(function(){var e=Object.defineProperty,t=(e,t)=>()=>(e&&(t=e(e=0)),t),n=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),r=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r};
/**
* @license
* Copyright 2010-2026 Three.js Authors
* SPDX-License-Identifier: MIT
*/
function i(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function a(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function o(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function s(...e){let t=`THREE.`+e.shift();St?St(`log`,t,...e):console.log(t,...e)}function c(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function l(...e){e=c(e);let t=`THREE.`+e.shift();if(St)St(`warn`,t,...e);else{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function u(...e){e=c(e);let t=`THREE.`+e.shift();if(St)St(`error`,t,...e);else{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function d(...e){let t=e.join(` `);t in xt||(xt[t]=!0,l(...e))}function f(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(wt[e&255]+wt[e>>8&255]+wt[e>>16&255]+wt[e>>24&255]+`-`+wt[t&255]+wt[t>>8&255]+`-`+wt[t>>16&15|64]+wt[t>>24&255]+`-`+wt[n&63|128]+wt[n>>8&255]+`-`+wt[n>>16&255]+wt[n>>24&255]+wt[r&255]+wt[r>>8&255]+wt[r>>16&255]+wt[r>>24&255]).toLowerCase()}function p(e,t,n){return Math.max(t,Math.min(n,e))}function m(e,t){return(e%t+t)%t}function h(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function g(e,t,n){return e===t?0:(n-e)/(t-e)}function _(e,t,n){return(1-n)*e+n*t}function v(e,t,n,r){return _(e,t,1-Math.exp(-n*r))}function y(e,t=1){return t-Math.abs(m(e,t*2)-t)}function b(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function x(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function S(e,t){return e+Math.floor(Math.random()*(t-e+1))}function C(e,t){return e+Math.random()*(t-e)}function w(e){return e*(.5-Math.random())}function T(e){e!==void 0&&(Tt=e);let t=Tt+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function E(e){return e*Et}function D(e){return e*Dt}function O(e){return(e&e-1)==0&&e!==0}function ee(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function k(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function te(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),u=a((t+r)/2),d=o((t+r)/2),f=a((t-r)/2),p=o((t-r)/2),m=a((r-t)/2),h=o((r-t)/2);switch(i){case`XYX`:e.set(s*d,c*f,c*p,s*u);break;case`YZY`:e.set(c*p,s*d,c*f,s*u);break;case`ZXZ`:e.set(c*f,c*p,s*d,s*u);break;case`XZX`:e.set(s*d,c*h,c*m,s*u);break;case`YXY`:e.set(c*m,s*d,c*h,s*u);break;case`ZYZ`:e.set(c*h,c*m,s*d,s*u);break;default:l(`MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function A(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function j(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function ne(){let e={enabled:!0,workingColorSpace:ht,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n?e:(this.spaces[t].transfer===`srgb`&&(e.r=M(e.r),e.g=M(e.g),e.b=M(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=N(e.r),e.g=N(e.g),e.b=N(e.b)),e)},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?gt:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(t,n){return d(`ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().`),e.workingToColorSpace(t,n)},toWorkingColorSpace:function(t,n){return d(`ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().`),e.colorSpaceToWorking(t,n)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[ht]:{primaries:t,whitePoint:r,transfer:gt,toXYZ:Nt,fromXYZ:Pt,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:H},outputColorSpaceConfig:{drawingBufferColorSpace:H}},[H]:{primaries:t,whitePoint:r,transfer:_t,toXYZ:Nt,fromXYZ:Pt,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:H}}}),e}function M(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function N(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}function P(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?Lt.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(l(`Texture: Unable to serialize Texture.`),{})}function F(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}function I(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){Zn.fromArray(e,a);let o=i.x*Math.abs(Zn.x)+i.y*Math.abs(Zn.y)+i.z*Math.abs(Zn.z),s=t.dot(Zn),c=n.dot(Zn),l=r.dot(Zn);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}function re(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;Br.copy(s),Br.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(Br);return l<n.near||l>n.far?null:{distance:l,point:Br.clone(),object:e}}function L(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,Pr),e.getVertexPosition(c,Fr),e.getVertexPosition(l,Ir);let u=re(e,t,n,r,Pr,Fr,Ir,zr);if(u){let e=new W;Ln.getBarycoord(zr,Pr,Fr,Ir,e),i&&(u.uv=Ln.getInterpolatedAttribute(i,s,c,l,e,new U)),a&&(u.uv1=Ln.getInterpolatedAttribute(a,s,c,l,e,new U)),o&&(u.normal=Ln.getInterpolatedAttribute(o,s,c,l,e,new W),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new W,materialIndex:0};Ln.getNormal(Pr,Fr,Ir,t.normal),u.face=t,u.barycoord=e}return u}function R(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(xi.fromBufferAttribute(s,i),Si.fromBufferAttribute(s,a),n.distanceSqToSegment(xi,Si,Ei,Di)>r)return;Ei.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(Ei);if(!(c<t.near||c>t.far))return{distance:c,point:Di.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}function z(e,t,n,r,i,a,o){let s=Fi.distanceSqToPoint(e);if(s<n){let n=new W;Fi.closestPointToPoint(e,n),n.applyMatrix4(r);let c=i.ray.origin.distanceTo(n);if(c<i.near||c>i.far)return;a.push({distance:c,distanceToRay:Math.sqrt(s),point:n,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}function ie(e,t,n=2){let r=t&&t.length,i=r?t[0]*n:e.length,a=ae(e,0,i,n,!0),o=[];if(!a||a.next===a.prev)return o;let s,c,l;if(r&&(a=fe(e,t,a,n)),e.length>80*n){s=e[0],c=e[1];let t=s,r=c;for(let a=n;a<i;a+=n){let n=e[a],i=e[a+1];n<s&&(s=n),i<c&&(c=i),n>t&&(t=n),i>r&&(r=i)}l=Math.max(t-s,r-c),l=l===0?0:32767/l}return se(a,o,n,s,c,l,0),o}function ae(e,t,n,r,i){let a;if(i===Pe(e,t,n,r)>0)for(let i=t;i<n;i+=r)a=je(i/r|0,e[i],e[i+1],a);else for(let i=n-r;i>=t;i-=r)a=je(i/r|0,e[i],e[i+1],a);return a&&Ce(a,a.next)&&(Me(a),a=a.next),a}function oe(e,t){if(!e)return e;t||=e;let n=e,r;do if(r=!1,!n.steiner&&(Ce(n,n.next)||V(n.prev,n,n.next)===0)){if(Me(n),n=t=n.prev,n===n.next)break;r=!0}else n=n.next;while(r||n!==t);return t}function se(e,t,n,r,i,a,o){if(!e)return;!o&&a&&ge(e,r,i,a);let s=e;for(;e.prev!==e.next;){let c=e.prev,l=e.next;if(a?le(e,r,i,a):ce(e)){t.push(c.i,e.i,l.i),Me(e),e=l.next,s=l.next;continue}if(e=l,e===s){o?o===1?(e=ue(oe(e),t),se(e,t,n,r,i,a,2)):o===2&&de(e,t,n,r,i,a):se(oe(e),t,n,r,i,a,1);break}}}function ce(e){let t=e.prev,n=e,r=e.next;if(V(t,n,r)>=0)return!1;let i=t.x,a=n.x,o=r.x,s=t.y,c=n.y,l=r.y,u=Math.min(i,a,o),d=Math.min(s,c,l),f=Math.max(i,a,o),p=Math.max(s,c,l),m=r.next;for(;m!==t;){if(m.x>=u&&m.x<=f&&m.y>=d&&m.y<=p&&xe(i,s,a,c,o,l,m.x,m.y)&&V(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function le(e,t,n,r){let i=e.prev,a=e,o=e.next;if(V(i,a,o)>=0)return!1;let s=i.x,c=a.x,l=o.x,u=i.y,d=a.y,f=o.y,p=Math.min(s,c,l),m=Math.min(u,d,f),h=Math.max(s,c,l),g=Math.max(u,d,f),_=ve(p,m,t,n,r),v=ve(h,g,t,n,r),y=e.prevZ,b=e.nextZ;for(;y&&y.z>=_&&b&&b.z<=v;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&xe(s,u,c,d,l,f,y.x,y.y)&&V(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&xe(s,u,c,d,l,f,b.x,b.y)&&V(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=_;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&xe(s,u,c,d,l,f,y.x,y.y)&&V(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=v;){if(b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&xe(s,u,c,d,l,f,b.x,b.y)&&V(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function ue(e,t){let n=e;do{let r=n.prev,i=n.next.next;!Ce(r,i)&&we(r,n,n.next,i)&&Oe(r,i)&&Oe(i,r)&&(t.push(r.i,n.i,i.i),Me(n),Me(n.next),n=e=i),n=n.next}while(n!==e);return oe(n)}function de(e,t,n,r,i,a){let o=e;do{let e=o.next.next;for(;e!==o.prev;){if(o.i!==e.i&&Se(o,e)){let s=Ae(o,e);o=oe(o,o.next),s=oe(s,s.next),se(o,t,n,r,i,a,0),se(s,t,n,r,i,a,0);return}e=e.next}o=o.next}while(o!==e)}function fe(e,t,n,r){let i=[];for(let n=0,a=t.length;n<a;n++){let o=ae(e,t[n]*r,n<a-1?t[n+1]*r:e.length,r,!1);o===o.next&&(o.steiner=!0),i.push(ye(o))}i.sort(B);for(let e=0;e<i.length;e++)n=pe(i[e],n);return n}function B(e,t){let n=e.x-t.x;return n===0&&(n=e.y-t.y,n===0&&(n=(e.next.y-e.y)/(e.next.x-e.x)-(t.next.y-t.y)/(t.next.x-t.x))),n}function pe(e,t){let n=me(e,t);if(!n)return t;let r=Ae(n,e);return oe(r,r.next),oe(n,n.next)}function me(e,t){let n=t,r=e.x,i=e.y,a=-1/0,o;if(Ce(e,n))return n;do{if(Ce(e,n.next))return n.next;if(i<=n.y&&i>=n.next.y&&n.next.y!==n.y){let e=n.x+(i-n.y)*(n.next.x-n.x)/(n.next.y-n.y);if(e<=r&&e>a&&(a=e,o=n.x<n.next.x?n:n.next,e===r))return o}n=n.next}while(n!==t);if(!o)return null;let s=o,c=o.x,l=o.y,u=1/0;n=o;do{if(r>=n.x&&n.x>=c&&r!==n.x&&be(i<l?r:a,i,c,l,i<l?a:r,i,n.x,n.y)){let t=Math.abs(i-n.y)/(r-n.x);Oe(n,e)&&(t<u||t===u&&(n.x>o.x||n.x===o.x&&he(o,n)))&&(o=n,u=t)}n=n.next}while(n!==s);return o}function he(e,t){return V(e.prev,e,t.prev)<0&&V(t.next,e,e.next)<0}function ge(e,t,n,r){let i=e;do i.z===0&&(i.z=ve(i.x,i.y,t,n,r)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==e);i.prevZ.nextZ=null,i.prevZ=null,_e(i)}function _e(e){let t,n=1;do{let r=e,i;e=null;let a=null;for(t=0;r;){t++;let o=r,s=0;for(let e=0;e<n&&(s++,o=o.nextZ,o);e++);let c=n;for(;s>0||c>0&&o;)s!==0&&(c===0||!o||r.z<=o.z)?(i=r,r=r.nextZ,s--):(i=o,o=o.nextZ,c--),a?a.nextZ=i:e=i,i.prevZ=a,a=i;r=o}a.nextZ=null,n*=2}while(t>1);return e}function ve(e,t,n,r,i){return e=(e-n)*i|0,t=(t-r)*i|0,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,e|t<<1}function ye(e){let t=e,n=e;do(t.x<n.x||t.x===n.x&&t.y<n.y)&&(n=t),t=t.next;while(t!==e);return n}function be(e,t,n,r,i,a,o,s){return(i-o)*(t-s)>=(e-o)*(a-s)&&(e-o)*(r-s)>=(n-o)*(t-s)&&(n-o)*(a-s)>=(i-o)*(r-s)}function xe(e,t,n,r,i,a,o,s){return!(e===o&&t===s)&&be(e,t,n,r,i,a,o,s)}function Se(e,t){return e.next.i!==t.i&&e.prev.i!==t.i&&!De(e,t)&&(Oe(e,t)&&Oe(t,e)&&ke(e,t)&&(V(e.prev,e,t.prev)||V(e,t.prev,t))||Ce(e,t)&&V(e.prev,e,e.next)>0&&V(t.prev,t,t.next)>0)}function V(e,t,n){return(t.y-e.y)*(n.x-t.x)-(t.x-e.x)*(n.y-t.y)}function Ce(e,t){return e.x===t.x&&e.y===t.y}function we(e,t,n,r){let i=Ee(V(e,t,n)),a=Ee(V(e,t,r)),o=Ee(V(n,r,e)),s=Ee(V(n,r,t));return!!(i!==a&&o!==s||i===0&&Te(e,n,t)||a===0&&Te(e,r,t)||o===0&&Te(n,e,r)||s===0&&Te(n,t,r))}function Te(e,t,n){return t.x<=Math.max(e.x,n.x)&&t.x>=Math.min(e.x,n.x)&&t.y<=Math.max(e.y,n.y)&&t.y>=Math.min(e.y,n.y)}function Ee(e){return e>0?1:e<0?-1:0}function De(e,t){let n=e;do{if(n.i!==e.i&&n.next.i!==e.i&&n.i!==t.i&&n.next.i!==t.i&&we(n,n.next,e,t))return!0;n=n.next}while(n!==e);return!1}function Oe(e,t){return V(e.prev,e,e.next)<0?V(e,t,e.next)>=0&&V(e,e.prev,t)>=0:V(e,t,e.prev)<0||V(e,e.next,t)<0}function ke(e,t){let n=e,r=!1,i=(e.x+t.x)/2,a=(e.y+t.y)/2;do n.y>a!=n.next.y>a&&n.next.y!==n.y&&i<(n.next.x-n.x)*(a-n.y)/(n.next.y-n.y)+n.x&&(r=!r),n=n.next;while(n!==e);return r}function Ae(e,t){let n=Ne(e.i,e.x,e.y),r=Ne(t.i,t.x,t.y),i=e.next,a=t.prev;return e.next=t,t.prev=e,n.next=i,i.prev=n,r.next=n,n.prev=r,a.next=r,r.prev=a,r}function je(e,t,n,r){let i=Ne(e,t,n);return r?(i.next=r.next,i.prev=r,r.next.prev=i,r.next=i):(i.prev=i,i.next=i),i}function Me(e){e.next.prev=e.prev,e.prev.next=e.next,e.prevZ&&(e.prevZ.nextZ=e.nextZ),e.nextZ&&(e.nextZ.prevZ=e.prevZ)}function Ne(e,t,n){return{i:e,x:t,y:n,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Pe(e,t,n,r){let i=0;for(let a=t,o=n-r;a<n;a+=r)i+=(e[o]-e[a])*(e[a+1]+e[o+1]),o=a;return i}function Fe(e){let t=e.length;t>2&&e[t-1].equals(e[0])&&e.pop()}function Ie(e,t){for(let n=0;n<t.length;n++)e.push(t[n].x),e.push(t[n].y)}function Le(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(ze(i))i.isRenderTargetTexture?(l(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i))if(ze(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice();else t[n][r]=i}}return t}function Re(e){let t={};for(let n=0;n<e.length;n++){let r=Le(e[n]);for(let e in r)t[e]=r[e]}return t}function ze(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function Be(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function Ve(e){function t(t,n){return e[t]-e[n]}let n=e.length,r=Array(n);for(let e=0;e!==n;++e)r[e]=e;return r.sort(t),r}function He(e,t,n){let r=e.length,i=new e.constructor(r);for(let a=0,o=0;o!==r;++a){let r=n[a]*t;for(let n=0;n!==t;++n)i[o++]=e[r+n]}return i}function Ue(e,t,n,r){let i=1,a=e[0];for(;a!==void 0&&a[r]===void 0;)a=e[i++];if(a===void 0)return;let o=a[r];if(o!==void 0)if(Array.isArray(o))do o=a[r],o!==void 0&&(t.push(a.time),n.push(...o)),a=e[i++];while(a!==void 0);else if(o.toArray!==void 0)do o=a[r],o!==void 0&&(t.push(a.time),o.toArray(n,n.length)),a=e[i++];while(a!==void 0);else do o=a[r],o!==void 0&&(t.push(a.time),n.push(o)),a=e[i++];while(a!==void 0)}function We(e){switch(e.toLowerCase()){case`scalar`:case`double`:case`float`:case`number`:case`integer`:return aa;case`vector`:case`vector2`:case`vector3`:case`vector4`:return la;case`color`:return ia;case`quaternion`:return sa;case`bool`:case`boolean`:return ra;case`string`:return ca}throw Error(`THREE.KeyframeTrack: Unsupported typeName: `+e)}function Ge(e){if(e.type===void 0)throw Error(`THREE.KeyframeTrack: track type undefined, can not parse`);let t=We(e.type);if(e.times===void 0){let t=[],n=[];Ue(e.keys,t,n,`value`),e.times=t,e.values=n}return t.parse===void 0?new t(e.name,e.times,e.values,e.interpolation):t.parse(e)}function Ke(e){try{let t=e.slice(e.indexOf(`:`)+1);return new URL(t).protocol===`blob:`}catch{return!1}}var qe,Je,Ye,Xe,Ze,Qe,$e,et,tt,nt,rt,it,at,ot,st,ct,lt,ut,dt,ft,pt,mt,H,ht,gt,_t,vt,yt,bt,xt,St,Ct,wt,Tt,Et,Dt,Ot,U,kt,W,At,jt,G,Mt,Nt,Pt,Ft,It,Lt,Rt,zt,Bt,Vt,Ht,Ut,K,Wt,Gt,Kt,qt,Jt,Yt,Xt,Zt,Qt,$t,en,tn,nn,rn,an,on,sn,cn,ln,un,dn,fn,pn,mn,hn,gn,_n,vn,yn,bn,xn,q,Sn,Cn,wn,Tn,En,Dn,On,kn,An,jn,Mn,Nn,Pn,Fn,In,Ln,Rn,zn,Bn,Vn,Hn,Un,Wn,Gn,Kn,qn,Jn,Yn,Xn,Zn,Qn,$n,er,tr,nr,rr,J,ir,ar,or,sr,cr,lr,ur,dr,fr,pr,mr,hr,gr,_r,vr,yr,br,xr,Sr,Cr,wr,Tr,Er,Dr,Or,kr,Ar,jr,Mr,Nr,Pr,Fr,Ir,Lr,Rr,zr,Br,Vr,Hr,Ur,Wr,Gr,Kr,qr,Jr,Yr,Xr,Zr,Qr,$r,ei,ti,ni,ri,ii,ai,oi,si,ci,li,ui,di,fi,pi,mi,hi,gi,_i,vi,yi,bi,xi,Si,Ci,wi,Ti,Ei,Di,Oi,ki,Ai,ji,Mi,Ni,Pi,Fi,Ii,Li,Ri,zi,Bi,Vi,Hi,Ui,Wi,Gi,Ki,qi,Ji,Yi,Xi,Zi,Qi,$i,ea,ta,na,ra,ia,aa,oa,sa,ca,la,ua,da,fa,pa,ma,ha,ga,_a,va,ya,ba,xa,Sa,Ca,wa,Ta,Ea,Da,Oa,ka,Aa,ja,Ma,Na,Pa,Fa,Ia,La,Ra,za,Ba,Va,Ha,Ua,Wa,Ga,Ka,qa,Ja,Ya,Xa,Za,Qa,$a,eo,to,no,ro,io,ao=t((()=>{qe=`attached`,Je=1e3,Ye=1001,Xe=1002,Ze=1003,Qe=1004,$e=1005,et=1006,tt=1007,nt=1008,rt=1009,it=1015,at=1023,ot=1028,st=2300,ct=2301,lt=2302,ut=2303,dt=2400,ft=2401,pt=2402,mt=2500,H=`srgb`,ht=`srgb-linear`,gt=`linear`,_t=`srgb`,vt=7680,yt=35044,bt=2e3,xt={},St=null,Ct=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},wt=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),Tt=1234567,Et=Math.PI/180,Dt=180/Math.PI,Ot={DEG2RAD:Et,RAD2DEG:Dt,generateUUID:f,clamp:p,euclideanModulo:m,mapLinear:h,inverseLerp:g,lerp:_,damp:v,pingpong:y,smoothstep:b,smootherstep:x,randInt:S,randFloat:C,randFloatSpread:w,seededRandom:T,degToRad:E,radToDeg:D,isPowerOfTwo:O,ceilPowerOfTwo:ee,floorPowerOfTwo:k,setQuaternionFromProperEuler:te,normalize:j,denormalize:A},U=class e{static{e.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=p(this.x,e.x,t.x),this.y=p(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=p(this.x,e,t),this.y=p(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(p(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(p(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},kt=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),u=o(r/2),d=o(i/2),f=s(n/2),p=s(r/2),m=s(i/2);switch(a){case`XYZ`:this._x=f*u*d+c*p*m,this._y=c*p*d-f*u*m,this._z=c*u*m+f*p*d,this._w=c*u*d-f*p*m;break;case`YXZ`:this._x=f*u*d+c*p*m,this._y=c*p*d-f*u*m,this._z=c*u*m-f*p*d,this._w=c*u*d+f*p*m;break;case`ZXY`:this._x=f*u*d-c*p*m,this._y=c*p*d+f*u*m,this._z=c*u*m+f*p*d,this._w=c*u*d-f*p*m;break;case`ZYX`:this._x=f*u*d-c*p*m,this._y=c*p*d+f*u*m,this._z=c*u*m-f*p*d,this._w=c*u*d+f*p*m;break;case`YZX`:this._x=f*u*d+c*p*m,this._y=c*p*d+f*u*m,this._z=c*u*m-f*p*d,this._w=c*u*d-f*p*m;break;case`XZY`:this._x=f*u*d-c*p*m,this._y=c*p*d-f*u*m,this._z=c*u*m+f*p*d,this._w=c*u*d+f*p*m;break;default:l(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(p(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},W=class e{static{e.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(jt.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(jt.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=p(this.x,e.x,t.x),this.y=p(this.y,e.y,t.y),this.z=p(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=p(this.x,e,t),this.y=p(this.y,e,t),this.z=p(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(p(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return At.copy(this).projectOnVector(e),this.sub(At)}reflect(e){return this.sub(At.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(p(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},At=new W,jt=new kt,G=class e{static{e.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return d(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(Mt.makeScale(e,t)),this}rotate(e){return d(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(Mt.makeRotation(-e)),this}translate(e,t){return d(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(Mt.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Mt=new G,Nt=new G().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Pt=new G().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715),Ft=ne(),Lt=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{It===void 0&&(It=o(`canvas`)),It.width=e.width,It.height=e.height;let t=It.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=It}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=o(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=M(i[e]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(M(t[e]/255)*255):t[e]=M(t[e]);return{data:t,width:e.width,height:e.height}}else return l(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},Rt=0,zt=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,`id`,{value:Rt++}),this.uuid=f(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width,t.height,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(P(r[t].image)):e.push(P(r[t]))}else e=P(r);n.url=e}return t||(e.images[this.uuid]=n),n}},Bt=0,Vt=new W,Ht=class e extends Ct{constructor(t=e.DEFAULT_IMAGE,n=e.DEFAULT_MAPPING,r=Ye,i=Ye,a=et,o=nt,s=at,c=rt,l=e.DEFAULT_ANISOTROPY,u=``){super(),this.isTexture=!0,Object.defineProperty(this,`id`,{value:Bt++}),this.uuid=f(),this.name=``,this.source=new zt(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=r,this.wrapT=i,this.magFilter=a,this.minFilter=o,this.anisotropy=l,this.format=s,this.internalFormat=null,this.type=c,this.offset=new U(0,0),this.repeat=new U(1,1),this.center=new U(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new G,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Vt).x}get height(){return this.source.getSize(Vt).y}get depth(){return this.source.getSize(Vt).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){l(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){l(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(e){if(this.mapping!==300)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Je:e.x-=Math.floor(e.x);break;case Ye:e.x=e.x<0?0:1;break;case Xe:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x-=Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Je:e.y-=Math.floor(e.y);break;case Ye:e.y=e.y<0?0:1;break;case Xe:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y-=Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}},Ht.DEFAULT_IMAGE=null,Ht.DEFAULT_MAPPING=300,Ht.DEFAULT_ANISOTROPY=1,Ut=class e{static{e.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=p(this.x,e.x,t.x),this.y=p(this.y,e.y,t.y),this.z=p(this.z,e.z,t.z),this.w=p(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=p(this.x,e,t),this.y=p(this.y,e,t),this.z=p(this.z,e,t),this.w=p(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(p(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},K=class e{static{e.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/Wt.setFromMatrixColumn(e,0).length(),i=1/Wt.setFromMatrixColumn(e,1).length(),a=1/Wt.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Kt,e,qt)}lookAt(e,t,n){let r=this.elements;return Xt.subVectors(e,t),Xt.lengthSq()===0&&(Xt.z=1),Xt.normalize(),Jt.crossVectors(n,Xt),Jt.lengthSq()===0&&(Math.abs(n.z)===1?Xt.x+=1e-4:Xt.z+=1e-4,Xt.normalize(),Jt.crossVectors(n,Xt)),Jt.normalize(),Yt.crossVectors(Xt,Jt),r[0]=Jt.x,r[4]=Yt.x,r[8]=Xt.x,r[1]=Jt.y,r[5]=Yt.y,r[9]=Xt.y,r[2]=Jt.z,r[6]=Yt.z,r[10]=Xt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],ee=r[2],k=r[6],te=r[10],A=r[14],j=r[3],ne=r[7],M=r[11],N=r[15];return i[0]=a*x+o*T+s*ee+c*j,i[4]=a*S+o*E+s*k+c*ne,i[8]=a*C+o*D+s*te+c*M,i[12]=a*w+o*O+s*A+c*N,i[1]=l*x+u*T+d*ee+f*j,i[5]=l*S+u*E+d*k+f*ne,i[9]=l*C+u*D+d*te+f*M,i[13]=l*w+u*O+d*A+f*N,i[2]=p*x+m*T+h*ee+g*j,i[6]=p*S+m*E+h*k+g*ne,i[10]=p*C+m*D+h*te+g*M,i[14]=p*w+m*O+h*A+g*N,i[3]=_*x+v*T+y*ee+b*j,i[7]=_*S+v*E+y*k+b*ne,i[11]=_*C+v*D+y*te+b*M,i[15]=_*w+v*O+y*A+b*N,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,ee=_*O-v*D+y*E+b*T-x*w+S*C;if(ee===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let k=1/ee;return e[0]=(o*O-s*D+c*E)*k,e[1]=(r*D-n*O-i*E)*k,e[2]=(m*S-h*x+g*b)*k,e[3]=(d*x-u*S-f*b)*k,e[4]=(s*T-a*O-c*w)*k,e[5]=(t*O-r*T+i*w)*k,e[6]=(h*y-p*S-g*v)*k,e[7]=(l*S-d*y+f*v)*k,e[8]=(a*D-o*T+c*C)*k,e[9]=(n*T-t*D-i*C)*k,e[10]=(p*x-m*y+g*_)*k,e[11]=(u*y-l*x-f*_)*k,e[12]=(o*w-a*E-s*C)*k,e[13]=(t*E-n*w+r*C)*k,e[14]=(m*v-p*b-h*_)*k,e[15]=(l*b-u*v+d*_)*k,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=Wt.set(r[0],r[1],r[2]).length(),o=Wt.set(r[4],r[5],r[6]).length(),s=Wt.set(r[8],r[9],r[10]).length();i<0&&(a=-a),Gt.copy(this);let c=1/a,l=1/o,u=1/s;return Gt.elements[0]*=c,Gt.elements[1]*=c,Gt.elements[2]*=c,Gt.elements[4]*=l,Gt.elements[5]*=l,Gt.elements[6]*=l,Gt.elements[8]*=u,Gt.elements[9]*=u,Gt.elements[10]*=u,t.setFromRotationMatrix(Gt),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=bt,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=bt,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Wt=new W,Gt=new K,Kt=new W(0,0,0),qt=new W(1,1,1),Jt=new W,Yt=new W,Xt=new W,Zt=new K,Qt=new kt,$t=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],u=r[9],d=r[2],f=r[6],m=r[10];switch(t){case`XYZ`:this._y=Math.asin(p(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-u,m),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(f,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-p(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-d,i),this._z=0);break;case`ZXY`:this._x=Math.asin(p(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-d,m),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-p(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(f,m),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(p(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-u,c),this._y=Math.atan2(-d,i)):(this._x=0,this._y=Math.atan2(o,m));break;case`XZY`:this._z=Math.asin(-p(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(f,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-u,m),this._y=0);break;default:l(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Zt.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Zt,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Qt.setFromEuler(this),this.setFromQuaternion(Qt,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}},$t.DEFAULT_ORDER=`XYZ`,en=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!=0}},tn=0,nn=new W,rn=new kt,an=new K,on=new W,sn=new W,cn=new W,ln=new kt,un=new W(1,0,0),dn=new W(0,1,0),fn=new W(0,0,1),pn={type:`added`},mn={type:`removed`},hn={type:`childadded`,child:null},gn={type:`childremoved`,child:null},_n=class e extends Ct{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,`id`,{value:tn++}),this.uuid=f(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new W,n=new $t,r=new kt,i=new W(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new K},normalMatrix:{value:new G}}),this.matrix=new K,this.matrixWorld=new K,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new en,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return rn.setFromAxisAngle(e,t),this.quaternion.multiply(rn),this}rotateOnWorldAxis(e,t){return rn.setFromAxisAngle(e,t),this.quaternion.premultiply(rn),this}rotateX(e){return this.rotateOnAxis(un,e)}rotateY(e){return this.rotateOnAxis(dn,e)}rotateZ(e){return this.rotateOnAxis(fn,e)}translateOnAxis(e,t){return nn.copy(e).applyQuaternion(this.quaternion),this.position.add(nn.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(un,e)}translateY(e){return this.translateOnAxis(dn,e)}translateZ(e){return this.translateOnAxis(fn,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(an.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?on.copy(e):on.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),sn.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?an.lookAt(sn,on,this.up):an.lookAt(on,sn,this.up),this.quaternion.setFromRotationMatrix(an),r&&(an.extractRotation(r.matrixWorld),rn.setFromRotationMatrix(an),this.quaternion.premultiply(rn.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(u(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(pn),hn.child=e,this.dispatchEvent(hn),hn.child=null):u(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(mn),gn.child=e,this.dispatchEvent(gn),gn.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),an.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),an.multiply(e.parent.matrixWorld)),e.applyMatrix4(an),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(pn),hn.child=e,this.dispatchEvent(hn),hn.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(sn,e,cn),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(sn,ln,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,this.name!==``&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material);if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}},_n.DEFAULT_UP=new W(0,1,0),_n.DEFAULT_MATRIX_AUTO_UPDATE=!0,_n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0,vn=class extends _n{constructor(){super(),this.isGroup=!0,this.type=`Group`}},yn={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},bn={h:0,s:0,l:0},xn={h:0,s:0,l:0},q=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=H){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ft.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Ft.workingColorSpace){return this.r=e,this.g=t,this.b=n,Ft.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Ft.workingColorSpace){if(e=m(e,1),t=p(t,0,1),n=p(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=F(i,r,e+1/3),this.g=F(i,r,e),this.b=F(i,r,e-1/3)}return Ft.colorSpaceToWorking(this,r),this}setStyle(e,t=H){function n(t){t!==void 0&&parseFloat(t)<1&&l(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseInt(i[1],10))/100,Math.min(100,parseInt(i[2],10))/100,Math.min(100,parseInt(i[3],10))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:l(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);l(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=H){let n=yn[e.toLowerCase()];return n===void 0?l(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=M(e.r),this.g=M(e.g),this.b=M(e.b),this}copyLinearToSRGB(e){return this.r=N(e.r),this.g=N(e.g),this.b=N(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=H){return Ft.workingToColorSpace(Sn.copy(this),e),Math.round(p(Sn.r*255,0,255))*65536+Math.round(p(Sn.g*255,0,255))*256+Math.round(p(Sn.b*255,0,255))}getHexString(e=H){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ft.workingColorSpace){Ft.workingToColorSpace(Sn.copy(this),t);let n=Sn.r,r=Sn.g,i=Sn.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4;break}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=Ft.workingColorSpace){return Ft.workingToColorSpace(Sn.copy(this),t),e.r=Sn.r,e.g=Sn.g,e.b=Sn.b,e}getStyle(e=H){Ft.workingToColorSpace(Sn.copy(this),e);let t=Sn.r,n=Sn.g,r=Sn.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(bn),this.setHSL(bn.h+e,bn.s+t,bn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(bn),e.getHSL(xn);let n=_(bn.h,xn.h,t),r=_(bn.s,xn.s,t),i=_(bn.l,xn.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Sn=new q,q.NAMES=yn,Cn=class extends _n{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new $t,this.environmentIntensity=1,this.environmentRotation=new $t,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}},wn=new W,Tn=new W,En=new W,Dn=new W,On=new W,kn=new W,An=new W,jn=new W,Mn=new W,Nn=new W,Pn=new Ut,Fn=new Ut,In=new Ut,Ln=class e{constructor(e=new W,t=new W,n=new W){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),wn.subVectors(e,t),r.cross(wn);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){wn.subVectors(r,t),Tn.subVectors(n,t),En.subVectors(e,t);let a=wn.dot(wn),o=wn.dot(Tn),s=wn.dot(En),c=Tn.dot(Tn),l=Tn.dot(En),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Dn)===null?!1:Dn.x>=0&&Dn.y>=0&&Dn.x+Dn.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,Dn)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,Dn.x),s.addScaledVector(a,Dn.y),s.addScaledVector(o,Dn.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return Pn.setScalar(0),Fn.setScalar(0),In.setScalar(0),Pn.fromBufferAttribute(e,t),Fn.fromBufferAttribute(e,n),In.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Pn,i.x),a.addScaledVector(Fn,i.y),a.addScaledVector(In,i.z),a}static isFrontFacing(e,t,n,r){return wn.subVectors(n,t),Tn.subVectors(e,t),wn.cross(Tn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return wn.subVectors(this.c,this.b),Tn.subVectors(this.a,this.b),wn.cross(Tn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;On.subVectors(r,n),kn.subVectors(i,n),jn.subVectors(e,n);let s=On.dot(jn),c=kn.dot(jn);if(s<=0&&c<=0)return t.copy(n);Mn.subVectors(e,r);let l=On.dot(Mn),u=kn.dot(Mn);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0)return a=s/(s-l),t.copy(n).addScaledVector(On,a);Nn.subVectors(e,i);let f=On.dot(Nn),p=kn.dot(Nn);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(kn,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return An.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(An,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(On,a).addScaledVector(kn,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Rn=class{constructor(e=new W(1/0,1/0,1/0),t=new W(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Bn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Bn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Bn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,Bn):Bn.fromBufferAttribute(r,t),Bn.applyMatrix4(e.matrixWorld),this.expandByPoint(Bn);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),Vn.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),Vn.copy(e.boundingBox)),Vn.applyMatrix4(e.matrixWorld),this.union(Vn)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Bn),Bn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Jn),Yn.subVectors(this.max,Jn),Hn.subVectors(e.a,Jn),Un.subVectors(e.b,Jn),Wn.subVectors(e.c,Jn),Gn.subVectors(Un,Hn),Kn.subVectors(Wn,Un),qn.subVectors(Hn,Wn);let t=[0,-Gn.z,Gn.y,0,-Kn.z,Kn.y,0,-qn.z,qn.y,Gn.z,0,-Gn.x,Kn.z,0,-Kn.x,qn.z,0,-qn.x,-Gn.y,Gn.x,0,-Kn.y,Kn.x,0,-qn.y,qn.x,0];return!I(t,Hn,Un,Wn,Yn)||(t=[1,0,0,0,1,0,0,0,1],!I(t,Hn,Un,Wn,Yn))?!1:(Xn.crossVectors(Gn,Kn),t=[Xn.x,Xn.y,Xn.z],I(t,Hn,Un,Wn,Yn))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Bn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Bn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(zn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),zn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),zn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),zn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),zn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),zn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),zn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),zn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(zn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},zn=[new W,new W,new W,new W,new W,new W,new W,new W],Bn=new W,Vn=new Rn,Hn=new W,Un=new W,Wn=new W,Gn=new W,Kn=new W,qn=new W,Jn=new W,Yn=new W,Xn=new W,Zn=new W,Qn=new W,$n=new U,er=0,tr=class extends Ct{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,`id`,{value:er++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=yt,this.updateRanges=[],this.gpuType=it,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)$n.fromBufferAttribute(this,t),$n.applyMatrix3(e),this.setXY(t,$n.x,$n.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Qn.fromBufferAttribute(this,t),Qn.applyMatrix3(e),this.setXYZ(t,Qn.x,Qn.y,Qn.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Qn.fromBufferAttribute(this,t),Qn.applyMatrix4(e),this.setXYZ(t,Qn.x,Qn.y,Qn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Qn.fromBufferAttribute(this,t),Qn.applyNormalMatrix(e),this.setXYZ(t,Qn.x,Qn.y,Qn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Qn.fromBufferAttribute(this,t),Qn.transformDirection(e),this.setXYZ(t,Qn.x,Qn.y,Qn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=A(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=j(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=A(t,this.array)),t}setX(e,t){return this.normalized&&(t=j(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=A(t,this.array)),t}setY(e,t){return this.normalized&&(t=j(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=A(t,this.array)),t}setZ(e,t){return this.normalized&&(t=j(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=A(t,this.array)),t}setW(e,t){return this.normalized&&(t=j(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=j(t,this.array),n=j(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=j(t,this.array),n=j(n,this.array),r=j(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=j(t,this.array),n=j(n,this.array),r=j(r,this.array),i=j(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==``&&(e.name=this.name),this.usage!==35044&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:`dispose`})}},nr=class extends tr{constructor(e,t,n){super(new Uint16Array(e),t,n)}},rr=class extends tr{constructor(e,t,n){super(new Uint32Array(e),t,n)}},J=class extends tr{constructor(e,t,n){super(new Float32Array(e),t,n)}},ir=new Rn,ar=new W,or=new W,sr=class{constructor(e=new W,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?ir.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ar.subVectors(e,this.center);let t=ar.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(ar,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(or.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ar.copy(e.center).add(or)),this.expandByPoint(ar.copy(e.center).sub(or))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},cr=0,lr=new K,ur=new _n,dr=new W,fr=new Rn,pr=new Rn,mr=new W,hr=class e extends Ct{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,`id`,{value:cr++}),this.uuid=f(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(i(e)?rr:nr)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new G().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return lr.makeRotationFromQuaternion(e),this.applyMatrix4(lr),this}rotateX(e){return lr.makeRotationX(e),this.applyMatrix4(lr),this}rotateY(e){return lr.makeRotationY(e),this.applyMatrix4(lr),this}rotateZ(e){return lr.makeRotationZ(e),this.applyMatrix4(lr),this}translate(e,t,n){return lr.makeTranslation(e,t,n),this.applyMatrix4(lr),this}scale(e,t,n){return lr.makeScale(e,t,n),this.applyMatrix4(lr),this}lookAt(e){return ur.lookAt(e),ur.updateMatrix(),this.applyMatrix4(ur.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(dr).negate(),this.translate(dr.x,dr.y,dr.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new J(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&l(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Rn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){u(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new W(-1/0,-1/0,-1/0),new W(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];fr.setFromBufferAttribute(n),this.morphTargetsRelative?(mr.addVectors(this.boundingBox.min,fr.min),this.boundingBox.expandByPoint(mr),mr.addVectors(this.boundingBox.max,fr.max),this.boundingBox.expandByPoint(mr)):(this.boundingBox.expandByPoint(fr.min),this.boundingBox.expandByPoint(fr.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&u(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new sr);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){u(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new W,1/0);return}if(e){let n=this.boundingSphere.center;if(fr.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];pr.setFromBufferAttribute(n),this.morphTargetsRelative?(mr.addVectors(fr.min,pr.min),fr.expandByPoint(mr),mr.addVectors(fr.max,pr.max),fr.expandByPoint(mr)):(fr.expandByPoint(pr.min),fr.expandByPoint(pr.max))}fr.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)mr.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(mr));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)mr.fromBufferAttribute(a,t),o&&(dr.fromBufferAttribute(e,t),mr.add(dr)),r=Math.max(r,n.distanceToSquared(mr))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&u(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){u(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new tr(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[];for(let e=0;e<n.count;e++)o[e]=new W,s[e]=new W;let c=new W,l=new W,d=new W,f=new U,p=new U,m=new U,h=new W,g=new W;function _(e,t,r){c.fromBufferAttribute(n,e),l.fromBufferAttribute(n,t),d.fromBufferAttribute(n,r),f.fromBufferAttribute(i,e),p.fromBufferAttribute(i,t),m.fromBufferAttribute(i,r),l.sub(c),d.sub(c),p.sub(f),m.sub(f);let a=1/(p.x*m.y-m.x*p.y);isFinite(a)&&(h.copy(l).multiplyScalar(m.y).addScaledVector(d,-p.y).multiplyScalar(a),g.copy(d).multiplyScalar(p.x).addScaledVector(l,-m.x).multiplyScalar(a),o[e].add(h),o[t].add(h),o[r].add(h),s[e].add(g),s[t].add(g),s[r].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let t=0,n=v.length;t<n;++t){let n=v[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)_(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let y=new W,b=new W,x=new W,S=new W;function C(e){x.fromBufferAttribute(r,e),S.copy(x);let t=o[e];y.copy(t),y.sub(x.multiplyScalar(x.dot(t))).normalize(),b.crossVectors(S,t);let n=b.dot(s[e])<0?-1:1;a.setXYZW(e,y.x,y.y,y.z,n)}for(let t=0,n=v.length;t<n;++t){let n=v[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)C(e.getX(t+0)),C(e.getX(t+1)),C(e.getX(t+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new tr(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new W,i=new W,a=new W,o=new W,s=new W,c=new W,l=new W,u=new W;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)mr.fromBufferAttribute(e,t),mr.normalize(),e.setXYZ(t,mr.x,mr.y,mr.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new tr(a,r,i)}if(this.index===null)return l(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,this.name!==``&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},gr=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e===void 0?0:e.length/t,this.usage=yt,this.updateRanges=[],this.version=0,this.uuid=f()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,i=this.stride;r<i;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=f()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=f()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},_r=new W,vr=class e{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name=``,this.data=e,this.itemSize=t,this.offset=n,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)_r.fromBufferAttribute(this,t),_r.applyMatrix4(e),this.setXYZ(t,_r.x,_r.y,_r.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)_r.fromBufferAttribute(this,t),_r.applyNormalMatrix(e),this.setXYZ(t,_r.x,_r.y,_r.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)_r.fromBufferAttribute(this,t),_r.transformDirection(e),this.setXYZ(t,_r.x,_r.y,_r.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=A(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=j(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=j(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=j(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=j(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=j(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=A(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=A(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=A(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=A(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=j(t,this.array),n=j(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=j(t,this.array),n=j(n,this.array),r=j(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=j(t,this.array),n=j(n,this.array),r=j(r,this.array),i=j(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=i,this}clone(t){if(t===void 0){s(`InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return new tr(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new e(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){s(`InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},yr=0,br=class extends Ct{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,`id`,{value:yr++}),this.uuid=f(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new q(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=vt,this.stencilZFail=vt,this.stencilZPass=vt,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){l(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){l(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,this.name!==``&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==1&&(n.blending=this.blending),this.side!==0&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==204&&(n.blendSrc=this.blendSrc),this.blendDst!==205&&(n.blendDst=this.blendDst),this.blendEquation!==100&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==3&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==519&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==7680&&(n.stencilFail=this.stencilFail),this.stencilZFail!==7680&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==7680&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.allowOverride===!1&&(n.allowOverride=!1),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==`round`&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==`round`&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new q().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors==`number`?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new U().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new U().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},xr=new W,Sr=new W,Cr=new W,wr=new W,Tr=new W,Er=new W,Dr=new W,Or=class{constructor(e=new W,t=new W(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,xr)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=xr.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(xr.copy(this.origin).addScaledVector(this.direction,t),xr.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Sr.copy(e).add(t).multiplyScalar(.5),Cr.copy(t).sub(e).normalize(),wr.copy(this.origin).sub(Sr);let i=e.distanceTo(t)*.5,a=-this.direction.dot(Cr),o=wr.dot(this.direction),s=-wr.dot(Cr),c=wr.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0)if(u=a*s-o,d=a*o-s,p=i*l,u>=0)if(d>=-p)if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c);else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Sr).addScaledVector(Cr,d),f}intersectSphere(e,t){xr.subVectors(e.center,this.origin);let n=xr.dot(this.direction),r=xr.dot(xr)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,xr)!==null}intersectTriangle(e,t,n,r,i){Tr.subVectors(t,e),Er.subVectors(n,e),Dr.crossVectors(Tr,Er);let a=this.direction.dot(Dr),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;wr.subVectors(this.origin,e);let s=o*this.direction.dot(Er.crossVectors(wr,Er));if(s<0)return null;let c=o*this.direction.dot(Tr.cross(wr));if(c<0||s+c>a)return null;let l=-o*wr.dot(Dr);return l<0?null:this.at(l/a,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},kr=class extends br{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new q(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $t,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Ar=new K,jr=new Or,Mr=new sr,Nr=new W,Pr=new W,Fr=new W,Ir=new W,Lr=new W,Rr=new W,zr=new W,Br=new W,Vr=class extends _n{constructor(e=new hr,t=new kr){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){Rr.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(Lr.fromBufferAttribute(s,e),a?Rr.addScaledVector(Lr,r):Rr.addScaledVector(Lr.sub(t),r))}t.add(Rr)}return t}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Mr.copy(n.boundingSphere),Mr.applyMatrix4(i),jr.copy(e.ray).recast(e.near),!(Mr.containsPoint(jr.origin)===!1&&(jr.intersectSphere(Mr,Nr)===null||jr.origin.distanceToSquared(Nr)>(e.far-e.near)**2))&&(Ar.copy(i).invert(),jr.copy(e.ray).applyMatrix4(Ar),!(n.boundingBox!==null&&jr.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,jr)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null)if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=L(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=L(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}else if(s!==void 0)if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=L(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=L(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}},Hr=new Ut,Ur=new Ut,Wr=new Ut,Gr=new Ut,Kr=new K,qr=new W,Jr=new sr,Yr=new K,Xr=new Or,Zr=class extends Vr{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type=`SkinnedMesh`,this.bindMode=qe,this.bindMatrix=new K,this.bindMatrixInverse=new K,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Rn),this.boundingBox.makeEmpty();let t=e.getAttribute(`position`);for(let e=0;e<t.count;e++)this.getVertexPosition(e,qr),this.boundingBox.expandByPoint(qr)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new sr),this.boundingSphere.makeEmpty();let t=e.getAttribute(`position`);for(let e=0;e<t.count;e++)this.getVertexPosition(e,qr),this.boundingSphere.expandByPoint(qr)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,r=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Jr.copy(this.boundingSphere),Jr.applyMatrix4(r),e.ray.intersectsSphere(Jr)!==!1&&(Yr.copy(r).invert(),Xr.copy(e.ray).applyMatrix4(Yr),!(this.boundingBox!==null&&Xr.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Xr)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new Ut,t=this.geometry.attributes.skinWeight;for(let n=0,r=t.count;n<r;n++){e.fromBufferAttribute(t,n);let r=1/e.manhattanLength();r===1/0?e.set(1,0,0,0):e.multiplyScalar(r),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===`attached`?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===`detached`?this.bindMatrixInverse.copy(this.bindMatrix).invert():l(`SkinnedMesh: Unrecognized bindMode: `+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,r=this.geometry;Ur.fromBufferAttribute(r.attributes.skinIndex,e),Wr.fromBufferAttribute(r.attributes.skinWeight,e),t.isVector4?(Hr.copy(t),t.set(0,0,0,0)):(Hr.set(...t,1),t.set(0,0,0)),Hr.applyMatrix4(this.bindMatrix);for(let e=0;e<4;e++){let r=Wr.getComponent(e);if(r!==0){let i=Ur.getComponent(e);Kr.multiplyMatrices(n.bones[i].matrixWorld,n.boneInverses[i]),t.addScaledVector(Gr.copy(Hr).applyMatrix4(Kr),r)}}return t.isVector4&&(t.w=Hr.w),t.applyMatrix4(this.bindMatrixInverse)}},Qr=class extends _n{constructor(){super(),this.isBone=!0,this.type=`Bone`}},$r=class extends Ht{constructor(e=null,t=1,n=1,r,i,a,o,s,c=Ze,l=Ze,u,d){super(null,a,o,s,c,l,r,i,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},ei=new K,ti=new K,ni=class e{constructor(e=[],t=[]){this.uuid=f(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){l(`Skeleton: Number of inverse bone matrices does not match amount of bones.`),this.boneInverses=[];for(let e=0,t=this.bones.length;e<t;e++)this.boneInverses.push(new K)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let t=new K;this.bones[e]&&t.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(t)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let t=this.bones[e];t&&t.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let t=this.bones[e];t&&(t.parent&&t.parent.isBone?(t.matrix.copy(t.parent.matrixWorld).invert(),t.matrix.multiply(t.matrixWorld)):t.matrix.copy(t.matrixWorld),t.matrix.decompose(t.position,t.quaternion,t.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,r=this.boneTexture;for(let r=0,i=e.length;r<i;r++){let i=e[r]?e[r].matrixWorld:ti;ei.multiplyMatrices(i,t[r]),ei.toArray(n,r*16)}r!==null&&(r.needsUpdate=!0)}clone(){return new e(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new $r(t,e,e,at,it);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let n=this.bones[t];if(n.name===e)return n}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,r=e.bones.length;n<r;n++){let r=e.bones[n],i=t[r];i===void 0&&(l(`Skeleton: No bone found with UUID:`,r),i=new Qr),this.bones.push(i),this.boneInverses.push(new K().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.7,type:`Skeleton`,generator:`Skeleton.toJSON`},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let r=0,i=t.length;r<i;r++){let i=t[r];e.bones.push(i.uuid);let a=n[r];e.boneInverses.push(a.toArray())}return e}},ri=class extends tr{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},ii=new K,ai=new K,oi=[],si=new Rn,ci=new K,li=new Vr,ui=new sr,di=class extends Vr{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new ri(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let e=0;e<n;e++)this.setMatrixAt(e,ci)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Rn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ii),si.copy(e.boundingBox).applyMatrix4(ii),this.boundingBox.union(si)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new sr),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ii),ui.copy(e.boundingSphere).applyMatrix4(ii),this.boundingSphere.union(ui)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,i=e*(n.length+1)+1;for(let e=0;e<n.length;e++)n[e]=r[i+e]}raycast(e,t){let n=this.matrixWorld,r=this.count;if(li.geometry=this.geometry,li.material=this.material,li.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ui.copy(this.boundingSphere),ui.applyMatrix4(n),e.ray.intersectsSphere(ui)!==!1))for(let i=0;i<r;i++){this.getMatrixAt(i,ii),ai.multiplyMatrices(n,ii),li.matrixWorld=ai,li.raycast(e,oi);for(let e=0,n=oi.length;e<n;e++){let n=oi[e];n.instanceId=i,n.object=this,t.push(n)}oi.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new ri(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new $r(new Float32Array(r*this.count),r,this.count,ot,it));let i=this.morphTexture.source.data.data,a=0;for(let e=0;e<n.length;e++)a+=n[e];let o=this.geometry.morphTargetsRelative?1:1-a,s=r*e;return i[s]=o,i.set(n,s+1),this}updateMorphTargets(){}dispose(){this.dispatchEvent({type:`dispose`}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},fi=new W,pi=new W,mi=new G,hi=class{constructor(e=new W(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=fi.subVectors(n,t).cross(pi.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(fi),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||mi.getNormalMatrix(e),r=this.coplanarPoint(fi).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},gi=new sr,_i=new U(.5,.5),vi=new W,yi=class{constructor(e=new hi,t=new hi,n=new hi,r=new hi,i=new hi,a=new hi){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=bt,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),gi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),gi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(gi)}intersectsSprite(e){return gi.center.set(0,0,0),gi.radius=.7071067811865476+_i.distanceTo(e.center),gi.applyMatrix4(e.matrixWorld),this.intersectsSphere(gi)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if(vi.x=r.normal.x>0?e.max.x:e.min.x,vi.y=r.normal.y>0?e.max.y:e.min.y,vi.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(vi)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},bi=class extends br{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new q(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},xi=new W,Si=new W,Ci=new K,wi=new Or,Ti=new sr,Ei=new W,Di=new W,Oi=class extends _n{constructor(e=new hr,t=new bi){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)xi.fromBufferAttribute(t,e-1),Si.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=xi.distanceTo(Si);e.setAttribute(`lineDistance`,new J(n,1))}else l(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ti.copy(n.boundingSphere),Ti.applyMatrix4(r),Ti.radius+=i,e.ray.intersectsSphere(Ti)===!1)return;Ci.copy(r).invert(),wi.copy(e.ray).applyMatrix4(Ci);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=R(this,e,wi,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=R(this,e,wi,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=R(this,e,wi,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=R(this,e,wi,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}},ki=new W,Ai=new W,ji=class extends Oi{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)ki.fromBufferAttribute(t,e),Ai.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+ki.distanceTo(Ai);e.setAttribute(`lineDistance`,new J(n,1))}else l(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},Mi=class extends Oi{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type=`LineLoop`}},Ni=class extends br{constructor(e){super(),this.isPointsMaterial=!0,this.type=`PointsMaterial`,this.color=new q(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Pi=new K,Fi=new Or,Ii=new sr,Li=new W,Ri=class extends _n{constructor(e=new hr,t=new Ni){super(),this.isPoints=!0,this.type=`Points`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ii.copy(n.boundingSphere),Ii.applyMatrix4(r),Ii.radius+=i,e.ray.intersectsSphere(Ii)===!1)return;Pi.copy(r).invert(),Fi.copy(e.ray).applyMatrix4(Pi);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=n.index,l=n.attributes.position;if(c!==null){let n=Math.max(0,a.start),i=Math.min(c.count,a.start+a.count);for(let a=n,o=i;a<o;a++){let n=c.getX(a);Li.fromBufferAttribute(l,n),z(Li,n,s,r,e,t,this)}}else{let n=Math.max(0,a.start),i=Math.min(l.count,a.start+a.count);for(let a=n,o=i;a<o;a++)Li.fromBufferAttribute(l,a),z(Li,a,s,r,e,t,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}},zi=class e extends hr{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new J(c,3)),this.setAttribute(`normal`,new J(l,3)),this.setAttribute(`uv`,new J(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new W;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},Bi=class e extends hr{constructor(e=1,t=1,n=4,r=8,i=1){super(),this.type=`CapsuleGeometry`,this.parameters={radius:e,height:t,capSegments:n,radialSegments:r,heightSegments:i},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),r=Math.max(3,Math.floor(r)),i=Math.max(1,Math.floor(i));let a=[],o=[],s=[],c=[],l=t/2,u=Math.PI/2*e,d=t,f=2*u+d,p=n*2+i,m=r+1,h=new W,g=new W;for(let _=0;_<=p;_++){let v=0,y=0,b=0,x=0;if(_<=n){let t=_/n,r=t*Math.PI/2;y=-l-e*Math.cos(r),b=e*Math.sin(r),x=-e*Math.cos(r),v=t*u}else if(_<=n+i){let r=(_-n)/i;y=-l+r*t,b=e,x=0,v=u+r*d}else{let t=(_-n-i)/n,r=t*Math.PI/2;y=l+e*Math.sin(r),b=e*Math.cos(r),x=e*Math.sin(r),v=u+d+t*u}let S=Math.max(0,Math.min(1,v/f)),C=0;_===0?C=.5/r:_===p&&(C=-.5/r);for(let e=0;e<=r;e++){let t=e/r,n=t*Math.PI*2,i=Math.sin(n),a=Math.cos(n);g.x=-b*a,g.y=y,g.z=b*i,o.push(g.x,g.y,g.z),h.set(-b*a,x,b*i),h.normalize(),s.push(h.x,h.y,h.z),c.push(t+C,S)}if(_>0){let e=(_-1)*m;for(let t=0;t<r;t++){let n=e+t,r=e+t+1,i=_*m+t,o=_*m+t+1;a.push(n,r,i),a.push(r,o,i)}}}this.setIndex(a),this.setAttribute(`position`,new J(o,3)),this.setAttribute(`normal`,new J(s,3)),this.setAttribute(`uv`,new J(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.height,t.capSegments,t.radialSegments,t.heightSegments)}},Vi=class e extends hr{constructor(e=1,t=1,n=1,r=32,i=1,a=!1,o=0,s=Math.PI*2){super(),this.type=`CylinderGeometry`,this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:i,openEnded:a,thetaStart:o,thetaLength:s};let c=this;r=Math.floor(r),i=Math.floor(i);let l=[],u=[],d=[],f=[],p=0,m=[],h=n/2,g=0;_(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(l),this.setAttribute(`position`,new J(u,3)),this.setAttribute(`normal`,new J(d,3)),this.setAttribute(`uv`,new J(f,2));function _(){let a=new W,_=new W,v=0,y=(t-e)/n;for(let c=0;c<=i;c++){let l=[],g=c/i,v=g*(t-e)+e;for(let e=0;e<=r;e++){let t=e/r,i=t*s+o,c=Math.sin(i),m=Math.cos(i);_.x=v*c,_.y=-g*n+h,_.z=v*m,u.push(_.x,_.y,_.z),a.set(c,y,m).normalize(),d.push(a.x,a.y,a.z),f.push(t,1-g),l.push(p++)}m.push(l)}for(let n=0;n<r;n++)for(let r=0;r<i;r++){let a=m[r][n],o=m[r+1][n],s=m[r+1][n+1],c=m[r][n+1];(e>0||r!==0)&&(l.push(a,o,c),v+=3),(t>0||r!==i-1)&&(l.push(o,s,c),v+=3)}c.addGroup(g,v,0),g+=v}function v(n){let i=p,a=new U,m=new W,_=0,v=n===!0?e:t,y=n===!0?1:-1;for(let e=1;e<=r;e++)u.push(0,h*y,0),d.push(0,y,0),f.push(.5,.5),p++;let b=p;for(let e=0;e<=r;e++){let t=e/r*s+o,n=Math.cos(t),i=Math.sin(t);m.x=v*i,m.y=h*y,m.z=v*n,u.push(m.x,m.y,m.z),d.push(0,y,0),a.x=n*.5+.5,a.y=i*.5*y+.5,f.push(a.x,a.y),p++}for(let e=0;e<r;e++){let t=i+e,r=b+e;n===!0?l.push(r,r+1,t):l.push(r+1,r,t),_+=3}c.addGroup(g,_,n===!0?1:2),g+=_}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Hi=class e extends Vi{constructor(e=1,t=1,n=32,r=1,i=!1,a=0,o=Math.PI*2){super(0,e,t,n,r,i,a,o),this.type=`ConeGeometry`,this.parameters={radius:e,height:t,radialSegments:n,heightSegments:r,openEnded:i,thetaStart:a,thetaLength:o}}static fromJSON(t){return new e(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Ui=class{constructor(){this.type=`Curve`,this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){l(`Curve: .getPoint() not implemented.`)}getPointAt(e,t){let n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],n,r=this.getPoint(0),i=0;t.push(0);for(let a=1;a<=e;a++)n=this.getPoint(a/e),i+=n.distanceTo(r),t.push(i),r=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){let n=this.getLengths(),r=0,i=n.length,a;a=t||e*n[i-1];let o=0,s=i-1,c;for(;o<=s;)if(r=Math.floor(o+(s-o)/2),c=n[r]-a,c<0)o=r+1;else if(c>0)s=r-1;else{s=r;break}if(r=s,n[r]===a)return r/(i-1);let l=n[r],u=n[r+1]-l,d=(a-l)/u;return(r+d)/(i-1)}getTangent(e,t){let n=1e-4,r=e-n,i=e+n;r<0&&(r=0),i>1&&(i=1);let a=this.getPoint(r),o=this.getPoint(i),s=t||(a.isVector2?new U:new W);return s.copy(o).sub(a).normalize(),s}getTangentAt(e,t){let n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){let n=new W,r=[],i=[],a=[],o=new W,s=new K;for(let t=0;t<=e;t++){let n=t/e;r[t]=this.getTangentAt(n,new W)}i[0]=new W,a[0]=new W;let c=Number.MAX_VALUE,l=Math.abs(r[0].x),u=Math.abs(r[0].y),d=Math.abs(r[0].z);l<=c&&(c=l,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(r[0],n).normalize(),i[0].crossVectors(r[0],o),a[0].crossVectors(r[0],i[0]);for(let t=1;t<=e;t++){if(i[t]=i[t-1].clone(),a[t]=a[t-1].clone(),o.crossVectors(r[t-1],r[t]),o.length()>2**-52){o.normalize();let e=Math.acos(p(r[t-1].dot(r[t]),-1,1));i[t].applyMatrix4(s.makeRotationAxis(o,e))}a[t].crossVectors(r[t],i[t])}if(t===!0){let t=Math.acos(p(i[0].dot(i[e]),-1,1));t/=e,r[0].dot(o.crossVectors(i[0],i[e]))>0&&(t=-t);for(let n=1;n<=e;n++)i[n].applyMatrix4(s.makeRotationAxis(r[n],t*n)),a[n].crossVectors(r[n],i[n])}return{tangents:r,normals:i,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.7,type:`Curve`,generator:`Curve.toJSON`}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},Wi=class{static triangulate(e,t,n=2){return ie(e,t,n)}},Gi=class e{static area(e){let t=e.length,n=0;for(let r=t-1,i=0;i<t;r=i++)n+=e[r].x*e[i].y-e[i].x*e[r].y;return n*.5}static isClockWise(t){return e.area(t)<0}static triangulateShape(e,t){let n=[],r=[],i=[];Fe(e),Ie(n,e);let a=e.length;t.forEach(Fe);for(let e=0;e<t.length;e++)r.push(a),a+=t[e].length,Ie(n,t[e]);let o=Wi.triangulate(n,r);for(let e=0;e<o.length;e+=3)i.push(o.slice(e,e+3));return i}},Ki=class e extends hr{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new W,d=new W,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new J(p,3)),this.setAttribute(`normal`,new J(m,3)),this.setAttribute(`uv`,new J(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},qi=class extends br{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type=`MeshStandardMaterial`,this.defines={STANDARD:``},this.color=new q(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new U(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $t,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:``},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Ji=class extends qi{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:``,PHYSICAL:``},this.type=`MeshPhysicalMaterial`,this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new U(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,`reflectivity`,{get:function(){return p(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new q(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new q(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new q(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:``,PHYSICAL:``},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}},Yi=class extends br{constructor(e){super(),this.isMeshPhongMaterial=!0,this.type=`MeshPhongMaterial`,this.color=new q(16777215),this.specular=new q(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new U(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $t,this.combine=0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Xi=class extends br{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type=`MeshLambertMaterial`,this.color=new q(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new U(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $t,this.combine=0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Zi=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},Qi=class extends Zi{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:dt,endingEnd:dt}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case ft:i=e,o=2*t-n;break;case pt:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case ft:a=e,s=2*n-t;break;case pt:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},$i=class extends Zi{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},ea=class extends Zi{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},ta=class extends Zi{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=(n-t)/(r-t),S,C,w,T,E;for(let e=0;e<8;e++){S=x*x,C=S*x,w=1-x,T=w*w,E=T*w;let e=E*t+3*T*x*g+3*w*S*y+C*r-n;if(Math.abs(e)<1e-10)break;let i=3*T*(g-t)+6*w*x*(y-g)+3*S*(r-y);if(Math.abs(i)<1e-10)break;x-=e/i,x=Math.max(0,Math.min(1,x))}i[p]=E*o+3*T*x*_+3*w*S*b+C*m}return i}},na=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=Be(t,this.TimeBufferType),this.values=Be(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Be(e.times,Array),values:Be(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new ea(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new $i(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Qi(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new ta(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case st:t=this.InterpolantFactoryMethodDiscrete;break;case ct:t=this.InterpolantFactoryMethodLinear;break;case lt:t=this.InterpolantFactoryMethodSmooth;break;case ut:t=this.InterpolantFactoryMethodBezier;break}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t);return l(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return st;case this.InterpolantFactoryMethodLinear:return ct;case this.InterpolantFactoryMethodSmooth:return lt;case this.InterpolantFactoryMethodBezier:return ut}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(u(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(u(`KeyframeTrack: Track is empty.`,this),e=!1);let o=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){u(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(o!==null&&o>r){u(`KeyframeTrack: Out of order keys.`,this,t,r,o),e=!1;break}o=r}if(r!==void 0&&a(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){u(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===lt,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0]))if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,r}},na.prototype.ValueTypeName=``,na.prototype.TimeBufferType=Float32Array,na.prototype.ValueBufferType=Float32Array,na.prototype.DefaultInterpolation=ct,ra=class extends na{constructor(e,t,n){super(e,t,n)}},ra.prototype.ValueTypeName=`bool`,ra.prototype.ValueBufferType=Array,ra.prototype.DefaultInterpolation=st,ra.prototype.InterpolantFactoryMethodLinear=void 0,ra.prototype.InterpolantFactoryMethodSmooth=void 0,ia=class extends na{constructor(e,t,n,r){super(e,t,n,r)}},ia.prototype.ValueTypeName=`color`,aa=class extends na{constructor(e,t,n,r){super(e,t,n,r)}},aa.prototype.ValueTypeName=`number`,oa=class extends Zi{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)kt.slerpFlat(i,0,a,c-o,a,c,s);return i}},sa=class extends na{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new oa(this.times,this.values,this.getValueSize(),e)}},sa.prototype.ValueTypeName=`quaternion`,sa.prototype.InterpolantFactoryMethodSmooth=void 0,ca=class extends na{constructor(e,t,n){super(e,t,n)}},ca.prototype.ValueTypeName=`string`,ca.prototype.ValueBufferType=Array,ca.prototype.DefaultInterpolation=st,ca.prototype.InterpolantFactoryMethodLinear=void 0,ca.prototype.InterpolantFactoryMethodSmooth=void 0,la=class extends na{constructor(e,t,n,r){super(e,t,n,r)}},la.prototype.ValueTypeName=`vector`,ua=class{constructor(e=``,t=-1,n=[],r=mt){this.name=e,this.tracks=n,this.duration=t,this.blendMode=r,this.uuid=f(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,r=1/(e.fps||1);for(let e=0,i=n.length;e!==i;++e)t.push(Ge(n[e]).scale(r));let i=new this(e.name,e.duration,t,e.blendMode);return i.uuid=e.uuid,i.userData=JSON.parse(e.userData||`{}`),i}static toJSON(e){let t=[],n=e.tracks,r={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let e=0,r=n.length;e!==r;++e)t.push(na.toJSON(n[e]));return r}static CreateFromMorphTargetSequence(e,t,n,r){let i=t.length,a=[];for(let e=0;e<i;e++){let o=[],s=[];o.push((e+i-1)%i,e,(e+1)%i),s.push(0,1,0);let c=Ve(o);o=He(o,1,c),s=He(s,1,c),!r&&o[0]===0&&(o.push(i),s.push(s[0])),a.push(new aa(`.morphTargetInfluences[`+t[e].name+`]`,o,s).scale(1/n))}return new this(e,-1,a)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let t=e;n=t.geometry&&t.geometry.animations||t.animations}for(let e=0;e<n.length;e++)if(n[e].name===t)return n[e];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let r={},i=/^([\w-]*?)([\d]+)$/;for(let t=0,n=e.length;t<n;t++){let n=e[t],a=n.name.match(i);if(a&&a.length>1){let e=a[1],t=r[e];t||(r[e]=t=[]),t.push(n)}}let a=[];for(let e in r)a.push(this.CreateFromMorphTargetSequence(e,r[e],t,n));return a}resetDuration(){let e=this.tracks,t=0;for(let n=0,r=e.length;n!==r;++n){let e=this.tracks[n];t=Math.max(t,e.times[e.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e&&=this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());let t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}},da={enabled:!1,files:{},add:function(e,t){this.enabled!==!1&&(Ke(e)||(this.files[e]=t))},get:function(e){if(this.enabled!==!1&&!Ke(e))return this.files[e]},remove:function(e){delete this.files[e]},clear:function(){this.files={}}},fa=class{constructor(e,t,n){let r=this,i=!1,a=0,o=0,s,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this._abortController=null,this.itemStart=function(e){o++,i===!1&&r.onStart!==void 0&&r.onStart(e,a,o),i=!0},this.itemEnd=function(e){a++,r.onProgress!==void 0&&r.onProgress(e,a,o),a===o&&(i=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(e){r.onError!==void 0&&r.onError(e)},this.resolveURL=function(e){return e=e.normalize(`NFC`),s?s(e):e},this.setURLModifier=function(e){return s=e,this},this.addHandler=function(e,t){return c.push(e,t),this},this.removeHandler=function(e){let t=c.indexOf(e);return t!==-1&&c.splice(t,2),this},this.getHandler=function(e){for(let t=0,n=c.length;t<n;t+=2){let n=c[t],r=c[t+1];if(n.global&&(n.lastIndex=0),n.test(e))return r}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||=new AbortController,this._abortController}},pa=new fa,ma=class{constructor(e){this.manager=e===void 0?pa:e,this.crossOrigin=`anonymous`,this.withCredentials=!1,this.path=``,this.resourcePath=``,this.requestHeader={},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}load(){}loadAsync(e,t){let n=this;return new Promise(function(r,i){n.load(e,r,t,i)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}},ma.DEFAULT_MATERIAL_NAME=`__DEFAULT`,ha={},ga=class extends Error{constructor(e,t){super(e),this.response=t}},_a=class extends ma{constructor(e){super(e),this.mimeType=``,this.responseType=``,this._abortController=new AbortController}load(e,t,n,r){e===void 0&&(e=``),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let i=da.get(`file:${e}`);if(i!==void 0){this.manager.itemStart(e),setTimeout(()=>{t&&t(i),this.manager.itemEnd(e)},0);return}if(ha[e]!==void 0){ha[e].push({onLoad:t,onProgress:n,onError:r});return}ha[e]=[],ha[e].push({onLoad:t,onProgress:n,onError:r});let a=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?`include`:`same-origin`,signal:typeof AbortSignal.any==`function`?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),o=this.mimeType,s=this.responseType;fetch(a).then(t=>{if(t.status===200||t.status===0){if(t.status===0&&l(`FileLoader: HTTP Status 0 received.`),typeof ReadableStream>`u`||t.body===void 0||t.body.getReader===void 0)return t;let n=ha[e],r=t.body.getReader(),i=t.headers.get(`X-File-Size`)||t.headers.get(`Content-Length`),a=i?parseInt(i):0,o=a!==0,s=0,c=new ReadableStream({start(e){t();function t(){r.read().then(({done:r,value:i})=>{if(r)e.close();else{s+=i.byteLength;let r=new ProgressEvent(`progress`,{lengthComputable:o,loaded:s,total:a});for(let e=0,t=n.length;e<t;e++){let t=n[e];t.onProgress&&t.onProgress(r)}e.enqueue(i),t()}},t=>{e.error(t)})}}});return new Response(c)}else throw new ga(`fetch for "${t.url}" responded with ${t.status}: ${t.statusText}`,t)}).then(e=>{switch(s){case`arraybuffer`:return e.arrayBuffer();case`blob`:return e.blob();case`document`:return e.text().then(e=>new DOMParser().parseFromString(e,o));case`json`:return e.json();default:if(o===``)return e.text();{let t=/charset="?([^;"\s]*)"?/i.exec(o),n=t&&t[1]?t[1].toLowerCase():void 0,r=new TextDecoder(n);return e.arrayBuffer().then(e=>r.decode(e))}}}).then(t=>{da.add(`file:${e}`,t);let n=ha[e];delete ha[e];for(let e=0,r=n.length;e<r;e++){let r=n[e];r.onLoad&&r.onLoad(t)}}).catch(t=>{let n=ha[e];if(n===void 0)throw this.manager.itemError(e),t;delete ha[e];for(let e=0,r=n.length;e<r;e++){let r=n[e];r.onError&&r.onError(t)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}},va=new WeakMap,ya=class extends ma{constructor(e){super(e)}load(e,t,n,r){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let i=this,a=da.get(`image:${e}`);if(a!==void 0){if(a.complete===!0)i.manager.itemStart(e),setTimeout(function(){t&&t(a),i.manager.itemEnd(e)},0);else{let e=va.get(a);e===void 0&&(e=[],va.set(a,e)),e.push({onLoad:t,onError:r})}return a}let s=o(`img`);function c(){u(),t&&t(this);let n=va.get(this)||[];for(let e=0;e<n.length;e++){let t=n[e];t.onLoad&&t.onLoad(this)}va.delete(this),i.manager.itemEnd(e)}function l(t){u(),r&&r(t),da.remove(`image:${e}`);let n=va.get(this)||[];for(let e=0;e<n.length;e++){let r=n[e];r.onError&&r.onError(t)}va.delete(this),i.manager.itemError(e),i.manager.itemEnd(e)}function u(){s.removeEventListener(`load`,c,!1),s.removeEventListener(`error`,l,!1)}return s.addEventListener(`load`,c,!1),s.addEventListener(`error`,l,!1),e.slice(0,5)!==`data:`&&this.crossOrigin!==void 0&&(s.crossOrigin=this.crossOrigin),da.add(`image:${e}`,s),i.manager.itemStart(e),s.src=e,s}},ba=class extends ma{constructor(e){super(e)}load(e,t,n,r){let i=this,a=new $r,o=new _a(this.manager);return o.setResponseType(`arraybuffer`),o.setRequestHeader(this.requestHeader),o.setPath(this.path),o.setWithCredentials(i.withCredentials),o.load(e,function(e){let n;try{n=i.parse(e)}catch(e){r===void 0?u(e):r(e);return}i._applyTexData(a,n),t&&t(a,n)},n,r),a}createDataTexture(e){let t=new $r;return this._applyTexData(t,this.parse(e)),t}_applyTexData(e,t){t.image===void 0?t.data!==void 0&&(e.image.width=t.width,e.image.height=t.height,e.image.data=t.data):e.image=t.image,e.wrapS=t.wrapS===void 0?Ye:t.wrapS,e.wrapT=t.wrapT===void 0?Ye:t.wrapT,e.magFilter=t.magFilter===void 0?et:t.magFilter,e.minFilter=t.minFilter===void 0?et:t.minFilter,e.anisotropy=t.anisotropy===void 0?1:t.anisotropy,t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.mipmaps!==void 0&&(e.mipmaps=t.mipmaps,e.minFilter=nt),t.mipmapCount===1&&(e.minFilter=et),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),e.needsUpdate=!0}},xa=class extends ma{constructor(e){super(e)}load(e,t,n,r){let i=new Ht,a=new ya(this.manager);return a.setCrossOrigin(this.crossOrigin),a.setPath(this.path),a.load(e,function(e){i.image=e,i.needsUpdate=!0,t!==void 0&&t(i)},n,r),i}},Sa=class extends _n{constructor(e,t=1){super(),this.isLight=!0,this.type=`Light`,this.color=new q(e),this.intensity=t}dispose(){this.dispatchEvent({type:`dispose`})}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},Ca=new K,wa=new W,Ta=new W,Ea=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new U(512,512),this.mapType=rt,this.map=null,this.mapPass=null,this.matrix=new K,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new yi,this._frameExtents=new U(1,1),this._viewportCount=1,this._viewports=[new Ut(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;wa.setFromMatrixPosition(e.matrixWorld),t.position.copy(wa),Ta.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ta),t.updateMatrixWorld(),Ca.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ca,t.coordinateSystem,t.reversedDepth),t.coordinateSystem===2001||t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Ca)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Da=new W,Oa=new kt,ka=new W,Aa=class extends _n{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new K,this.projectionMatrix=new K,this.projectionMatrixInverse=new K,this.coordinateSystem=bt,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Da,Oa,ka),ka.x===1&&ka.y===1&&ka.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Da,Oa,ka.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Da,Oa,ka),ka.x===1&&ka.y===1&&ka.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Da,Oa,ka.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},ja=new W,Ma=new U,Na=new U,Pa=class extends Aa{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=Dt*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Et*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Dt*2*Math.atan(Math.tan(Et*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ja.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ja.x,ja.y).multiplyScalar(-e/ja.z),ja.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ja.x,ja.y).multiplyScalar(-e/ja.z)}getViewSize(e,t){return this.getViewBounds(e,Ma,Na),t.subVectors(Na,Ma)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Et*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Fa=class extends Ea{constructor(){super(new Pa(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){let t=this.camera,n=Dt*2*e.angle*this.focus,r=this.mapSize.width/this.mapSize.height*this.aspect,i=e.distance||t.far;(n!==t.fov||r!==t.aspect||i!==t.far)&&(t.fov=n,t.aspect=r,t.far=i,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},Ia=class extends Sa{constructor(e,t,n=0,r=Math.PI/3,i=0,a=2){super(e,t),this.isSpotLight=!0,this.type=`SpotLight`,this.position.copy(_n.DEFAULT_UP),this.updateMatrix(),this.target=new _n,this.distance=n,this.angle=r,this.penumbra=i,this.decay=a,this.map=null,this.shadow=new Fa}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.map=e.map,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.angle=this.angle,t.object.decay=this.decay,t.object.penumbra=this.penumbra,t.object.target=this.target.uuid,this.map&&this.map.isTexture&&(t.object.map=this.map.toJSON(e).uuid),t.object.shadow=this.shadow.toJSON(),t}},La=class extends Ea{constructor(){super(new Pa(90,1,.5,500)),this.isPointLightShadow=!0}},Ra=class extends Sa{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type=`PointLight`,this.distance=n,this.decay=r,this.shadow=new La}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}},za=class extends Aa{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Ba=class extends Ea{constructor(){super(new za(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Va=class extends Sa{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type=`DirectionalLight`,this.position.copy(_n.DEFAULT_UP),this.updateMatrix(),this.target=new _n,this.shadow=new Ba}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}},Ha=class extends Sa{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type=`AmbientLight`}},Ua=class extends Sa{constructor(e,t,n=10,r=10){super(e,t),this.isRectAreaLight=!0,this.type=`RectAreaLight`,this.width=n,this.height=r}get power(){return this.intensity*this.width*this.height*Math.PI}set power(e){this.intensity=e/(this.width*this.height*Math.PI)}copy(e){return super.copy(e),this.width=e.width,this.height=e.height,this}toJSON(e){let t=super.toJSON(e);return t.object.width=this.width,t.object.height=this.height,t}},Wa=class{static extractUrlBase(e){let t=e.lastIndexOf(`/`);return t===-1?`./`:e.slice(0,t+1)}static resolveURL(e,t){return typeof e!=`string`||e===``?``:(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,`$1`)),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}},Ga=new WeakMap,Ka=class extends ma{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>`u`&&l(`ImageBitmapLoader: createImageBitmap() not supported.`),typeof fetch>`u`&&l(`ImageBitmapLoader: fetch() not supported.`),this.options={premultiplyAlpha:`none`},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,r){e===void 0&&(e=``),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let i=this,a=da.get(`image-bitmap:${e}`);if(a!==void 0){if(i.manager.itemStart(e),a.then){a.then(n=>{Ga.has(a)===!0?(r&&r(Ga.get(a)),i.manager.itemError(e),i.manager.itemEnd(e)):(t&&t(n),i.manager.itemEnd(e))});return}setTimeout(function(){t&&t(a),i.manager.itemEnd(e)},0);return}let o={};o.credentials=this.crossOrigin===`anonymous`?`same-origin`:`include`,o.headers=this.requestHeader,o.signal=typeof AbortSignal.any==`function`?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;let s=fetch(e,o).then(function(e){return e.blob()}).then(function(e){return createImageBitmap(e,Object.assign(i.options,{colorSpaceConversion:`none`}))}).then(function(n){da.add(`image-bitmap:${e}`,n),t&&t(n),i.manager.itemEnd(e)}).catch(function(t){r&&r(t),Ga.set(s,t),da.remove(`image-bitmap:${e}`),i.manager.itemError(e),i.manager.itemEnd(e)});da.add(`image-bitmap:${e}`,s),i.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}},qa=`\\[\\]\\.:\\/`,Ja=RegExp(`[`+qa+`]`,`g`),Ya=`[^`+qa+`]`,Xa=`[^`+qa.replace(`\\.`,``)+`]`,Za=`((?:WC+[\\/:])*)`.replace(`WC`,Ya),Qa=`(WCOD+)?`.replace(`WCOD`,Xa),$a=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,Ya),eo=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,Ya),to=RegExp(`^`+Za+Qa+$a+eo+`$`),no=[`material`,`materials`,`bones`,`map`],ro=class{constructor(e,t,n){let r=n||io.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},io=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(Ja,``)}static parseTrackName(e){let t=to.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);no.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){l(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){u(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){u(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){u(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){u(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){u(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){u(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){u(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;u(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){u(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){u(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}},io.Composite=ro,io.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},io.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},io.prototype.GetterByBindingType=[io.prototype._getValue_direct,io.prototype._getValue_array,io.prototype._getValue_arrayElement,io.prototype._getValue_toArray],io.prototype.SetterByBindingTypeAndVersioning=[[io.prototype._setValue_direct,io.prototype._setValue_direct_setNeedsUpdate,io.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[io.prototype._setValue_array,io.prototype._setValue_array_setNeedsUpdate,io.prototype._setValue_array_setMatrixWorldNeedsUpdate],[io.prototype._setValue_arrayElement,io.prototype._setValue_arrayElement_setNeedsUpdate,io.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[io.prototype._setValue_fromArray,io.prototype._setValue_fromArray_setNeedsUpdate,io.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]],class e{static{e.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`185`}})),typeof window<`u`&&(window.__THREE__?l(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`185`)})),Y,X,oo,so,co,lo=t((()=>{
/**
* @license
* Copyright 2010-2026 Three.js Authors
* SPDX-License-Identifier: MIT
*/
ao(),Y={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},X={common:{diffuse:{value:new q(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new G},alphaMap:{value:null},alphaMapTransform:{value:new G},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new G}},envmap:{envMap:{value:null},envMapRotation:{value:new G},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new G}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new G}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new G},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new G},normalScale:{value:new U(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new G},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new G}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new G}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new G}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new q(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new W},probesMax:{value:new W},probesResolution:{value:new W}},points:{diffuse:{value:new q(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new G},alphaTest:{value:0},uvTransform:{value:new G}},sprite:{diffuse:{value:new q(16777215)},opacity:{value:1},center:{value:new U(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new G},alphaMap:{value:null},alphaMapTransform:{value:new G},alphaTest:{value:0}}},oo={basic:{uniforms:Re([X.common,X.specularmap,X.envmap,X.aomap,X.lightmap,X.fog]),vertexShader:Y.meshbasic_vert,fragmentShader:Y.meshbasic_frag},lambert:{uniforms:Re([X.common,X.specularmap,X.envmap,X.aomap,X.lightmap,X.emissivemap,X.bumpmap,X.normalmap,X.displacementmap,X.fog,X.lights,{emissive:{value:new q(0)},envMapIntensity:{value:1}}]),vertexShader:Y.meshlambert_vert,fragmentShader:Y.meshlambert_frag},phong:{uniforms:Re([X.common,X.specularmap,X.envmap,X.aomap,X.lightmap,X.emissivemap,X.bumpmap,X.normalmap,X.displacementmap,X.fog,X.lights,{emissive:{value:new q(0)},specular:{value:new q(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Y.meshphong_vert,fragmentShader:Y.meshphong_frag},standard:{uniforms:Re([X.common,X.envmap,X.aomap,X.lightmap,X.emissivemap,X.bumpmap,X.normalmap,X.displacementmap,X.roughnessmap,X.metalnessmap,X.fog,X.lights,{emissive:{value:new q(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Y.meshphysical_vert,fragmentShader:Y.meshphysical_frag},toon:{uniforms:Re([X.common,X.aomap,X.lightmap,X.emissivemap,X.bumpmap,X.normalmap,X.displacementmap,X.gradientmap,X.fog,X.lights,{emissive:{value:new q(0)}}]),vertexShader:Y.meshtoon_vert,fragmentShader:Y.meshtoon_frag},matcap:{uniforms:Re([X.common,X.bumpmap,X.normalmap,X.displacementmap,X.fog,{matcap:{value:null}}]),vertexShader:Y.meshmatcap_vert,fragmentShader:Y.meshmatcap_frag},points:{uniforms:Re([X.points,X.fog]),vertexShader:Y.points_vert,fragmentShader:Y.points_frag},dashed:{uniforms:Re([X.common,X.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Y.linedashed_vert,fragmentShader:Y.linedashed_frag},depth:{uniforms:Re([X.common,X.displacementmap]),vertexShader:Y.depth_vert,fragmentShader:Y.depth_frag},normal:{uniforms:Re([X.common,X.bumpmap,X.normalmap,X.displacementmap,{opacity:{value:1}}]),vertexShader:Y.meshnormal_vert,fragmentShader:Y.meshnormal_frag},sprite:{uniforms:Re([X.sprite,X.fog]),vertexShader:Y.sprite_vert,fragmentShader:Y.sprite_frag},background:{uniforms:{uvTransform:{value:new G},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Y.background_vert,fragmentShader:Y.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new G}},vertexShader:Y.backgroundCube_vert,fragmentShader:Y.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Y.cube_vert,fragmentShader:Y.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Y.equirect_vert,fragmentShader:Y.equirect_frag},distance:{uniforms:Re([X.common,X.displacementmap,{referencePosition:{value:new W},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Y.distance_vert,fragmentShader:Y.distance_frag},shadow:{uniforms:Re([X.lights,X.fog,{color:{value:new q(0)},opacity:{value:1}}]),vertexShader:Y.shadow_vert,fragmentShader:Y.shadow_frag}},oo.physical={uniforms:Re([oo.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new G},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new G},clearcoatNormalScale:{value:new U(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new G},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new G},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new G},sheen:{value:0},sheenColor:{value:new q(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new G},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new G},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new G},transmissionSamplerSize:{value:new U},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new G},attenuationDistance:{value:0},attenuationColor:{value:new q(0)},specularColor:{value:new q(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new G},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new G},anisotropyVector:{value:new U},anisotropyMap:{value:null},anisotropyMapTransform:{value:new G}}]),vertexShader:Y.meshphysical_vert,fragmentShader:Y.meshphysical_frag},so=new G,so.set(-1,0,0,0,1,0,0,0,1),co=new G,co.set(-1,0,0,0,1,0,0,0,1),new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183])})),uo=n((e=>{function t(e,t,n){if(n===void 0&&(n=Array.prototype),e&&typeof n.find==`function`)return n.find.call(e,t);for(var i=0;i<e.length;i++)if(r(e,i)){var a=e[i];if(t.call(void 0,a,i,e))return a}}function n(e,t){return t===void 0&&(t=Object),t&&typeof t.getOwnPropertyDescriptors==`function`&&(e=t.create(null,t.getOwnPropertyDescriptors(e))),t&&typeof t.freeze==`function`?t.freeze(e):e}function r(e,t){return Object.prototype.hasOwnProperty.call(e,t)}function i(e,t){if(typeof e!=`object`||!e)throw TypeError(`target is not an object`);for(var n in t)r(t,n)&&(e[n]=t[n]);return e}var a=n({allowfullscreen:!0,async:!0,autofocus:!0,autoplay:!0,checked:!0,controls:!0,default:!0,defer:!0,disabled:!0,formnovalidate:!0,hidden:!0,ismap:!0,itemscope:!0,loop:!0,multiple:!0,muted:!0,nomodule:!0,novalidate:!0,open:!0,playsinline:!0,readonly:!0,required:!0,reversed:!0,selected:!0});function o(e){return r(a,e.toLowerCase())}var s=n({area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function c(e){return r(s,e.toLowerCase())}var l=n({script:!1,style:!1,textarea:!0,title:!0});function u(e){var t=e.toLowerCase();return r(l,t)&&!l[t]}function d(e){var t=e.toLowerCase();return r(l,t)&&l[t]}function f(e){return e===m.HTML}function p(e){return f(e)||e===m.XML_XHTML_APPLICATION}var m=n({HTML:`text/html`,XML_APPLICATION:`application/xml`,XML_TEXT:`text/xml`,XML_XHTML_APPLICATION:`application/xhtml+xml`,XML_SVG_IMAGE:`image/svg+xml`}),h=Object.keys(m).map(function(e){return m[e]});function g(e){return h.indexOf(e)>-1}var _=n({HTML:`http://www.w3.org/1999/xhtml`,SVG:`http://www.w3.org/2000/svg`,XML:`http://www.w3.org/XML/1998/namespace`,XMLNS:`http://www.w3.org/2000/xmlns/`});e.assign=i,e.find=t,e.freeze=n,e.HTML_BOOLEAN_ATTRIBUTES=a,e.HTML_RAW_TEXT_ELEMENTS=l,e.HTML_VOID_ELEMENTS=s,e.hasDefaultHTMLNamespace=p,e.hasOwn=r,e.isHTMLBooleanAttribute=o,e.isHTMLRawTextElement=u,e.isHTMLEscapableRawTextElement=d,e.isHTMLMimeType=f,e.isHTMLVoidElement=c,e.isValidMimeType=g,e.MIME_TYPE=m,e.NAMESPACE=_})),fo=n((e=>{var t=uo();function n(e,t){e.prototype=Object.create(Error.prototype,{constructor:{value:e},name:{value:e.name,enumerable:!0,writable:t}})}var r=t.freeze({Error:`Error`,IndexSizeError:`IndexSizeError`,DomstringSizeError:`DomstringSizeError`,HierarchyRequestError:`HierarchyRequestError`,WrongDocumentError:`WrongDocumentError`,InvalidCharacterError:`InvalidCharacterError`,NoDataAllowedError:`NoDataAllowedError`,NoModificationAllowedError:`NoModificationAllowedError`,NotFoundError:`NotFoundError`,NotSupportedError:`NotSupportedError`,InUseAttributeError:`InUseAttributeError`,InvalidStateError:`InvalidStateError`,SyntaxError:`SyntaxError`,InvalidModificationError:`InvalidModificationError`,NamespaceError:`NamespaceError`,InvalidAccessError:`InvalidAccessError`,ValidationError:`ValidationError`,TypeMismatchError:`TypeMismatchError`,SecurityError:`SecurityError`,NetworkError:`NetworkError`,AbortError:`AbortError`,URLMismatchError:`URLMismatchError`,QuotaExceededError:`QuotaExceededError`,TimeoutError:`TimeoutError`,InvalidNodeTypeError:`InvalidNodeTypeError`,DataCloneError:`DataCloneError`,EncodingError:`EncodingError`,NotReadableError:`NotReadableError`,UnknownError:`UnknownError`,ConstraintError:`ConstraintError`,DataError:`DataError`,TransactionInactiveError:`TransactionInactiveError`,ReadOnlyError:`ReadOnlyError`,VersionError:`VersionError`,OperationError:`OperationError`,NotAllowedError:`NotAllowedError`,OptOutError:`OptOutError`}),i=Object.keys(r);function a(e){return typeof e==`number`&&e>=1&&e<=25}function o(e){return typeof e==`string`&&e.substring(e.length-r.Error.length)===r.Error}function s(e,t){a(e)?(this.name=i[e],this.message=t||``):(this.message=e,this.name=o(t)?t:r.Error),Error.captureStackTrace&&Error.captureStackTrace(this,s)}n(s,!0),Object.defineProperties(s.prototype,{code:{enumerable:!0,get:function(){var e=i.indexOf(this.name);return a(e)?e:0}}});for(var c={INDEX_SIZE_ERR:1,DOMSTRING_SIZE_ERR:2,HIERARCHY_REQUEST_ERR:3,WRONG_DOCUMENT_ERR:4,INVALID_CHARACTER_ERR:5,NO_DATA_ALLOWED_ERR:6,NO_MODIFICATION_ALLOWED_ERR:7,NOT_FOUND_ERR:8,NOT_SUPPORTED_ERR:9,INUSE_ATTRIBUTE_ERR:10,INVALID_STATE_ERR:11,SYNTAX_ERR:12,INVALID_MODIFICATION_ERR:13,NAMESPACE_ERR:14,INVALID_ACCESS_ERR:15,VALIDATION_ERR:16,TYPE_MISMATCH_ERR:17,SECURITY_ERR:18,NETWORK_ERR:19,ABORT_ERR:20,URL_MISMATCH_ERR:21,QUOTA_EXCEEDED_ERR:22,TIMEOUT_ERR:23,INVALID_NODE_TYPE_ERR:24,DATA_CLONE_ERR:25},l=Object.entries(c),u=0;u<l.length;u++){var d=l[u][0];s[d]=l[u][1]}function f(e,t,n){this.message=e,this.locator=t,this.cause=n,Error.captureStackTrace&&Error.captureStackTrace(this,f)}n(f),e.DOMException=s,e.DOMExceptionName=r,e.ExceptionCode=c,e.ParseError=f})),po=n((e=>{function t(e){try{typeof e!=`function`&&(e=RegExp);var t=new e(`𝌆`,`u`).exec(`𝌆`);return!!t&&t[0].length===2}catch{}return!1}var n=t();function r(e){if(e.source[0]!==`[`)throw Error(e+` can not be used with chars`);return e.source.slice(1,e.source.lastIndexOf(`]`))}function i(e,t){if(e.source[0]!==`[`)throw Error(`/`+e.source+`/ can not be used with chars_without`);if(!t||typeof t!=`string`)throw Error(JSON.stringify(t)+` is not a valid search`);if(e.source.indexOf(t)===-1)throw Error(`"`+t+`" is not is /`+e.source+`/`);if(t===`-`&&e.source.indexOf(t)!==1)throw Error(`"`+t+`" is not at the first postion of /`+e.source+`/`);return new RegExp(e.source.replace(t,``),n?`u`:``)}function a(e){var t=this;return new RegExp(Array.prototype.slice.call(arguments).map(function(e){var n=typeof e==`string`;if(n&&t===void 0&&e===`|`)throw Error("use regg instead of reg to wrap expressions with `|`!");return n?e:e.source}).join(``),n?`u`:``)}function o(e){if(arguments.length===0)throw Error(`no parameters provided`);return a.apply(o,[`(?:`].concat(Array.prototype.slice.call(arguments),[`)`]))}var s=`�`,c=/[-\x09\x0A\x0D\x20-\x2C\x2E-\uD7FF\uE000-\uFFFD]/;n&&(c=a(`[`,r(c),`\\u{10000}-\\u{10FFFF}`,`]`));var l=RegExp(`[^`+r(c)+`]`,n?`u`:``),u=/[\x20\x09\x0D\x0A]/,d=r(u),f=a(u,`+`),p=a(u,`*`),m=/[:_a-zA-Z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;n&&(m=a(`[`,r(m),`\\u{10000}-\\u{10FFFF}`,`]`));var h=a(`[`,r(m),r(/[-.0-9\xB7]/),r(/[\u0300-\u036F\u203F-\u2040]/),`]`),g=a(m,h,`*`),_=a(`^`,g,`$`),v=a(h,`+`),y=o(a(`&`,g,`;`),`|`,o(/&#[0-9]+;|&#x[0-9a-fA-F]+;/)),b=a(`%`,g,`;`),x=o(a(`"`,o(/[^%&"]/,`|`,b,`|`,y),`*`,`"`),`|`,a(`'`,o(/[^%&']/,`|`,b,`|`,y),`*`,`'`)),S=o(`"`,o(/[^<&"]/,`|`,y),`*`,`"`,`|`,`'`,o(/[^<&']/,`|`,y),`*`,`'`),C=a(i(m,`:`),i(h,`:`),`*`),w=a(`^`,C,`$`),T=a(C,o(`:`,C),`?`),E=a(`^`,T,`$`),D=a(`(`,T,`)`),O=o(/"[^"]*"|'[^']*'/),ee=a(/^<\?/,`(`,g,`)`,o(f,`(?!`,u,`)(`,c,`*?)`),`?`,/\?>/),k=/[\x20\x0D\x0Aa-zA-Z0-9-'()+,./:=?;!*#@$_%]/,te=o(`"`,k,`*"`,`|`,`'`,i(k,`'`),`*'`),A=`<!--`,j=`-->`,ne=a(A,o(i(c,`-`),`|`,a(`-`,i(c,`-`))),`*`,j),M=`#PCDATA`,N=o(`EMPTY`,`|`,`ANY`,`|`,o(a(/\(/,p,M,o(p,/\|/,p,T),`*`,p,/\)\*/),`|`,a(/\(/,p,M,p,/\)/)),`|`,a(/\([^>]+\)/,/[?*+]?/)),P=a(`<!ELEMENT`,f,o(T,`|`,b),f,o(N,`|`,b),p,`>`),F=a(`<!ATTLIST`,f,g,o(f,g,f,o(/CDATA|ID|IDREF|IDREFS|ENTITY|ENTITIES|NMTOKEN|NMTOKENS/,`|`,o(a(`NOTATION`,f,/\(/,p,g,o(p,/\|/,p,g),`*`,p,/\)/),`|`,a(/\(/,p,v,o(p,/\|/,p,v),`*`,p,/\)/))),f,o(/#REQUIRED|#IMPLIED/,`|`,o(o(`#FIXED`,f),`?`,S))),`*`,p,`>`),I=`about:legacy-compat`,re=o(`"`+I+`"`,`|`,`'`+I+`'`),L=`SYSTEM`,R=`PUBLIC`,z=o(o(L,f,O),`|`,o(R,f,te,f,O)),ie=a(`^`,o(o(L,f,`(?<SystemLiteralOnly>`,O,`)`),`|`,o(R,f,`(?<PubidLiteral>`,te,`)`,f,`(?<SystemLiteral>`,O,`)`))),ae=a(`^`,te,`$`),oe=a(`^`,O,`$`),se=o(x,`|`,o(z,o(f,`NDATA`,f,g),`?`)),ce=`<!ENTITY`,le=o(a(ce,f,g,f,se,p,`>`),`|`,a(ce,f,`%`,f,g,f,o(x,`|`,z),p,`>`)),ue=a(`<!NOTATION`,f,g,f,o(z,`|`,a(R,f,te)),p,`>`),de=a(p,`=`,p),fe=/1[.]\d+/,B=a(f,`version`,de,o(`'`,fe,`'`,`|`,`"`,fe,`"`)),pe=/[A-Za-z][-A-Za-z0-9._]*/,me=a(/^<\?xml/,B,o(f,`encoding`,de,o(`"`,pe,`"`,`|`,`'`,pe,`'`)),`?`,o(f,`standalone`,de,o(`'`,o(`yes`,`|`,`no`),`'`,`|`,`"`,o(`yes`,`|`,`no`),`"`)),`?`,p,/\?>/),he=`<!DOCTYPE`,ge=`<![CDATA[`,_e=`]]>`,ve=a(/<!\[CDATA\[/,a(c,`*?`,/\]\]>/));e.chars=r,e.chars_without=i,e.detectUnicodeSupport=t,e.reg=a,e.regg=o,e.ABOUT_LEGACY_COMPAT=I,e.ABOUT_LEGACY_COMPAT_SystemLiteral=re,e.AttlistDecl=F,e.CDATA_START=ge,e.CDATA_END=_e,e.CDSect=ve,e.Char=c,e.Comment=ne,e.COMMENT_START=A,e.COMMENT_END=j,e.DOCTYPE_DECL_START=he,e.elementdecl=P,e.EntityDecl=le,e.EntityValue=x,e.ExternalID=z,e.ExternalID_match=ie,e.Name=g,e.Name_exact=_,e.NCName_exact=w,e.NotationDecl=ue,e.Reference=y,e.PEReference=b,e.PI=ee,e.PUBLIC=R,e.PubidLiteral=te,e.PubidLiteral_match=ae,e.QName=T,e.QName_exact=E,e.QName_group=D,e.S=f,e.SChar_s=d,e.S_OPT=p,e.SYSTEM=L,e.SystemLiteral=O,e.SystemLiteral_match=oe,e.InvalidChar=l,e.UNICODE_REPLACEMENT_CHARACTER=s,e.UNICODE_SUPPORT=n,e.XMLDecl=me})),mo=n((e=>{var t=uo(),n=t.find,r=t.hasDefaultHTMLNamespace,i=t.hasOwn,a=t.isHTMLMimeType,o=t.isHTMLRawTextElement,s=t.isHTMLVoidElement,c=t.MIME_TYPE,l=t.NAMESPACE,u=Symbol(),d=fo(),f=d.DOMException,p=d.DOMExceptionName,m=po();function h(e){if(e!==u)throw TypeError(`Illegal constructor`)}function g(e){return e!==``}function _(e){return e?e.split(/[\t\n\f\r ]+/).filter(g):[]}function v(e,t){return i(e,t)||(e[t]=!0),e}function y(e){if(!e)return[];var t=_(e);return Object.keys(t.reduce(v,{}))}function b(e){return function(t){return e&&e.indexOf(t)!==-1}}function x(e){if(!m.QName_exact.test(e))throw new f(f.INVALID_CHARACTER_ERR,`invalid character in qualified name "`+e+`"`)}function S(e,n){x(n),e||=null;var r=null,i=n;if(n.indexOf(`:`)>=0){var a=n.split(`:`);r=a[0],i=a[1]}if(r!==null&&e===null)throw new f(f.NAMESPACE_ERR,`prefix is non-null and namespace is null`);if(r===`xml`&&e!==t.NAMESPACE.XML)throw new f(f.NAMESPACE_ERR,`prefix is "xml" and namespace is not the XML namespace`);if((r===`xmlns`||n===`xmlns`)&&e!==t.NAMESPACE.XMLNS)throw new f(f.NAMESPACE_ERR,`either qualifiedName or prefix is "xmlns" and namespace is not the XMLNS namespace`);if(e===t.NAMESPACE.XMLNS&&r!==`xmlns`&&n!==`xmlns`)throw new f(f.NAMESPACE_ERR,`namespace is the XMLNS namespace and neither qualifiedName nor prefix is "xmlns"`);return[e,r,i]}function C(e,t){for(var n in e)i(e,n)&&(t[n]=e[n])}function w(e,t){var n=e.prototype;if(!(n instanceof t)){function r(){}r.prototype=t.prototype,r=new r,C(n,r),e.prototype=n=r}n.constructor!=e&&(typeof e!=`function`&&console.error(`unknown Class:`+e),n.constructor=e)}var T={},E=T.ELEMENT_NODE=1,D=T.ATTRIBUTE_NODE=2,O=T.TEXT_NODE=3,ee=T.CDATA_SECTION_NODE=4,k=T.ENTITY_REFERENCE_NODE=5,te=T.ENTITY_NODE=6,A=T.PROCESSING_INSTRUCTION_NODE=7,j=T.COMMENT_NODE=8,ne=T.DOCUMENT_NODE=9,M=T.DOCUMENT_TYPE_NODE=10,N=T.DOCUMENT_FRAGMENT_NODE=11,P=T.NOTATION_NODE=12,F=t.freeze({DOCUMENT_POSITION_DISCONNECTED:1,DOCUMENT_POSITION_PRECEDING:2,DOCUMENT_POSITION_FOLLOWING:4,DOCUMENT_POSITION_CONTAINS:8,DOCUMENT_POSITION_CONTAINED_BY:16,DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:32});function I(e,t){if(t.length<e.length)return I(t,e);var n=null;for(var r in e){if(e[r]!==t[r])return n;n=e[r]}return n}function re(e){return e.guid||=Math.random(),e.guid}function L(){}L.prototype={length:0,item:function(e){return e>=0&&e<this.length?this[e]:null},toString:function(e){for(var t=typeof e==`function`?{requireWellFormed:!1,splitCDATASections:!0,nodeFilter:e}:e?{requireWellFormed:!!e.requireWellFormed,splitCDATASections:e.splitCDATASections!==!1,nodeFilter:e.nodeFilter||null}:{requireWellFormed:!1,splitCDATASections:!0,nodeFilter:null},n=[],r=0;r<this.length;r++)qe(this[r],n,null,t);return n.join(``)},filter:function(e){return Array.prototype.filter.call(this,e)},indexOf:function(e){return Array.prototype.indexOf.call(this,e)}},L.prototype[Symbol.iterator]=function(){var e=this,t=0;return{next:function(){return t<e.length?{value:e[t++],done:!1}:{done:!0}},return:function(){return{done:!0}}}};function R(e,t){this._node=e,this._refresh=t,z(this)}function z(e){var t=e._node._inc||e._node.ownerDocument._inc;if(e._inc!==t){var n=e._refresh(e._node);if(Xe(e,`length`,n.length),!e.$$length||n.length<e.$$length)for(var r=n.length;r in e;r++)i(e,r)&&delete e[r];C(n,e),e._inc=t}}R.prototype.item=function(e){return z(this),this[e]||null},w(R,L);function ie(){this._nsIndex=Object.create(null),this._noNsIndex=Object.create(null)}function ae(e,t){for(var n=0;n<e.length;){if(e[n]===t)return n;n++}}function oe(e,t,n){if(!t)return e._noNsIndex;var r=e._nsIndex[t];return!r&&n&&(r=e._nsIndex[t]=Object.create(null)),r}function se(e,t,n){var r=oe(e,t,!1);return r&&r[n]||null}function ce(e,t){oe(e,t.namespaceURI,!0)[t.localName]=t}function le(e,t){var n=oe(e,t.namespaceURI,!1);n&&delete n[t.localName]}function ue(e,t,n,r){if(r?t[ae(t,r)]=n:(t[t.length]=n,t.length++),ce(t,n),e){n.ownerElement=e;var i=e.ownerDocument;i&&(r&&ve(i,e,r),_e(i,e,n))}}function de(e,t,n){var r=ae(t,n);if(r>=0){for(var i=t.length-1;r<=i;)t[r]=t[++r];if(t.length=i,le(t,n),e){var a=e.ownerDocument;a&&ve(a,e,n),n.ownerElement=null}}}ie.prototype={length:0,item:L.prototype.item,getNamedItem:function(e){this._ownerElement&&this._ownerElement._isInHTMLDocumentAndNamespace()&&(e=e.toLowerCase());for(var t=0;t<this.length;){var n=this[t];if(n.nodeName===e)return n;t++}return null},setNamedItem:function(e){var t=e.ownerElement;if(t&&t!==this._ownerElement)throw new f(f.INUSE_ATTRIBUTE_ERR);var n=se(this,e.namespaceURI,e.localName);return n===e?e:(ue(this._ownerElement,this,e,n),n)},setNamedItemNS:function(e){return this.setNamedItem(e)},removeNamedItem:function(e){var t=this.getNamedItem(e);if(!t)throw new f(f.NOT_FOUND_ERR,e);return de(this._ownerElement,this,t),t},removeNamedItemNS:function(e,t){var n=this.getNamedItemNS(e,t);if(!n)throw new f(f.NOT_FOUND_ERR,e?e+` : `+t:t);return de(this._ownerElement,this,n),n},getNamedItemNS:function(e,t){e||=null;for(var n=0;n<this.length;){var r=this[n];if(r.localName===t&&r.namespaceURI===e)return r;n++}return null}},ie.prototype[Symbol.iterator]=function(){var e=this,t=0;return{next:function(){return t<e.length?{value:e[t++],done:!1}:{done:!0}},return:function(){return{done:!0}}}};function fe(){}fe.prototype={hasFeature:function(e,t){return!0},createDocument:function(e,t,n){var r=c.XML_APPLICATION;e===l.HTML?r=c.XML_XHTML_APPLICATION:e===l.SVG&&(r=c.XML_SVG_IMAGE);var i=new ge(u,{contentType:r});if(i.implementation=this,i.childNodes=new L,i.doctype=n||null,n&&i.appendChild(n),t){var a=i.createElementNS(e,t);i.appendChild(a)}return i},createDocumentType:function(e,t,n,r){x(e);var i=new Le(u);return i.name=e,i.nodeName=e,i.publicId=t||``,i.systemId=n||``,i.internalSubset=r||``,i.childNodes=new L,i},createHTMLDocument:function(e){var t=new ge(u,{contentType:c.HTML});if(t.implementation=this,t.childNodes=new L,e!==!1){t.doctype=this.createDocumentType(`html`),t.doctype.ownerDocument=t,t.appendChild(t.doctype);var n=t.createElement(`html`);t.appendChild(n);var r=t.createElement(`head`);if(n.appendChild(r),typeof e==`string`){var i=t.createElement(`title`);i.appendChild(t.createTextNode(e)),r.appendChild(i)}n.appendChild(t.createElement(`body`))}return t}};function B(e){h(e)}B.prototype={firstChild:null,lastChild:null,previousSibling:null,nextSibling:null,parentNode:null,get parentElement(){return this.parentNode&&this.parentNode.nodeType===this.ELEMENT_NODE?this.parentNode:null},childNodes:null,ownerDocument:null,nodeValue:null,namespaceURI:null,prefix:null,localName:null,baseURI:`about:blank`,get isConnected(){var e=this.getRootNode();return e&&e.nodeType===e.DOCUMENT_NODE},contains:function(e){if(!e)return!1;var t=e;do{if(this===t)return!0;t=t.parentNode}while(t);return!1},getRootNode:function(e){var t=this;do{if(!t.parentNode)return t;t=t.parentNode}while(t)},isEqualNode:function(e){if(!e)return!1;for(var t=[{node:this,other:e}];t.length>0;){var n=t.pop(),r=n.node,i=n.other;if(r.nodeType!==i.nodeType)return!1;switch(r.nodeType){case r.DOCUMENT_TYPE_NODE:if(r.name!==i.name||r.publicId!==i.publicId||r.systemId!==i.systemId)return!1;break;case r.ELEMENT_NODE:if(r.namespaceURI!==i.namespaceURI||r.prefix!==i.prefix||r.localName!==i.localName||r.attributes.length!==i.attributes.length)return!1;for(var a=0;a<r.attributes.length;a++){var o=r.attributes.item(a),s=i.getAttributeNodeNS(o.namespaceURI,o.localName);if(!s)return!1;t.push({node:o,other:s})}break;case r.ATTRIBUTE_NODE:if(r.namespaceURI!==i.namespaceURI||r.localName!==i.localName||r.value!==i.value)return!1;break;case r.PROCESSING_INSTRUCTION_NODE:if(r.target!==i.target||r.data!==i.data)return!1;break;case r.TEXT_NODE:case r.CDATA_SECTION_NODE:case r.COMMENT_NODE:if(r.data!==i.data)return!1;break}if(r.childNodes.length!==i.childNodes.length)return!1;for(var a=r.childNodes.length-1;a>=0;a--)t.push({node:r.childNodes[a],other:i.childNodes[a]})}return!0},isSameNode:function(e){return this===e},insertBefore:function(e,t){return Ae(this,e,t)},replaceChild:function(e,t){Ae(this,e,t,ke),t&&this.removeChild(t)},removeChild:function(e){return be(this,e)},appendChild:function(e){return this.insertBefore(e,null)},hasChildNodes:function(){return this.firstChild!=null},cloneNode:function(e){return Ye(this.ownerDocument||this,this,e)},normalize:function(){he(this,null,{enter:function(e){for(var t=e.firstChild;t;){var n=t.nextSibling;if(n!==null&&n.nodeType===O&&t.nodeType===O){for(var r=[],i=n;i!==null&&i.nodeType===O;)r.push(i.data),i=i.nextSibling;for(var a=t.nextSibling;a!==i;){var o=a.nextSibling;a.parentNode=null,a.previousSibling=null,a.nextSibling=null,a=o}t.nextSibling=i,i===null?e.lastChild=t:i.previousSibling=t,t.appendData(r.join(``)),ye(e.ownerDocument,e),t=i}else t=n}return!0}})},isSupported:function(e,t){return this.ownerDocument.implementation.hasFeature(e,t)},lookupPrefix:function(e){for(var t=this;t;){var n=t._nsMap;if(n){for(var r in n)if(i(n,r)&&n[r]===e)return r}t=t.nodeType==D?t.ownerDocument:t.parentNode}return null},lookupNamespaceURI:function(e){for(var t=this;t;){var n=t._nsMap;if(n&&i(n,e))return n[e];t=t.nodeType==D?t.ownerDocument:t.parentNode}return null},isDefaultNamespace:function(e){return this.lookupPrefix(e)==null},compareDocumentPosition:function(e){if(this===e)return 0;var t=e,n=this,r=null,i=null;if(t instanceof Me&&(r=t,t=r.ownerElement),n instanceof Me&&(i=n,n=i.ownerElement,r&&t&&n===t))for(var a=0,o;o=n.attributes[a];a++){if(o===r)return F.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC+F.DOCUMENT_POSITION_PRECEDING;if(o===i)return F.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC+F.DOCUMENT_POSITION_FOLLOWING}if(!t||!n||n.ownerDocument!==t.ownerDocument)return F.DOCUMENT_POSITION_DISCONNECTED+F.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC+(re(n.ownerDocument)>re(t.ownerDocument)?F.DOCUMENT_POSITION_FOLLOWING:F.DOCUMENT_POSITION_PRECEDING);if(i&&t===n)return F.DOCUMENT_POSITION_CONTAINS+F.DOCUMENT_POSITION_PRECEDING;if(r&&t===n)return F.DOCUMENT_POSITION_CONTAINED_BY+F.DOCUMENT_POSITION_FOLLOWING;for(var s=[],c=t.parentNode;c;){if(!i&&c===n)return F.DOCUMENT_POSITION_CONTAINED_BY+F.DOCUMENT_POSITION_FOLLOWING;s.push(c),c=c.parentNode}s.reverse();for(var l=[],u=n.parentNode;u;){if(!r&&u===t)return F.DOCUMENT_POSITION_CONTAINS+F.DOCUMENT_POSITION_PRECEDING;l.push(u),u=u.parentNode}l.reverse();var d=I(s,l);for(var f in d.childNodes){var p=d.childNodes[f];if(p===n)return F.DOCUMENT_POSITION_FOLLOWING;if(p===t)return F.DOCUMENT_POSITION_PRECEDING;if(l.indexOf(p)>=0)return F.DOCUMENT_POSITION_FOLLOWING;if(s.indexOf(p)>=0)return F.DOCUMENT_POSITION_PRECEDING}return 0}};function pe(e){return e==`<`&&`&lt;`||e==`>`&&`&gt;`||e==`&`&&`&amp;`||e==`"`&&`&quot;`||`&#`+e.charCodeAt()+`;`}C(T,B),C(T,B.prototype),C(F,B),C(F,B.prototype);function me(e,t){he(e,null,{enter:function(e){return t(e)?he.STOP:!0}})}function he(e,t,n){for(var r=[{node:e,context:t,phase:he.ENTER}];r.length>0;){var i=r.pop();if(i.phase===he.ENTER){var a=n.enter(i.node,i.context);if(a===he.STOP)return he.STOP;if(r.push({node:i.node,context:a,phase:he.EXIT}),a==null)continue;for(var o=i.node.lastChild;o;)r.push({node:o,context:a,phase:he.ENTER}),o=o.previousSibling}else n.exit&&n.exit(i.node,i.context)}}he.STOP=Symbol(`walkDOM.STOP`),he.ENTER=0,he.EXIT=1;function ge(e,t){h(e);var n=t||{};this.ownerDocument=this,this.contentType=n.contentType||c.XML_APPLICATION,this.type=a(this.contentType)?`html`:`xml`}function _e(e,t,n){e&&e._inc++,n.namespaceURI===l.XMLNS&&(t._nsMap[n.prefix?n.localName:``]=n.value)}function ve(e,t,n,r){e&&e._inc++,n.namespaceURI===l.XMLNS&&delete t._nsMap[n.prefix?n.localName:``]}function ye(e,t,n){if(e&&e._inc){e._inc++;var r=t.childNodes;if(n&&!n.nextSibling)r[r.length++]=n;else{for(var i=t.firstChild,a=0;i;)r[a++]=i,i=i.nextSibling;r.length=a,delete r[r.length]}}}function be(e,t){if(e!==t.parentNode)throw new f(f.NOT_FOUND_ERR,`child's parent is not parent`);var n=t.previousSibling,r=t.nextSibling;return n?n.nextSibling=r:e.firstChild=r,r?r.previousSibling=n:e.lastChild=n,ye(e.ownerDocument,e),t.parentNode=null,t.previousSibling=null,t.nextSibling=null,t}function xe(e){return e&&(e.nodeType===B.DOCUMENT_NODE||e.nodeType===B.DOCUMENT_FRAGMENT_NODE||e.nodeType===B.ELEMENT_NODE)}function Se(e){return e&&(e.nodeType===B.CDATA_SECTION_NODE||e.nodeType===B.COMMENT_NODE||e.nodeType===B.DOCUMENT_FRAGMENT_NODE||e.nodeType===B.DOCUMENT_TYPE_NODE||e.nodeType===B.ELEMENT_NODE||e.nodeType===B.PROCESSING_INSTRUCTION_NODE||e.nodeType===B.TEXT_NODE)}function V(e){return e&&e.nodeType===B.DOCUMENT_TYPE_NODE}function Ce(e){return e&&e.nodeType===B.ELEMENT_NODE}function we(e){return e&&e.nodeType===B.TEXT_NODE}function Te(e,t){var r=e.childNodes||[];if(n(r,Ce)||V(t))return!1;var i=n(r,V);return!(t&&i&&r.indexOf(i)>r.indexOf(t))}function Ee(e,t){var r=e.childNodes||[];function i(e){return Ce(e)&&e!==t}if(n(r,i))return!1;var a=n(r,V);return!(t&&a&&r.indexOf(a)>r.indexOf(t))}function De(e,t,n){if(!xe(e))throw new f(f.HIERARCHY_REQUEST_ERR,`Unexpected parent node type `+e.nodeType);if(n&&n.parentNode!==e)throw new f(f.NOT_FOUND_ERR,`child not in parent`);if(!Se(t)||V(t)&&e.nodeType!==B.DOCUMENT_NODE)throw new f(f.HIERARCHY_REQUEST_ERR,`Unexpected node type `+t.nodeType+` for parent node type `+e.nodeType)}function Oe(e,t,r){var i=e.childNodes||[],a=t.childNodes||[];if(t.nodeType===B.DOCUMENT_FRAGMENT_NODE){var o=a.filter(Ce);if(o.length>1||n(a,we))throw new f(f.HIERARCHY_REQUEST_ERR,`More than one element or text in fragment`);if(o.length===1&&!Te(e,r))throw new f(f.HIERARCHY_REQUEST_ERR,`Element in fragment can not be inserted before doctype`)}if(Ce(t)&&!Te(e,r))throw new f(f.HIERARCHY_REQUEST_ERR,`Only one element can be added and only after doctype`);if(V(t)){if(n(i,V))throw new f(f.HIERARCHY_REQUEST_ERR,`Only one doctype is allowed`);var s=n(i,Ce);if(r&&i.indexOf(s)<i.indexOf(r))throw new f(f.HIERARCHY_REQUEST_ERR,`Doctype can only be inserted before an element`);if(!r&&s)throw new f(f.HIERARCHY_REQUEST_ERR,`Doctype can not be appended since element is present`)}}function ke(e,t,r){var i=e.childNodes||[],a=t.childNodes||[];if(t.nodeType===B.DOCUMENT_FRAGMENT_NODE){var o=a.filter(Ce);if(o.length>1||n(a,we))throw new f(f.HIERARCHY_REQUEST_ERR,`More than one element or text in fragment`);if(o.length===1&&!Ee(e,r))throw new f(f.HIERARCHY_REQUEST_ERR,`Element in fragment can not be inserted before doctype`)}if(Ce(t)&&!Ee(e,r))throw new f(f.HIERARCHY_REQUEST_ERR,`Only one element can be added and only after doctype`);if(V(t)){function s(e){return V(e)&&e!==r}if(n(i,s))throw new f(f.HIERARCHY_REQUEST_ERR,`Only one doctype is allowed`);var c=n(i,Ce);if(r&&i.indexOf(c)<i.indexOf(r))throw new f(f.HIERARCHY_REQUEST_ERR,`Doctype can only be inserted before an element`)}}function Ae(e,t,n,r){De(e,t,n),e.nodeType===B.DOCUMENT_NODE&&(r||Oe)(e,t,n);var i=t.parentNode;if(i&&i.removeChild(t),t.nodeType===N){var a=t.firstChild;if(a==null)return t;var o=t.lastChild}else a=o=t;var s=n?n.previousSibling:e.lastChild;a.previousSibling=s,o.nextSibling=n,s?s.nextSibling=a:e.firstChild=a,n==null?e.lastChild=o:n.previousSibling=o;do a.parentNode=e;while(a!==o&&(a=a.nextSibling));return ye(e.ownerDocument||e,e,t),t.nodeType==N&&(t.firstChild=t.lastChild=null),t}ge.prototype={implementation:null,nodeName:`#document`,nodeType:ne,doctype:null,documentElement:null,_inc:1,insertBefore:function(e,t){if(e.nodeType===N){for(var n=e.firstChild;n;){var r=n.nextSibling;this.insertBefore(n,t),n=r}return e}return Ae(this,e,t),e.ownerDocument=this,this.documentElement===null&&e.nodeType===E&&(this.documentElement=e),e},removeChild:function(e){var t=be(this,e);return t===this.documentElement&&(this.documentElement=null),t},replaceChild:function(e,t){Ae(this,e,t,ke),e.ownerDocument=this,t&&this.removeChild(t),Ce(e)&&(this.documentElement=e)},importNode:function(e,t){return Je(this,e,t)},getElementById:function(e){var t=null;return me(this.documentElement,function(n){if(n.nodeType==E&&n.getAttribute(`id`)==e)return t=n,!0}),t},createElement:function(e){var t=new je(u);t.ownerDocument=this,this.type===`html`&&(e=e.toLowerCase()),r(this.contentType)&&(t.namespaceURI=l.HTML),t.nodeName=e,t.tagName=e,t.localName=e,t.childNodes=new L;var n=t.attributes=new ie;return n._ownerElement=t,t},createDocumentFragment:function(){var e=new Ve(u);return e.ownerDocument=this,e.childNodes=new L,e},createTextNode:function(e){var t=new Pe(u);return t.ownerDocument=this,t.childNodes=new L,t.appendData(e),t},createComment:function(e){var t=new Fe(u);return t.ownerDocument=this,t.childNodes=new L,t.appendData(e),t},createCDATASection:function(e){if(e.indexOf(`]]>`)!==-1)throw new f(f.INVALID_CHARACTER_ERR,`data contains "]]>"`);var t=new Ie(u);return t.ownerDocument=this,t.childNodes=new L,t.appendData(e),t},createProcessingInstruction:function(e,t){var n=new He(u);return n.ownerDocument=this,n.childNodes=new L,n.nodeName=n.target=e,n.nodeValue=n.data=t,n},createAttribute:function(e){if(!m.QName_exact.test(e))throw new f(f.INVALID_CHARACTER_ERR,`invalid character in name "`+e+`"`);return this.type===`html`&&(e=e.toLowerCase()),this._createAttribute(e)},_createAttribute:function(e){var t=new Me(u);return t.ownerDocument=this,t.childNodes=new L,t.name=e,t.nodeName=e,t.localName=e,t.specified=!0,t},createEntityReference:function(e){if(!m.Name_exact.test(e))throw new f(f.INVALID_CHARACTER_ERR,`not a valid xml name "`+e+`"`);if(this.type===`html`)throw new f(`document is an html document`,p.NotSupportedError);var t=new Be(u);return t.ownerDocument=this,t.childNodes=new L,t.nodeName=e,t},createElementNS:function(e,t){var n=S(e,t),r=new je(u),i=r.attributes=new ie;return r.childNodes=new L,r.ownerDocument=this,r.nodeName=t,r.tagName=t,r.namespaceURI=n[0],r.prefix=n[1],r.localName=n[2],i._ownerElement=r,r},createAttributeNS:function(e,t){var n=S(e,t),r=new Me(u);return r.ownerDocument=this,r.childNodes=new L,r.nodeName=t,r.name=t,r.specified=!0,r.namespaceURI=n[0],r.prefix=n[1],r.localName=n[2],r}},w(ge,B);function je(e){h(e),this._nsMap=Object.create(null)}je.prototype={nodeType:E,attributes:null,getQualifiedName:function(){return this.prefix?this.prefix+`:`+this.localName:this.localName},_isInHTMLDocumentAndNamespace:function(){return this.ownerDocument.type===`html`&&this.namespaceURI===l.HTML},hasAttributes:function(){return!!(this.attributes&&this.attributes.length)},hasAttribute:function(e){return!!this.getAttributeNode(e)},getAttribute:function(e){var t=this.getAttributeNode(e);return t?t.value:null},getAttributeNode:function(e){return this._isInHTMLDocumentAndNamespace()&&(e=e.toLowerCase()),this.attributes.getNamedItem(e)},setAttribute:function(e,t){this._isInHTMLDocumentAndNamespace()&&(e=e.toLowerCase());var n=this.getAttributeNode(e);n?n.value=n.nodeValue=``+t:(n=this.ownerDocument._createAttribute(e),n.value=n.nodeValue=``+t,this.setAttributeNode(n))},removeAttribute:function(e){var t=this.getAttributeNode(e);t&&this.removeAttributeNode(t)},setAttributeNode:function(e){return this.attributes.setNamedItem(e)},setAttributeNodeNS:function(e){return this.attributes.setNamedItemNS(e)},removeAttributeNode:function(e){return this.attributes.removeNamedItem(e.nodeName)},removeAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t);n&&this.removeAttributeNode(n)},hasAttributeNS:function(e,t){return this.getAttributeNodeNS(e,t)!=null},getAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t);return n?n.value:null},setAttributeNS:function(e,t,n){var r=S(e,t)[2],i=this.getAttributeNodeNS(e,r);i?i.value=i.nodeValue=``+n:(i=this.ownerDocument.createAttributeNS(e,t),i.value=i.nodeValue=``+n,this.setAttributeNode(i))},getAttributeNodeNS:function(e,t){return this.attributes.getNamedItemNS(e,t)},getElementsByClassName:function(e){var t=y(e);return new R(this,function(n){var r=[];return t.length>0&&me(n,function(i){if(i!==n&&i.nodeType===E){var a=i.getAttribute(`class`);if(a){var o=e===a;if(!o){var s=y(a);o=t.every(b(s))}o&&r.push(i)}}}),r})},getElementsByTagName:function(e){var t=(this.nodeType===ne?this:this.ownerDocument).type===`html`,n=e.toLowerCase();return new R(this,function(r){var i=[];return me(r,function(a){a===r||a.nodeType!==E||(e===`*`||a.getQualifiedName()===(t&&a.namespaceURI===l.HTML?n:e))&&i.push(a)}),i})},getElementsByTagNameNS:function(e,t){return new R(this,function(n){var r=[];return me(n,function(i){i!==n&&i.nodeType===E&&(e===`*`||i.namespaceURI===e)&&(t===`*`||i.localName==t)&&r.push(i)}),r})}},ge.prototype.getElementsByClassName=je.prototype.getElementsByClassName,ge.prototype.getElementsByTagName=je.prototype.getElementsByTagName,ge.prototype.getElementsByTagNameNS=je.prototype.getElementsByTagNameNS,w(je,B);function Me(e){h(e),this.namespaceURI=null,this.prefix=null,this.ownerElement=null}Me.prototype.nodeType=D,w(Me,B);function Ne(e){h(e)}Ne.prototype={data:``,substringData:function(e,t){return this.data.substring(e,e+t)},appendData:function(e){e=this.data+e,this.nodeValue=this.data=e,this.length=e.length},insertData:function(e,t){this.replaceData(e,0,t)},deleteData:function(e,t){this.replaceData(e,t,``)},replaceData:function(e,t,n){var r=this.data.substring(0,e),i=this.data.substring(e+t);n=r+n+i,this.nodeValue=this.data=n,this.length=n.length}},w(Ne,B);function Pe(e){h(e)}Pe.prototype={nodeName:`#text`,nodeType:O,splitText:function(e){var t=this.data,n=t.substring(e);t=t.substring(0,e),this.data=this.nodeValue=t,this.length=t.length;var r=this.ownerDocument.createTextNode(n);return this.parentNode&&this.parentNode.insertBefore(r,this.nextSibling),r}},w(Pe,Ne);function Fe(e){h(e)}Fe.prototype={nodeName:`#comment`,nodeType:j},w(Fe,Ne);function Ie(e){h(e)}Ie.prototype={nodeName:`#cdata-section`,nodeType:ee},w(Ie,Pe);function Le(e){h(e)}Le.prototype.nodeType=M,w(Le,B);function Re(e){h(e)}Re.prototype.nodeType=P,w(Re,B);function ze(e){h(e)}ze.prototype.nodeType=te,w(ze,B);function Be(e){h(e)}Be.prototype.nodeType=k,w(Be,B);function Ve(e){h(e)}Ve.prototype.nodeName=`#document-fragment`,Ve.prototype.nodeType=N,w(Ve,B);function He(e){h(e)}He.prototype.nodeType=A,w(He,Ne);function Ue(){}Ue.prototype.serializeToString=function(e,t){return We.call(e,t)},B.prototype.toString=We;function We(e){var t=typeof e==`function`?{requireWellFormed:!1,splitCDATASections:!0,nodeFilter:e}:e==null?{requireWellFormed:!1,splitCDATASections:!0,nodeFilter:null}:{requireWellFormed:!!e.requireWellFormed,splitCDATASections:e.splitCDATASections!==!1,nodeFilter:e.nodeFilter||null},n=[],r=this.nodeType===ne&&this.documentElement||this,i=r.prefix,a=r.namespaceURI;if(a&&i==null){var i=r.lookupPrefix(a);if(i==null)var o=[{namespace:a,prefix:null}]}return qe(this,n,o,t),n.join(``)}function Ge(e,t,n){var r=e.prefix||``,i=e.namespaceURI;if(!i||r===`xml`&&i===l.XML||i===l.XMLNS)return!1;for(var a=n.length;a--;){var o=n[a];if(o.prefix===r)return o.namespace!==i}return!0}function Ke(e,t,n,r){if(r&&!m.QName_exact.test(t))throw new f(`The attribute name "`+t+`" is not a valid XML QName`,p.InvalidStateError);e.push(` `,t,`="`,n.replace(/[<>&"\t\n\r]/g,pe),`"`)}function qe(e,t,n,r){n||=[];var i=r.nodeFilter,a=r.requireWellFormed,c=r.splitCDATASections,u=(e.nodeType===ne?e:e.ownerDocument).type===`html`;he(e,{ns:n},{enter:function(e,n){var d=n.ns;if(i)if(e=i(e),e){if(typeof e==`string`)return t.push(e),null}else return null;switch(e.nodeType){case E:var h=e.attributes,g=h.length,_=e.tagName,v=_;if(!u&&!e.prefix&&e.namespaceURI){for(var y,b=0;b<h.length;b++)if(h.item(b).name===`xmlns`){y=h.item(b).value;break}if(!y)for(var x=d.length-1;x>=0;x--){var S=d[x];if(S.prefix===``&&S.namespace===e.namespaceURI){y=S.namespace;break}}if(y!==e.namespaceURI)for(var x=d.length-1;x>=0;x--){var S=d[x];if(S.namespace===e.namespaceURI){S.prefix&&(v=S.prefix+`:`+_);break}}}if(a&&!m.QName_exact.test(v))throw new f(`The element name "`+v+`" is not a valid XML QName`,p.InvalidStateError);t.push(`<`,v);for(var C=d.slice(),w=0;w<g;w++){var T=h.item(w);T.prefix==`xmlns`?C.push({prefix:T.localName,namespace:T.value}):T.nodeName==`xmlns`&&C.push({prefix:``,namespace:T.value})}for(var w=0;w<g;w++){var T=h.item(w);if(Ge(T,u,C)){var te=T.prefix||``,P=T.namespaceURI;Ke(t,te?`xmlns:`+te:`xmlns`,P,a),C.push({prefix:te,namespace:P})}var F=i?i(T):T;F&&(typeof F==`string`?t.push(F):Ke(t,F.name,F.value,a))}if(_===v&&Ge(e,u,C)){var I=e.prefix||``,P=e.namespaceURI;Ke(t,I?`xmlns:`+I:`xmlns`,P,a),C.push({prefix:I,namespace:P})}var re=!e.firstChild;if(re&&(u||e.namespaceURI===l.HTML)&&(re=s(_)),re)return t.push(`/>`),null;if(t.push(`>`),u&&o(_)){for(var L=e.firstChild;L;)L.data?t.push(L.data):qe(L,t,C.slice(),r),L=L.nextSibling;return t.push(`</`,v,`>`),null}return{ns:C,tag:v};case ne:case N:if(a&&e.nodeType===ne&&e.documentElement==null)throw new f(`The Document has no documentElement`,p.InvalidStateError);return{ns:d};case D:return Ke(t,e.name,e.value,a),null;case O:if(a&&m.InvalidChar.test(e.data))throw new f(`The Text node data contains characters outside the XML Char production`,p.InvalidStateError);return t.push(e.data.replace(/[<&>]/g,pe)),null;case ee:if(a&&e.data.indexOf(`]]>`)!==-1)throw new f(`The CDATASection data contains "]]>"`,p.InvalidStateError);return c?t.push(m.CDATA_START,e.data.replace(/]]>/g,`]]]]><![CDATA[>`),m.CDATA_END):t.push(m.CDATA_START,e.data,m.CDATA_END),null;case j:if(a){if(m.InvalidChar.test(e.data))throw new f(`The comment node data contains characters outside the XML Char production`,p.InvalidStateError);if(e.data.indexOf(`--`)!==-1||e.data[e.data.length-1]===`-`)throw new f(`The comment node data contains "--" or ends with "-"`,p.InvalidStateError)}return t.push(m.COMMENT_START,e.data,m.COMMENT_END),null;case M:var R=e.publicId,z=e.systemId;if(a){if(!m.Name_exact.test(e.name))throw new f(`The doctype name "`+e.name+`" is not a valid XML Name`,p.InvalidStateError);if(R&&!m.PubidLiteral_match.test(R))throw new f(`DocumentType publicId is not a valid PubidLiteral`,p.InvalidStateError);if(z&&z!==`.`&&!m.SystemLiteral_match.test(z))throw new f(`DocumentType systemId is not a valid SystemLiteral`,p.InvalidStateError);if(e.internalSubset&&e.internalSubset.indexOf(`]>`)!==-1)throw new f(`DocumentType internalSubset contains "]>"`,p.InvalidStateError)}return t.push(m.DOCTYPE_DECL_START,` `,e.name),R?(t.push(` `,m.PUBLIC,` `,R),z&&z!==`.`&&t.push(` `,z)):z&&z!==`.`&&t.push(` `,m.SYSTEM,` `,z),e.internalSubset&&t.push(` [`,e.internalSubset,`]`),t.push(`>`),null;case A:if(a){if(!m.NCName_exact.test(e.target)||e.target.toLowerCase()===`xml`)throw new f(`The processing instruction target "`+e.target+`" is not a valid XML NCName or is reserved`,p.InvalidStateError);if(m.InvalidChar.test(e.data))throw new f(`The ProcessingInstruction data contains characters outside the XML Char production`,p.InvalidStateError);if(e.data.indexOf(`?>`)!==-1)throw new f(`The ProcessingInstruction data contains "?>"`,p.InvalidStateError)}return t.push(`<?`,e.target,` `,e.data,`?>`),null;case k:if(a&&!m.Name_exact.test(e.nodeName))throw new f(`The entity reference name "`+e.nodeName+`" is not a valid XML Name`,p.InvalidStateError);return t.push(`&`,e.nodeName,`;`),null;default:return t.push(`??`,e.nodeName),null}},exit:function(e,n){n&&n.tag&&t.push(`</`,n.tag,`>`)}})}function Je(e,t,n){var r;return he(t,null,{enter:function(t,i){var a=t.cloneNode(!1);return a.ownerDocument=e,a.parentNode=null,i===null?r=a:i.appendChild(a),t.nodeType===D||n?a:null}}),r}function Ye(e,t,n){var r;return he(t,null,{enter:function(t,a){var o=new t.constructor(u);for(var s in t)if(i(t,s)){var c=t[s];typeof c!=`object`&&c!=o[s]&&(o[s]=c)}t.childNodes&&(o.childNodes=new L),o.ownerDocument=e;var l=n;switch(o.nodeType){case E:var d=t.attributes,f=o.attributes=new ie,p=d.length;f._ownerElement=o;for(var m=0;m<p;m++)o.setAttributeNode(Ye(e,d.item(m),!0));break;case D:l=!0}return a===null?r=o:a.appendChild(o),l?o:null}}),r}function Xe(e,t,n){e[t]=n}function Ze(e){for(var t=[],n=e.firstChild;n;)n.nodeType===E&&t.push(n),n=n.nextSibling;return t}try{Object.defineProperty&&(Object.defineProperty(R.prototype,`length`,{get:function(){return z(this),this.$$length}}),Object.defineProperty(B.prototype,`textContent`,{get:function(){if(this.nodeType===E||this.nodeType===N){var e=[];return he(this,null,{enter:function(t){if(t.nodeType===E||t.nodeType===N)return!0;if(t.nodeType===A||t.nodeType===j)return null;e.push(t.nodeValue)}}),e.join(``)}return this.nodeValue},set:function(e){switch(this.nodeType){case E:case N:for(;this.firstChild;)this.removeChild(this.firstChild);(e||String(e))&&this.appendChild(this.ownerDocument.createTextNode(e));break;default:this.data=e,this.value=e,this.nodeValue=e}}}),Object.defineProperty(Ne.prototype,`data`,{get:function(){return this._data==null?``:this._data},set:function(e){this._data=e,this.length=typeof e==`string`?e.length:0}}),Object.defineProperty(Ne.prototype,`nodeValue`,{get:function(){return this.data},set:function(e){this.data=e},enumerable:!0,configurable:!0}),Object.defineProperty(je.prototype,`children`,{get:function(){return new R(this,Ze)}}),Object.defineProperty(ge.prototype,`children`,{get:function(){return new R(this,Ze)}}),Object.defineProperty(Ve.prototype,`children`,{get:function(){return new R(this,Ze)}}),Xe=function(e,t,n){e[`$$`+t]=n})}catch{}e._updateLiveList=z,e.Attr=Me,e.CDATASection=Ie,e.CharacterData=Ne,e.Comment=Fe,e.Document=ge,e.DocumentFragment=Ve,e.DocumentType=Le,e.DOMImplementation=fe,e.Element=je,e.Entity=ze,e.EntityReference=Be,e.LiveNodeList=R,e.NamedNodeMap=ie,e.Node=B,e.NodeList=L,e.Notation=Re,e.Text=Pe,e.ProcessingInstruction=He,e.walkDOM=he,e.XMLSerializer=Ue})),ho=n((e=>{var t=uo().freeze;e.XML_ENTITIES=t({amp:`&`,apos:`'`,gt:`>`,lt:`<`,quot:`"`}),e.HTML_ENTITIES=t({Aacute:`Á`,aacute:`á`,Abreve:`Ă`,abreve:`ă`,ac:`∾`,acd:`∿`,acE:`∾̳`,Acirc:`Â`,acirc:`â`,acute:`´`,Acy:`А`,acy:`а`,AElig:`Æ`,aelig:`æ`,af:`⁡`,Afr:`𝔄`,afr:`𝔞`,Agrave:`À`,agrave:`à`,alefsym:`ℵ`,aleph:`ℵ`,Alpha:`Α`,alpha:`α`,Amacr:`Ā`,amacr:`ā`,amalg:`⨿`,AMP:`&`,amp:`&`,And:`⩓`,and:`∧`,andand:`⩕`,andd:`⩜`,andslope:`⩘`,andv:`⩚`,ang:`∠`,ange:`⦤`,angle:`∠`,angmsd:`∡`,angmsdaa:`⦨`,angmsdab:`⦩`,angmsdac:`⦪`,angmsdad:`⦫`,angmsdae:`⦬`,angmsdaf:`⦭`,angmsdag:`⦮`,angmsdah:`⦯`,angrt:`∟`,angrtvb:`⊾`,angrtvbd:`⦝`,angsph:`∢`,angst:`Å`,angzarr:`⍼`,Aogon:`Ą`,aogon:`ą`,Aopf:`𝔸`,aopf:`𝕒`,ap:`≈`,apacir:`⩯`,apE:`⩰`,ape:`≊`,apid:`≋`,apos:`'`,ApplyFunction:`⁡`,approx:`≈`,approxeq:`≊`,Aring:`Å`,aring:`å`,Ascr:`𝒜`,ascr:`𝒶`,Assign:`≔`,ast:`*`,asymp:`≈`,asympeq:`≍`,Atilde:`Ã`,atilde:`ã`,Auml:`Ä`,auml:`ä`,awconint:`∳`,awint:`⨑`,backcong:`≌`,backepsilon:`϶`,backprime:`‵`,backsim:`∽`,backsimeq:`⋍`,Backslash:`∖`,Barv:`⫧`,barvee:`⊽`,Barwed:`⌆`,barwed:`⌅`,barwedge:`⌅`,bbrk:`⎵`,bbrktbrk:`⎶`,bcong:`≌`,Bcy:`Б`,bcy:`б`,bdquo:`„`,becaus:`∵`,Because:`∵`,because:`∵`,bemptyv:`⦰`,bepsi:`϶`,bernou:`ℬ`,Bernoullis:`ℬ`,Beta:`Β`,beta:`β`,beth:`ℶ`,between:`≬`,Bfr:`𝔅`,bfr:`𝔟`,bigcap:`⋂`,bigcirc:`◯`,bigcup:`⋃`,bigodot:`⨀`,bigoplus:`⨁`,bigotimes:`⨂`,bigsqcup:`⨆`,bigstar:`★`,bigtriangledown:`▽`,bigtriangleup:`△`,biguplus:`⨄`,bigvee:`⋁`,bigwedge:`⋀`,bkarow:`⤍`,blacklozenge:`⧫`,blacksquare:`▪`,blacktriangle:`▴`,blacktriangledown:`▾`,blacktriangleleft:`◂`,blacktriangleright:`▸`,blank:`␣`,blk12:`▒`,blk14:`░`,blk34:`▓`,block:`█`,bne:`=⃥`,bnequiv:`≡⃥`,bNot:`⫭`,bnot:`⌐`,Bopf:`𝔹`,bopf:`𝕓`,bot:`⊥`,bottom:`⊥`,bowtie:`⋈`,boxbox:`⧉`,boxDL:`╗`,boxDl:`╖`,boxdL:`╕`,boxdl:`┐`,boxDR:`╔`,boxDr:`╓`,boxdR:`╒`,boxdr:`┌`,boxH:`═`,boxh:`─`,boxHD:`╦`,boxHd:`╤`,boxhD:`╥`,boxhd:`┬`,boxHU:`╩`,boxHu:`╧`,boxhU:`╨`,boxhu:`┴`,boxminus:`⊟`,boxplus:`⊞`,boxtimes:`⊠`,boxUL:`╝`,boxUl:`╜`,boxuL:`╛`,boxul:`┘`,boxUR:`╚`,boxUr:`╙`,boxuR:`╘`,boxur:`└`,boxV:`║`,boxv:`│`,boxVH:`╬`,boxVh:`╫`,boxvH:`╪`,boxvh:`┼`,boxVL:`╣`,boxVl:`╢`,boxvL:`╡`,boxvl:`┤`,boxVR:`╠`,boxVr:`╟`,boxvR:`╞`,boxvr:`├`,bprime:`‵`,Breve:`˘`,breve:`˘`,brvbar:`¦`,Bscr:`ℬ`,bscr:`𝒷`,bsemi:`⁏`,bsim:`∽`,bsime:`⋍`,bsol:`\\`,bsolb:`⧅`,bsolhsub:`⟈`,bull:`•`,bullet:`•`,bump:`≎`,bumpE:`⪮`,bumpe:`≏`,Bumpeq:`≎`,bumpeq:`≏`,Cacute:`Ć`,cacute:`ć`,Cap:`⋒`,cap:`∩`,capand:`⩄`,capbrcup:`⩉`,capcap:`⩋`,capcup:`⩇`,capdot:`⩀`,CapitalDifferentialD:`ⅅ`,caps:`∩︀`,caret:`⁁`,caron:`ˇ`,Cayleys:`ℭ`,ccaps:`⩍`,Ccaron:`Č`,ccaron:`č`,Ccedil:`Ç`,ccedil:`ç`,Ccirc:`Ĉ`,ccirc:`ĉ`,Cconint:`∰`,ccups:`⩌`,ccupssm:`⩐`,Cdot:`Ċ`,cdot:`ċ`,cedil:`¸`,Cedilla:`¸`,cemptyv:`⦲`,cent:`¢`,CenterDot:`·`,centerdot:`·`,Cfr:`ℭ`,cfr:`𝔠`,CHcy:`Ч`,chcy:`ч`,check:`✓`,checkmark:`✓`,Chi:`Χ`,chi:`χ`,cir:`○`,circ:`ˆ`,circeq:`≗`,circlearrowleft:`↺`,circlearrowright:`↻`,circledast:`⊛`,circledcirc:`⊚`,circleddash:`⊝`,CircleDot:`⊙`,circledR:`®`,circledS:`Ⓢ`,CircleMinus:`⊖`,CirclePlus:`⊕`,CircleTimes:`⊗`,cirE:`⧃`,cire:`≗`,cirfnint:`⨐`,cirmid:`⫯`,cirscir:`⧂`,ClockwiseContourIntegral:`∲`,CloseCurlyDoubleQuote:`”`,CloseCurlyQuote:`’`,clubs:`♣`,clubsuit:`♣`,Colon:`∷`,colon:`:`,Colone:`⩴`,colone:`≔`,coloneq:`≔`,comma:`,`,commat:`@`,comp:`∁`,compfn:`∘`,complement:`∁`,complexes:`ℂ`,cong:`≅`,congdot:`⩭`,Congruent:`≡`,Conint:`∯`,conint:`∮`,ContourIntegral:`∮`,Copf:`ℂ`,copf:`𝕔`,coprod:`∐`,Coproduct:`∐`,COPY:`©`,copy:`©`,copysr:`℗`,CounterClockwiseContourIntegral:`∳`,crarr:`↵`,Cross:`⨯`,cross:`✗`,Cscr:`𝒞`,cscr:`𝒸`,csub:`⫏`,csube:`⫑`,csup:`⫐`,csupe:`⫒`,ctdot:`⋯`,cudarrl:`⤸`,cudarrr:`⤵`,cuepr:`⋞`,cuesc:`⋟`,cularr:`↶`,cularrp:`⤽`,Cup:`⋓`,cup:`∪`,cupbrcap:`⩈`,CupCap:`≍`,cupcap:`⩆`,cupcup:`⩊`,cupdot:`⊍`,cupor:`⩅`,cups:`∪︀`,curarr:`↷`,curarrm:`⤼`,curlyeqprec:`⋞`,curlyeqsucc:`⋟`,curlyvee:`⋎`,curlywedge:`⋏`,curren:`¤`,curvearrowleft:`↶`,curvearrowright:`↷`,cuvee:`⋎`,cuwed:`⋏`,cwconint:`∲`,cwint:`∱`,cylcty:`⌭`,Dagger:`‡`,dagger:`†`,daleth:`ℸ`,Darr:`↡`,dArr:`⇓`,darr:`↓`,dash:`‐`,Dashv:`⫤`,dashv:`⊣`,dbkarow:`⤏`,dblac:`˝`,Dcaron:`Ď`,dcaron:`ď`,Dcy:`Д`,dcy:`д`,DD:`ⅅ`,dd:`ⅆ`,ddagger:`‡`,ddarr:`⇊`,DDotrahd:`⤑`,ddotseq:`⩷`,deg:`°`,Del:`∇`,Delta:`Δ`,delta:`δ`,demptyv:`⦱`,dfisht:`⥿`,Dfr:`𝔇`,dfr:`𝔡`,dHar:`⥥`,dharl:`⇃`,dharr:`⇂`,DiacriticalAcute:`´`,DiacriticalDot:`˙`,DiacriticalDoubleAcute:`˝`,DiacriticalGrave:"`",DiacriticalTilde:`˜`,diam:`⋄`,Diamond:`⋄`,diamond:`⋄`,diamondsuit:`♦`,diams:`♦`,die:`¨`,DifferentialD:`ⅆ`,digamma:`ϝ`,disin:`⋲`,div:`÷`,divide:`÷`,divideontimes:`⋇`,divonx:`⋇`,DJcy:`Ђ`,djcy:`ђ`,dlcorn:`⌞`,dlcrop:`⌍`,dollar:`$`,Dopf:`𝔻`,dopf:`𝕕`,Dot:`¨`,dot:`˙`,DotDot:`⃜`,doteq:`≐`,doteqdot:`≑`,DotEqual:`≐`,dotminus:`∸`,dotplus:`∔`,dotsquare:`⊡`,doublebarwedge:`⌆`,DoubleContourIntegral:`∯`,DoubleDot:`¨`,DoubleDownArrow:`⇓`,DoubleLeftArrow:`⇐`,DoubleLeftRightArrow:`⇔`,DoubleLeftTee:`⫤`,DoubleLongLeftArrow:`⟸`,DoubleLongLeftRightArrow:`⟺`,DoubleLongRightArrow:`⟹`,DoubleRightArrow:`⇒`,DoubleRightTee:`⊨`,DoubleUpArrow:`⇑`,DoubleUpDownArrow:`⇕`,DoubleVerticalBar:`∥`,DownArrow:`↓`,Downarrow:`⇓`,downarrow:`↓`,DownArrowBar:`⤓`,DownArrowUpArrow:`⇵`,DownBreve:`̑`,downdownarrows:`⇊`,downharpoonleft:`⇃`,downharpoonright:`⇂`,DownLeftRightVector:`⥐`,DownLeftTeeVector:`⥞`,DownLeftVector:`↽`,DownLeftVectorBar:`⥖`,DownRightTeeVector:`⥟`,DownRightVector:`⇁`,DownRightVectorBar:`⥗`,DownTee:`⊤`,DownTeeArrow:`↧`,drbkarow:`⤐`,drcorn:`⌟`,drcrop:`⌌`,Dscr:`𝒟`,dscr:`𝒹`,DScy:`Ѕ`,dscy:`ѕ`,dsol:`⧶`,Dstrok:`Đ`,dstrok:`đ`,dtdot:`⋱`,dtri:`▿`,dtrif:`▾`,duarr:`⇵`,duhar:`⥯`,dwangle:`⦦`,DZcy:`Џ`,dzcy:`џ`,dzigrarr:`⟿`,Eacute:`É`,eacute:`é`,easter:`⩮`,Ecaron:`Ě`,ecaron:`ě`,ecir:`≖`,Ecirc:`Ê`,ecirc:`ê`,ecolon:`≕`,Ecy:`Э`,ecy:`э`,eDDot:`⩷`,Edot:`Ė`,eDot:`≑`,edot:`ė`,ee:`ⅇ`,efDot:`≒`,Efr:`𝔈`,efr:`𝔢`,eg:`⪚`,Egrave:`È`,egrave:`è`,egs:`⪖`,egsdot:`⪘`,el:`⪙`,Element:`∈`,elinters:`⏧`,ell:`ℓ`,els:`⪕`,elsdot:`⪗`,Emacr:`Ē`,emacr:`ē`,empty:`∅`,emptyset:`∅`,EmptySmallSquare:`◻`,emptyv:`∅`,EmptyVerySmallSquare:`▫`,emsp:` `,emsp13:` `,emsp14:` `,ENG:`Ŋ`,eng:`ŋ`,ensp:` `,Eogon:`Ę`,eogon:`ę`,Eopf:`𝔼`,eopf:`𝕖`,epar:`⋕`,eparsl:`⧣`,eplus:`⩱`,epsi:`ε`,Epsilon:`Ε`,epsilon:`ε`,epsiv:`ϵ`,eqcirc:`≖`,eqcolon:`≕`,eqsim:`≂`,eqslantgtr:`⪖`,eqslantless:`⪕`,Equal:`⩵`,equals:`=`,EqualTilde:`≂`,equest:`≟`,Equilibrium:`⇌`,equiv:`≡`,equivDD:`⩸`,eqvparsl:`⧥`,erarr:`⥱`,erDot:`≓`,Escr:`ℰ`,escr:`ℯ`,esdot:`≐`,Esim:`⩳`,esim:`≂`,Eta:`Η`,eta:`η`,ETH:`Ð`,eth:`ð`,Euml:`Ë`,euml:`ë`,euro:`€`,excl:`!`,exist:`∃`,Exists:`∃`,expectation:`ℰ`,ExponentialE:`ⅇ`,exponentiale:`ⅇ`,fallingdotseq:`≒`,Fcy:`Ф`,fcy:`ф`,female:`♀`,ffilig:`ﬃ`,fflig:`ﬀ`,ffllig:`ﬄ`,Ffr:`𝔉`,ffr:`𝔣`,filig:`ﬁ`,FilledSmallSquare:`◼`,FilledVerySmallSquare:`▪`,fjlig:`fj`,flat:`♭`,fllig:`ﬂ`,fltns:`▱`,fnof:`ƒ`,Fopf:`𝔽`,fopf:`𝕗`,ForAll:`∀`,forall:`∀`,fork:`⋔`,forkv:`⫙`,Fouriertrf:`ℱ`,fpartint:`⨍`,frac12:`½`,frac13:`⅓`,frac14:`¼`,frac15:`⅕`,frac16:`⅙`,frac18:`⅛`,frac23:`⅔`,frac25:`⅖`,frac34:`¾`,frac35:`⅗`,frac38:`⅜`,frac45:`⅘`,frac56:`⅚`,frac58:`⅝`,frac78:`⅞`,frasl:`⁄`,frown:`⌢`,Fscr:`ℱ`,fscr:`𝒻`,gacute:`ǵ`,Gamma:`Γ`,gamma:`γ`,Gammad:`Ϝ`,gammad:`ϝ`,gap:`⪆`,Gbreve:`Ğ`,gbreve:`ğ`,Gcedil:`Ģ`,Gcirc:`Ĝ`,gcirc:`ĝ`,Gcy:`Г`,gcy:`г`,Gdot:`Ġ`,gdot:`ġ`,gE:`≧`,ge:`≥`,gEl:`⪌`,gel:`⋛`,geq:`≥`,geqq:`≧`,geqslant:`⩾`,ges:`⩾`,gescc:`⪩`,gesdot:`⪀`,gesdoto:`⪂`,gesdotol:`⪄`,gesl:`⋛︀`,gesles:`⪔`,Gfr:`𝔊`,gfr:`𝔤`,Gg:`⋙`,gg:`≫`,ggg:`⋙`,gimel:`ℷ`,GJcy:`Ѓ`,gjcy:`ѓ`,gl:`≷`,gla:`⪥`,glE:`⪒`,glj:`⪤`,gnap:`⪊`,gnapprox:`⪊`,gnE:`≩`,gne:`⪈`,gneq:`⪈`,gneqq:`≩`,gnsim:`⋧`,Gopf:`𝔾`,gopf:`𝕘`,grave:"`",GreaterEqual:`≥`,GreaterEqualLess:`⋛`,GreaterFullEqual:`≧`,GreaterGreater:`⪢`,GreaterLess:`≷`,GreaterSlantEqual:`⩾`,GreaterTilde:`≳`,Gscr:`𝒢`,gscr:`ℊ`,gsim:`≳`,gsime:`⪎`,gsiml:`⪐`,Gt:`≫`,GT:`>`,gt:`>`,gtcc:`⪧`,gtcir:`⩺`,gtdot:`⋗`,gtlPar:`⦕`,gtquest:`⩼`,gtrapprox:`⪆`,gtrarr:`⥸`,gtrdot:`⋗`,gtreqless:`⋛`,gtreqqless:`⪌`,gtrless:`≷`,gtrsim:`≳`,gvertneqq:`≩︀`,gvnE:`≩︀`,Hacek:`ˇ`,hairsp:` `,half:`½`,hamilt:`ℋ`,HARDcy:`Ъ`,hardcy:`ъ`,hArr:`⇔`,harr:`↔`,harrcir:`⥈`,harrw:`↭`,Hat:`^`,hbar:`ℏ`,Hcirc:`Ĥ`,hcirc:`ĥ`,hearts:`♥`,heartsuit:`♥`,hellip:`…`,hercon:`⊹`,Hfr:`ℌ`,hfr:`𝔥`,HilbertSpace:`ℋ`,hksearow:`⤥`,hkswarow:`⤦`,hoarr:`⇿`,homtht:`∻`,hookleftarrow:`↩`,hookrightarrow:`↪`,Hopf:`ℍ`,hopf:`𝕙`,horbar:`―`,HorizontalLine:`─`,Hscr:`ℋ`,hscr:`𝒽`,hslash:`ℏ`,Hstrok:`Ħ`,hstrok:`ħ`,HumpDownHump:`≎`,HumpEqual:`≏`,hybull:`⁃`,hyphen:`‐`,Iacute:`Í`,iacute:`í`,ic:`⁣`,Icirc:`Î`,icirc:`î`,Icy:`И`,icy:`и`,Idot:`İ`,IEcy:`Е`,iecy:`е`,iexcl:`¡`,iff:`⇔`,Ifr:`ℑ`,ifr:`𝔦`,Igrave:`Ì`,igrave:`ì`,ii:`ⅈ`,iiiint:`⨌`,iiint:`∭`,iinfin:`⧜`,iiota:`℩`,IJlig:`Ĳ`,ijlig:`ĳ`,Im:`ℑ`,Imacr:`Ī`,imacr:`ī`,image:`ℑ`,ImaginaryI:`ⅈ`,imagline:`ℐ`,imagpart:`ℑ`,imath:`ı`,imof:`⊷`,imped:`Ƶ`,Implies:`⇒`,in:`∈`,incare:`℅`,infin:`∞`,infintie:`⧝`,inodot:`ı`,Int:`∬`,int:`∫`,intcal:`⊺`,integers:`ℤ`,Integral:`∫`,intercal:`⊺`,Intersection:`⋂`,intlarhk:`⨗`,intprod:`⨼`,InvisibleComma:`⁣`,InvisibleTimes:`⁢`,IOcy:`Ё`,iocy:`ё`,Iogon:`Į`,iogon:`į`,Iopf:`𝕀`,iopf:`𝕚`,Iota:`Ι`,iota:`ι`,iprod:`⨼`,iquest:`¿`,Iscr:`ℐ`,iscr:`𝒾`,isin:`∈`,isindot:`⋵`,isinE:`⋹`,isins:`⋴`,isinsv:`⋳`,isinv:`∈`,it:`⁢`,Itilde:`Ĩ`,itilde:`ĩ`,Iukcy:`І`,iukcy:`і`,Iuml:`Ï`,iuml:`ï`,Jcirc:`Ĵ`,jcirc:`ĵ`,Jcy:`Й`,jcy:`й`,Jfr:`𝔍`,jfr:`𝔧`,jmath:`ȷ`,Jopf:`𝕁`,jopf:`𝕛`,Jscr:`𝒥`,jscr:`𝒿`,Jsercy:`Ј`,jsercy:`ј`,Jukcy:`Є`,jukcy:`є`,Kappa:`Κ`,kappa:`κ`,kappav:`ϰ`,Kcedil:`Ķ`,kcedil:`ķ`,Kcy:`К`,kcy:`к`,Kfr:`𝔎`,kfr:`𝔨`,kgreen:`ĸ`,KHcy:`Х`,khcy:`х`,KJcy:`Ќ`,kjcy:`ќ`,Kopf:`𝕂`,kopf:`𝕜`,Kscr:`𝒦`,kscr:`𝓀`,lAarr:`⇚`,Lacute:`Ĺ`,lacute:`ĺ`,laemptyv:`⦴`,lagran:`ℒ`,Lambda:`Λ`,lambda:`λ`,Lang:`⟪`,lang:`⟨`,langd:`⦑`,langle:`⟨`,lap:`⪅`,Laplacetrf:`ℒ`,laquo:`«`,Larr:`↞`,lArr:`⇐`,larr:`←`,larrb:`⇤`,larrbfs:`⤟`,larrfs:`⤝`,larrhk:`↩`,larrlp:`↫`,larrpl:`⤹`,larrsim:`⥳`,larrtl:`↢`,lat:`⪫`,lAtail:`⤛`,latail:`⤙`,late:`⪭`,lates:`⪭︀`,lBarr:`⤎`,lbarr:`⤌`,lbbrk:`❲`,lbrace:`{`,lbrack:`[`,lbrke:`⦋`,lbrksld:`⦏`,lbrkslu:`⦍`,Lcaron:`Ľ`,lcaron:`ľ`,Lcedil:`Ļ`,lcedil:`ļ`,lceil:`⌈`,lcub:`{`,Lcy:`Л`,lcy:`л`,ldca:`⤶`,ldquo:`“`,ldquor:`„`,ldrdhar:`⥧`,ldrushar:`⥋`,ldsh:`↲`,lE:`≦`,le:`≤`,LeftAngleBracket:`⟨`,LeftArrow:`←`,Leftarrow:`⇐`,leftarrow:`←`,LeftArrowBar:`⇤`,LeftArrowRightArrow:`⇆`,leftarrowtail:`↢`,LeftCeiling:`⌈`,LeftDoubleBracket:`⟦`,LeftDownTeeVector:`⥡`,LeftDownVector:`⇃`,LeftDownVectorBar:`⥙`,LeftFloor:`⌊`,leftharpoondown:`↽`,leftharpoonup:`↼`,leftleftarrows:`⇇`,LeftRightArrow:`↔`,Leftrightarrow:`⇔`,leftrightarrow:`↔`,leftrightarrows:`⇆`,leftrightharpoons:`⇋`,leftrightsquigarrow:`↭`,LeftRightVector:`⥎`,LeftTee:`⊣`,LeftTeeArrow:`↤`,LeftTeeVector:`⥚`,leftthreetimes:`⋋`,LeftTriangle:`⊲`,LeftTriangleBar:`⧏`,LeftTriangleEqual:`⊴`,LeftUpDownVector:`⥑`,LeftUpTeeVector:`⥠`,LeftUpVector:`↿`,LeftUpVectorBar:`⥘`,LeftVector:`↼`,LeftVectorBar:`⥒`,lEg:`⪋`,leg:`⋚`,leq:`≤`,leqq:`≦`,leqslant:`⩽`,les:`⩽`,lescc:`⪨`,lesdot:`⩿`,lesdoto:`⪁`,lesdotor:`⪃`,lesg:`⋚︀`,lesges:`⪓`,lessapprox:`⪅`,lessdot:`⋖`,lesseqgtr:`⋚`,lesseqqgtr:`⪋`,LessEqualGreater:`⋚`,LessFullEqual:`≦`,LessGreater:`≶`,lessgtr:`≶`,LessLess:`⪡`,lesssim:`≲`,LessSlantEqual:`⩽`,LessTilde:`≲`,lfisht:`⥼`,lfloor:`⌊`,Lfr:`𝔏`,lfr:`𝔩`,lg:`≶`,lgE:`⪑`,lHar:`⥢`,lhard:`↽`,lharu:`↼`,lharul:`⥪`,lhblk:`▄`,LJcy:`Љ`,ljcy:`љ`,Ll:`⋘`,ll:`≪`,llarr:`⇇`,llcorner:`⌞`,Lleftarrow:`⇚`,llhard:`⥫`,lltri:`◺`,Lmidot:`Ŀ`,lmidot:`ŀ`,lmoust:`⎰`,lmoustache:`⎰`,lnap:`⪉`,lnapprox:`⪉`,lnE:`≨`,lne:`⪇`,lneq:`⪇`,lneqq:`≨`,lnsim:`⋦`,loang:`⟬`,loarr:`⇽`,lobrk:`⟦`,LongLeftArrow:`⟵`,Longleftarrow:`⟸`,longleftarrow:`⟵`,LongLeftRightArrow:`⟷`,Longleftrightarrow:`⟺`,longleftrightarrow:`⟷`,longmapsto:`⟼`,LongRightArrow:`⟶`,Longrightarrow:`⟹`,longrightarrow:`⟶`,looparrowleft:`↫`,looparrowright:`↬`,lopar:`⦅`,Lopf:`𝕃`,lopf:`𝕝`,loplus:`⨭`,lotimes:`⨴`,lowast:`∗`,lowbar:`_`,LowerLeftArrow:`↙`,LowerRightArrow:`↘`,loz:`◊`,lozenge:`◊`,lozf:`⧫`,lpar:`(`,lparlt:`⦓`,lrarr:`⇆`,lrcorner:`⌟`,lrhar:`⇋`,lrhard:`⥭`,lrm:`‎`,lrtri:`⊿`,lsaquo:`‹`,Lscr:`ℒ`,lscr:`𝓁`,Lsh:`↰`,lsh:`↰`,lsim:`≲`,lsime:`⪍`,lsimg:`⪏`,lsqb:`[`,lsquo:`‘`,lsquor:`‚`,Lstrok:`Ł`,lstrok:`ł`,Lt:`≪`,LT:`<`,lt:`<`,ltcc:`⪦`,ltcir:`⩹`,ltdot:`⋖`,lthree:`⋋`,ltimes:`⋉`,ltlarr:`⥶`,ltquest:`⩻`,ltri:`◃`,ltrie:`⊴`,ltrif:`◂`,ltrPar:`⦖`,lurdshar:`⥊`,luruhar:`⥦`,lvertneqq:`≨︀`,lvnE:`≨︀`,macr:`¯`,male:`♂`,malt:`✠`,maltese:`✠`,Map:`⤅`,map:`↦`,mapsto:`↦`,mapstodown:`↧`,mapstoleft:`↤`,mapstoup:`↥`,marker:`▮`,mcomma:`⨩`,Mcy:`М`,mcy:`м`,mdash:`—`,mDDot:`∺`,measuredangle:`∡`,MediumSpace:` `,Mellintrf:`ℳ`,Mfr:`𝔐`,mfr:`𝔪`,mho:`℧`,micro:`µ`,mid:`∣`,midast:`*`,midcir:`⫰`,middot:`·`,minus:`−`,minusb:`⊟`,minusd:`∸`,minusdu:`⨪`,MinusPlus:`∓`,mlcp:`⫛`,mldr:`…`,mnplus:`∓`,models:`⊧`,Mopf:`𝕄`,mopf:`𝕞`,mp:`∓`,Mscr:`ℳ`,mscr:`𝓂`,mstpos:`∾`,Mu:`Μ`,mu:`μ`,multimap:`⊸`,mumap:`⊸`,nabla:`∇`,Nacute:`Ń`,nacute:`ń`,nang:`∠⃒`,nap:`≉`,napE:`⩰̸`,napid:`≋̸`,napos:`ŉ`,napprox:`≉`,natur:`♮`,natural:`♮`,naturals:`ℕ`,nbsp:`\xA0`,nbump:`≎̸`,nbumpe:`≏̸`,ncap:`⩃`,Ncaron:`Ň`,ncaron:`ň`,Ncedil:`Ņ`,ncedil:`ņ`,ncong:`≇`,ncongdot:`⩭̸`,ncup:`⩂`,Ncy:`Н`,ncy:`н`,ndash:`–`,ne:`≠`,nearhk:`⤤`,neArr:`⇗`,nearr:`↗`,nearrow:`↗`,nedot:`≐̸`,NegativeMediumSpace:`​`,NegativeThickSpace:`​`,NegativeThinSpace:`​`,NegativeVeryThinSpace:`​`,nequiv:`≢`,nesear:`⤨`,nesim:`≂̸`,NestedGreaterGreater:`≫`,NestedLessLess:`≪`,NewLine:`
`,nexist:`∄`,nexists:`∄`,Nfr:`𝔑`,nfr:`𝔫`,ngE:`≧̸`,nge:`≱`,ngeq:`≱`,ngeqq:`≧̸`,ngeqslant:`⩾̸`,nges:`⩾̸`,nGg:`⋙̸`,ngsim:`≵`,nGt:`≫⃒`,ngt:`≯`,ngtr:`≯`,nGtv:`≫̸`,nhArr:`⇎`,nharr:`↮`,nhpar:`⫲`,ni:`∋`,nis:`⋼`,nisd:`⋺`,niv:`∋`,NJcy:`Њ`,njcy:`њ`,nlArr:`⇍`,nlarr:`↚`,nldr:`‥`,nlE:`≦̸`,nle:`≰`,nLeftarrow:`⇍`,nleftarrow:`↚`,nLeftrightarrow:`⇎`,nleftrightarrow:`↮`,nleq:`≰`,nleqq:`≦̸`,nleqslant:`⩽̸`,nles:`⩽̸`,nless:`≮`,nLl:`⋘̸`,nlsim:`≴`,nLt:`≪⃒`,nlt:`≮`,nltri:`⋪`,nltrie:`⋬`,nLtv:`≪̸`,nmid:`∤`,NoBreak:`⁠`,NonBreakingSpace:`\xA0`,Nopf:`ℕ`,nopf:`𝕟`,Not:`⫬`,not:`¬`,NotCongruent:`≢`,NotCupCap:`≭`,NotDoubleVerticalBar:`∦`,NotElement:`∉`,NotEqual:`≠`,NotEqualTilde:`≂̸`,NotExists:`∄`,NotGreater:`≯`,NotGreaterEqual:`≱`,NotGreaterFullEqual:`≧̸`,NotGreaterGreater:`≫̸`,NotGreaterLess:`≹`,NotGreaterSlantEqual:`⩾̸`,NotGreaterTilde:`≵`,NotHumpDownHump:`≎̸`,NotHumpEqual:`≏̸`,notin:`∉`,notindot:`⋵̸`,notinE:`⋹̸`,notinva:`∉`,notinvb:`⋷`,notinvc:`⋶`,NotLeftTriangle:`⋪`,NotLeftTriangleBar:`⧏̸`,NotLeftTriangleEqual:`⋬`,NotLess:`≮`,NotLessEqual:`≰`,NotLessGreater:`≸`,NotLessLess:`≪̸`,NotLessSlantEqual:`⩽̸`,NotLessTilde:`≴`,NotNestedGreaterGreater:`⪢̸`,NotNestedLessLess:`⪡̸`,notni:`∌`,notniva:`∌`,notnivb:`⋾`,notnivc:`⋽`,NotPrecedes:`⊀`,NotPrecedesEqual:`⪯̸`,NotPrecedesSlantEqual:`⋠`,NotReverseElement:`∌`,NotRightTriangle:`⋫`,NotRightTriangleBar:`⧐̸`,NotRightTriangleEqual:`⋭`,NotSquareSubset:`⊏̸`,NotSquareSubsetEqual:`⋢`,NotSquareSuperset:`⊐̸`,NotSquareSupersetEqual:`⋣`,NotSubset:`⊂⃒`,NotSubsetEqual:`⊈`,NotSucceeds:`⊁`,NotSucceedsEqual:`⪰̸`,NotSucceedsSlantEqual:`⋡`,NotSucceedsTilde:`≿̸`,NotSuperset:`⊃⃒`,NotSupersetEqual:`⊉`,NotTilde:`≁`,NotTildeEqual:`≄`,NotTildeFullEqual:`≇`,NotTildeTilde:`≉`,NotVerticalBar:`∤`,npar:`∦`,nparallel:`∦`,nparsl:`⫽⃥`,npart:`∂̸`,npolint:`⨔`,npr:`⊀`,nprcue:`⋠`,npre:`⪯̸`,nprec:`⊀`,npreceq:`⪯̸`,nrArr:`⇏`,nrarr:`↛`,nrarrc:`⤳̸`,nrarrw:`↝̸`,nRightarrow:`⇏`,nrightarrow:`↛`,nrtri:`⋫`,nrtrie:`⋭`,nsc:`⊁`,nsccue:`⋡`,nsce:`⪰̸`,Nscr:`𝒩`,nscr:`𝓃`,nshortmid:`∤`,nshortparallel:`∦`,nsim:`≁`,nsime:`≄`,nsimeq:`≄`,nsmid:`∤`,nspar:`∦`,nsqsube:`⋢`,nsqsupe:`⋣`,nsub:`⊄`,nsubE:`⫅̸`,nsube:`⊈`,nsubset:`⊂⃒`,nsubseteq:`⊈`,nsubseteqq:`⫅̸`,nsucc:`⊁`,nsucceq:`⪰̸`,nsup:`⊅`,nsupE:`⫆̸`,nsupe:`⊉`,nsupset:`⊃⃒`,nsupseteq:`⊉`,nsupseteqq:`⫆̸`,ntgl:`≹`,Ntilde:`Ñ`,ntilde:`ñ`,ntlg:`≸`,ntriangleleft:`⋪`,ntrianglelefteq:`⋬`,ntriangleright:`⋫`,ntrianglerighteq:`⋭`,Nu:`Ν`,nu:`ν`,num:`#`,numero:`№`,numsp:` `,nvap:`≍⃒`,nVDash:`⊯`,nVdash:`⊮`,nvDash:`⊭`,nvdash:`⊬`,nvge:`≥⃒`,nvgt:`>⃒`,nvHarr:`⤄`,nvinfin:`⧞`,nvlArr:`⤂`,nvle:`≤⃒`,nvlt:`<⃒`,nvltrie:`⊴⃒`,nvrArr:`⤃`,nvrtrie:`⊵⃒`,nvsim:`∼⃒`,nwarhk:`⤣`,nwArr:`⇖`,nwarr:`↖`,nwarrow:`↖`,nwnear:`⤧`,Oacute:`Ó`,oacute:`ó`,oast:`⊛`,ocir:`⊚`,Ocirc:`Ô`,ocirc:`ô`,Ocy:`О`,ocy:`о`,odash:`⊝`,Odblac:`Ő`,odblac:`ő`,odiv:`⨸`,odot:`⊙`,odsold:`⦼`,OElig:`Œ`,oelig:`œ`,ofcir:`⦿`,Ofr:`𝔒`,ofr:`𝔬`,ogon:`˛`,Ograve:`Ò`,ograve:`ò`,ogt:`⧁`,ohbar:`⦵`,ohm:`Ω`,oint:`∮`,olarr:`↺`,olcir:`⦾`,olcross:`⦻`,oline:`‾`,olt:`⧀`,Omacr:`Ō`,omacr:`ō`,Omega:`Ω`,omega:`ω`,Omicron:`Ο`,omicron:`ο`,omid:`⦶`,ominus:`⊖`,Oopf:`𝕆`,oopf:`𝕠`,opar:`⦷`,OpenCurlyDoubleQuote:`“`,OpenCurlyQuote:`‘`,operp:`⦹`,oplus:`⊕`,Or:`⩔`,or:`∨`,orarr:`↻`,ord:`⩝`,order:`ℴ`,orderof:`ℴ`,ordf:`ª`,ordm:`º`,origof:`⊶`,oror:`⩖`,orslope:`⩗`,orv:`⩛`,oS:`Ⓢ`,Oscr:`𝒪`,oscr:`ℴ`,Oslash:`Ø`,oslash:`ø`,osol:`⊘`,Otilde:`Õ`,otilde:`õ`,Otimes:`⨷`,otimes:`⊗`,otimesas:`⨶`,Ouml:`Ö`,ouml:`ö`,ovbar:`⌽`,OverBar:`‾`,OverBrace:`⏞`,OverBracket:`⎴`,OverParenthesis:`⏜`,par:`∥`,para:`¶`,parallel:`∥`,parsim:`⫳`,parsl:`⫽`,part:`∂`,PartialD:`∂`,Pcy:`П`,pcy:`п`,percnt:`%`,period:`.`,permil:`‰`,perp:`⊥`,pertenk:`‱`,Pfr:`𝔓`,pfr:`𝔭`,Phi:`Φ`,phi:`φ`,phiv:`ϕ`,phmmat:`ℳ`,phone:`☎`,Pi:`Π`,pi:`π`,pitchfork:`⋔`,piv:`ϖ`,planck:`ℏ`,planckh:`ℎ`,plankv:`ℏ`,plus:`+`,plusacir:`⨣`,plusb:`⊞`,pluscir:`⨢`,plusdo:`∔`,plusdu:`⨥`,pluse:`⩲`,PlusMinus:`±`,plusmn:`±`,plussim:`⨦`,plustwo:`⨧`,pm:`±`,Poincareplane:`ℌ`,pointint:`⨕`,Popf:`ℙ`,popf:`𝕡`,pound:`£`,Pr:`⪻`,pr:`≺`,prap:`⪷`,prcue:`≼`,prE:`⪳`,pre:`⪯`,prec:`≺`,precapprox:`⪷`,preccurlyeq:`≼`,Precedes:`≺`,PrecedesEqual:`⪯`,PrecedesSlantEqual:`≼`,PrecedesTilde:`≾`,preceq:`⪯`,precnapprox:`⪹`,precneqq:`⪵`,precnsim:`⋨`,precsim:`≾`,Prime:`″`,prime:`′`,primes:`ℙ`,prnap:`⪹`,prnE:`⪵`,prnsim:`⋨`,prod:`∏`,Product:`∏`,profalar:`⌮`,profline:`⌒`,profsurf:`⌓`,prop:`∝`,Proportion:`∷`,Proportional:`∝`,propto:`∝`,prsim:`≾`,prurel:`⊰`,Pscr:`𝒫`,pscr:`𝓅`,Psi:`Ψ`,psi:`ψ`,puncsp:` `,Qfr:`𝔔`,qfr:`𝔮`,qint:`⨌`,Qopf:`ℚ`,qopf:`𝕢`,qprime:`⁗`,Qscr:`𝒬`,qscr:`𝓆`,quaternions:`ℍ`,quatint:`⨖`,quest:`?`,questeq:`≟`,QUOT:`"`,quot:`"`,rAarr:`⇛`,race:`∽̱`,Racute:`Ŕ`,racute:`ŕ`,radic:`√`,raemptyv:`⦳`,Rang:`⟫`,rang:`⟩`,rangd:`⦒`,range:`⦥`,rangle:`⟩`,raquo:`»`,Rarr:`↠`,rArr:`⇒`,rarr:`→`,rarrap:`⥵`,rarrb:`⇥`,rarrbfs:`⤠`,rarrc:`⤳`,rarrfs:`⤞`,rarrhk:`↪`,rarrlp:`↬`,rarrpl:`⥅`,rarrsim:`⥴`,Rarrtl:`⤖`,rarrtl:`↣`,rarrw:`↝`,rAtail:`⤜`,ratail:`⤚`,ratio:`∶`,rationals:`ℚ`,RBarr:`⤐`,rBarr:`⤏`,rbarr:`⤍`,rbbrk:`❳`,rbrace:`}`,rbrack:`]`,rbrke:`⦌`,rbrksld:`⦎`,rbrkslu:`⦐`,Rcaron:`Ř`,rcaron:`ř`,Rcedil:`Ŗ`,rcedil:`ŗ`,rceil:`⌉`,rcub:`}`,Rcy:`Р`,rcy:`р`,rdca:`⤷`,rdldhar:`⥩`,rdquo:`”`,rdquor:`”`,rdsh:`↳`,Re:`ℜ`,real:`ℜ`,realine:`ℛ`,realpart:`ℜ`,reals:`ℝ`,rect:`▭`,REG:`®`,reg:`®`,ReverseElement:`∋`,ReverseEquilibrium:`⇋`,ReverseUpEquilibrium:`⥯`,rfisht:`⥽`,rfloor:`⌋`,Rfr:`ℜ`,rfr:`𝔯`,rHar:`⥤`,rhard:`⇁`,rharu:`⇀`,rharul:`⥬`,Rho:`Ρ`,rho:`ρ`,rhov:`ϱ`,RightAngleBracket:`⟩`,RightArrow:`→`,Rightarrow:`⇒`,rightarrow:`→`,RightArrowBar:`⇥`,RightArrowLeftArrow:`⇄`,rightarrowtail:`↣`,RightCeiling:`⌉`,RightDoubleBracket:`⟧`,RightDownTeeVector:`⥝`,RightDownVector:`⇂`,RightDownVectorBar:`⥕`,RightFloor:`⌋`,rightharpoondown:`⇁`,rightharpoonup:`⇀`,rightleftarrows:`⇄`,rightleftharpoons:`⇌`,rightrightarrows:`⇉`,rightsquigarrow:`↝`,RightTee:`⊢`,RightTeeArrow:`↦`,RightTeeVector:`⥛`,rightthreetimes:`⋌`,RightTriangle:`⊳`,RightTriangleBar:`⧐`,RightTriangleEqual:`⊵`,RightUpDownVector:`⥏`,RightUpTeeVector:`⥜`,RightUpVector:`↾`,RightUpVectorBar:`⥔`,RightVector:`⇀`,RightVectorBar:`⥓`,ring:`˚`,risingdotseq:`≓`,rlarr:`⇄`,rlhar:`⇌`,rlm:`‏`,rmoust:`⎱`,rmoustache:`⎱`,rnmid:`⫮`,roang:`⟭`,roarr:`⇾`,robrk:`⟧`,ropar:`⦆`,Ropf:`ℝ`,ropf:`𝕣`,roplus:`⨮`,rotimes:`⨵`,RoundImplies:`⥰`,rpar:`)`,rpargt:`⦔`,rppolint:`⨒`,rrarr:`⇉`,Rrightarrow:`⇛`,rsaquo:`›`,Rscr:`ℛ`,rscr:`𝓇`,Rsh:`↱`,rsh:`↱`,rsqb:`]`,rsquo:`’`,rsquor:`’`,rthree:`⋌`,rtimes:`⋊`,rtri:`▹`,rtrie:`⊵`,rtrif:`▸`,rtriltri:`⧎`,RuleDelayed:`⧴`,ruluhar:`⥨`,rx:`℞`,Sacute:`Ś`,sacute:`ś`,sbquo:`‚`,Sc:`⪼`,sc:`≻`,scap:`⪸`,Scaron:`Š`,scaron:`š`,sccue:`≽`,scE:`⪴`,sce:`⪰`,Scedil:`Ş`,scedil:`ş`,Scirc:`Ŝ`,scirc:`ŝ`,scnap:`⪺`,scnE:`⪶`,scnsim:`⋩`,scpolint:`⨓`,scsim:`≿`,Scy:`С`,scy:`с`,sdot:`⋅`,sdotb:`⊡`,sdote:`⩦`,searhk:`⤥`,seArr:`⇘`,searr:`↘`,searrow:`↘`,sect:`§`,semi:`;`,seswar:`⤩`,setminus:`∖`,setmn:`∖`,sext:`✶`,Sfr:`𝔖`,sfr:`𝔰`,sfrown:`⌢`,sharp:`♯`,SHCHcy:`Щ`,shchcy:`щ`,SHcy:`Ш`,shcy:`ш`,ShortDownArrow:`↓`,ShortLeftArrow:`←`,shortmid:`∣`,shortparallel:`∥`,ShortRightArrow:`→`,ShortUpArrow:`↑`,shy:`­`,Sigma:`Σ`,sigma:`σ`,sigmaf:`ς`,sigmav:`ς`,sim:`∼`,simdot:`⩪`,sime:`≃`,simeq:`≃`,simg:`⪞`,simgE:`⪠`,siml:`⪝`,simlE:`⪟`,simne:`≆`,simplus:`⨤`,simrarr:`⥲`,slarr:`←`,SmallCircle:`∘`,smallsetminus:`∖`,smashp:`⨳`,smeparsl:`⧤`,smid:`∣`,smile:`⌣`,smt:`⪪`,smte:`⪬`,smtes:`⪬︀`,SOFTcy:`Ь`,softcy:`ь`,sol:`/`,solb:`⧄`,solbar:`⌿`,Sopf:`𝕊`,sopf:`𝕤`,spades:`♠`,spadesuit:`♠`,spar:`∥`,sqcap:`⊓`,sqcaps:`⊓︀`,sqcup:`⊔`,sqcups:`⊔︀`,Sqrt:`√`,sqsub:`⊏`,sqsube:`⊑`,sqsubset:`⊏`,sqsubseteq:`⊑`,sqsup:`⊐`,sqsupe:`⊒`,sqsupset:`⊐`,sqsupseteq:`⊒`,squ:`□`,Square:`□`,square:`□`,SquareIntersection:`⊓`,SquareSubset:`⊏`,SquareSubsetEqual:`⊑`,SquareSuperset:`⊐`,SquareSupersetEqual:`⊒`,SquareUnion:`⊔`,squarf:`▪`,squf:`▪`,srarr:`→`,Sscr:`𝒮`,sscr:`𝓈`,ssetmn:`∖`,ssmile:`⌣`,sstarf:`⋆`,Star:`⋆`,star:`☆`,starf:`★`,straightepsilon:`ϵ`,straightphi:`ϕ`,strns:`¯`,Sub:`⋐`,sub:`⊂`,subdot:`⪽`,subE:`⫅`,sube:`⊆`,subedot:`⫃`,submult:`⫁`,subnE:`⫋`,subne:`⊊`,subplus:`⪿`,subrarr:`⥹`,Subset:`⋐`,subset:`⊂`,subseteq:`⊆`,subseteqq:`⫅`,SubsetEqual:`⊆`,subsetneq:`⊊`,subsetneqq:`⫋`,subsim:`⫇`,subsub:`⫕`,subsup:`⫓`,succ:`≻`,succapprox:`⪸`,succcurlyeq:`≽`,Succeeds:`≻`,SucceedsEqual:`⪰`,SucceedsSlantEqual:`≽`,SucceedsTilde:`≿`,succeq:`⪰`,succnapprox:`⪺`,succneqq:`⪶`,succnsim:`⋩`,succsim:`≿`,SuchThat:`∋`,Sum:`∑`,sum:`∑`,sung:`♪`,Sup:`⋑`,sup:`⊃`,sup1:`¹`,sup2:`²`,sup3:`³`,supdot:`⪾`,supdsub:`⫘`,supE:`⫆`,supe:`⊇`,supedot:`⫄`,Superset:`⊃`,SupersetEqual:`⊇`,suphsol:`⟉`,suphsub:`⫗`,suplarr:`⥻`,supmult:`⫂`,supnE:`⫌`,supne:`⊋`,supplus:`⫀`,Supset:`⋑`,supset:`⊃`,supseteq:`⊇`,supseteqq:`⫆`,supsetneq:`⊋`,supsetneqq:`⫌`,supsim:`⫈`,supsub:`⫔`,supsup:`⫖`,swarhk:`⤦`,swArr:`⇙`,swarr:`↙`,swarrow:`↙`,swnwar:`⤪`,szlig:`ß`,Tab:`	`,target:`⌖`,Tau:`Τ`,tau:`τ`,tbrk:`⎴`,Tcaron:`Ť`,tcaron:`ť`,Tcedil:`Ţ`,tcedil:`ţ`,Tcy:`Т`,tcy:`т`,tdot:`⃛`,telrec:`⌕`,Tfr:`𝔗`,tfr:`𝔱`,there4:`∴`,Therefore:`∴`,therefore:`∴`,Theta:`Θ`,theta:`θ`,thetasym:`ϑ`,thetav:`ϑ`,thickapprox:`≈`,thicksim:`∼`,ThickSpace:`  `,thinsp:` `,ThinSpace:` `,thkap:`≈`,thksim:`∼`,THORN:`Þ`,thorn:`þ`,Tilde:`∼`,tilde:`˜`,TildeEqual:`≃`,TildeFullEqual:`≅`,TildeTilde:`≈`,times:`×`,timesb:`⊠`,timesbar:`⨱`,timesd:`⨰`,tint:`∭`,toea:`⤨`,top:`⊤`,topbot:`⌶`,topcir:`⫱`,Topf:`𝕋`,topf:`𝕥`,topfork:`⫚`,tosa:`⤩`,tprime:`‴`,TRADE:`™`,trade:`™`,triangle:`▵`,triangledown:`▿`,triangleleft:`◃`,trianglelefteq:`⊴`,triangleq:`≜`,triangleright:`▹`,trianglerighteq:`⊵`,tridot:`◬`,trie:`≜`,triminus:`⨺`,TripleDot:`⃛`,triplus:`⨹`,trisb:`⧍`,tritime:`⨻`,trpezium:`⏢`,Tscr:`𝒯`,tscr:`𝓉`,TScy:`Ц`,tscy:`ц`,TSHcy:`Ћ`,tshcy:`ћ`,Tstrok:`Ŧ`,tstrok:`ŧ`,twixt:`≬`,twoheadleftarrow:`↞`,twoheadrightarrow:`↠`,Uacute:`Ú`,uacute:`ú`,Uarr:`↟`,uArr:`⇑`,uarr:`↑`,Uarrocir:`⥉`,Ubrcy:`Ў`,ubrcy:`ў`,Ubreve:`Ŭ`,ubreve:`ŭ`,Ucirc:`Û`,ucirc:`û`,Ucy:`У`,ucy:`у`,udarr:`⇅`,Udblac:`Ű`,udblac:`ű`,udhar:`⥮`,ufisht:`⥾`,Ufr:`𝔘`,ufr:`𝔲`,Ugrave:`Ù`,ugrave:`ù`,uHar:`⥣`,uharl:`↿`,uharr:`↾`,uhblk:`▀`,ulcorn:`⌜`,ulcorner:`⌜`,ulcrop:`⌏`,ultri:`◸`,Umacr:`Ū`,umacr:`ū`,uml:`¨`,UnderBar:`_`,UnderBrace:`⏟`,UnderBracket:`⎵`,UnderParenthesis:`⏝`,Union:`⋃`,UnionPlus:`⊎`,Uogon:`Ų`,uogon:`ų`,Uopf:`𝕌`,uopf:`𝕦`,UpArrow:`↑`,Uparrow:`⇑`,uparrow:`↑`,UpArrowBar:`⤒`,UpArrowDownArrow:`⇅`,UpDownArrow:`↕`,Updownarrow:`⇕`,updownarrow:`↕`,UpEquilibrium:`⥮`,upharpoonleft:`↿`,upharpoonright:`↾`,uplus:`⊎`,UpperLeftArrow:`↖`,UpperRightArrow:`↗`,Upsi:`ϒ`,upsi:`υ`,upsih:`ϒ`,Upsilon:`Υ`,upsilon:`υ`,UpTee:`⊥`,UpTeeArrow:`↥`,upuparrows:`⇈`,urcorn:`⌝`,urcorner:`⌝`,urcrop:`⌎`,Uring:`Ů`,uring:`ů`,urtri:`◹`,Uscr:`𝒰`,uscr:`𝓊`,utdot:`⋰`,Utilde:`Ũ`,utilde:`ũ`,utri:`▵`,utrif:`▴`,uuarr:`⇈`,Uuml:`Ü`,uuml:`ü`,uwangle:`⦧`,vangrt:`⦜`,varepsilon:`ϵ`,varkappa:`ϰ`,varnothing:`∅`,varphi:`ϕ`,varpi:`ϖ`,varpropto:`∝`,vArr:`⇕`,varr:`↕`,varrho:`ϱ`,varsigma:`ς`,varsubsetneq:`⊊︀`,varsubsetneqq:`⫋︀`,varsupsetneq:`⊋︀`,varsupsetneqq:`⫌︀`,vartheta:`ϑ`,vartriangleleft:`⊲`,vartriangleright:`⊳`,Vbar:`⫫`,vBar:`⫨`,vBarv:`⫩`,Vcy:`В`,vcy:`в`,VDash:`⊫`,Vdash:`⊩`,vDash:`⊨`,vdash:`⊢`,Vdashl:`⫦`,Vee:`⋁`,vee:`∨`,veebar:`⊻`,veeeq:`≚`,vellip:`⋮`,Verbar:`‖`,verbar:`|`,Vert:`‖`,vert:`|`,VerticalBar:`∣`,VerticalLine:`|`,VerticalSeparator:`❘`,VerticalTilde:`≀`,VeryThinSpace:` `,Vfr:`𝔙`,vfr:`𝔳`,vltri:`⊲`,vnsub:`⊂⃒`,vnsup:`⊃⃒`,Vopf:`𝕍`,vopf:`𝕧`,vprop:`∝`,vrtri:`⊳`,Vscr:`𝒱`,vscr:`𝓋`,vsubnE:`⫋︀`,vsubne:`⊊︀`,vsupnE:`⫌︀`,vsupne:`⊋︀`,Vvdash:`⊪`,vzigzag:`⦚`,Wcirc:`Ŵ`,wcirc:`ŵ`,wedbar:`⩟`,Wedge:`⋀`,wedge:`∧`,wedgeq:`≙`,weierp:`℘`,Wfr:`𝔚`,wfr:`𝔴`,Wopf:`𝕎`,wopf:`𝕨`,wp:`℘`,wr:`≀`,wreath:`≀`,Wscr:`𝒲`,wscr:`𝓌`,xcap:`⋂`,xcirc:`◯`,xcup:`⋃`,xdtri:`▽`,Xfr:`𝔛`,xfr:`𝔵`,xhArr:`⟺`,xharr:`⟷`,Xi:`Ξ`,xi:`ξ`,xlArr:`⟸`,xlarr:`⟵`,xmap:`⟼`,xnis:`⋻`,xodot:`⨀`,Xopf:`𝕏`,xopf:`𝕩`,xoplus:`⨁`,xotime:`⨂`,xrArr:`⟹`,xrarr:`⟶`,Xscr:`𝒳`,xscr:`𝓍`,xsqcup:`⨆`,xuplus:`⨄`,xutri:`△`,xvee:`⋁`,xwedge:`⋀`,Yacute:`Ý`,yacute:`ý`,YAcy:`Я`,yacy:`я`,Ycirc:`Ŷ`,ycirc:`ŷ`,Ycy:`Ы`,ycy:`ы`,yen:`¥`,Yfr:`𝔜`,yfr:`𝔶`,YIcy:`Ї`,yicy:`ї`,Yopf:`𝕐`,yopf:`𝕪`,Yscr:`𝒴`,yscr:`𝓎`,YUcy:`Ю`,yucy:`ю`,Yuml:`Ÿ`,yuml:`ÿ`,Zacute:`Ź`,zacute:`ź`,Zcaron:`Ž`,zcaron:`ž`,Zcy:`З`,zcy:`з`,Zdot:`Ż`,zdot:`ż`,zeetrf:`ℨ`,ZeroWidthSpace:`​`,Zeta:`Ζ`,zeta:`ζ`,Zfr:`ℨ`,zfr:`𝔷`,ZHcy:`Ж`,zhcy:`ж`,zigrarr:`⇝`,Zopf:`ℤ`,zopf:`𝕫`,Zscr:`𝒵`,zscr:`𝓏`,zwj:`‍`,zwnj:`‌`}),e.entityMap=e.HTML_ENTITIES})),go=n((e=>{var t=uo(),n=po(),r=fo(),i=t.isHTMLEscapableRawTextElement,a=t.isHTMLMimeType,o=t.isHTMLRawTextElement,s=t.hasOwn,c=t.NAMESPACE,l=r.ParseError,u=r.DOMException,d=0,f=1,p=2,m=3,h=4,g=5,_=6,v=7;function y(){}y.prototype={parse:function(e,t,n){var r=this.domBuilder;r.startDocument(),E(t,t=Object.create(null)),x(e,t,n,r,this.errorHandler),r.endDocument()}};var b=/&#?\w+;?/g;function x(e,r,i,o,c){var d=a(o.mimeType);e.indexOf(n.UNICODE_REPLACEMENT_CHARACTER)>=0&&c.warning(`Unicode replacement character detected, source encoding issues?`);function f(e){if(e>65535){e-=65536;var t=55296+(e>>10),n=56320+(e&1023);return String.fromCharCode(t,n)}else return String.fromCharCode(e)}function p(e){var t=e[e.length-1]===`;`?e:e+`;`;if(!d&&t!==e)return c.error(`EntityRef: expecting ;`),e;var r=n.Reference.exec(t);if(!r||r[0].length!==t.length)return c.error(`entity not matching Reference production: `+e),e;var a=t.slice(1,-1);return s(i,a)?i[a]:a.charAt(0)===`#`?f(parseInt(a.substring(1).replace(`x`,`0x`))):(c.error(`entity not found:`+e),e)}function m(t){if(t>D){var n=e.substring(D,t).replace(b,p);v&&y(D),o.characters(n,0,t-D),D=t}}var h=0,g=0,_=/\r\n?|\n|$/g,v=o.locator;function y(t,n){for(;t>=g&&(n=_.exec(e));)h=g,g=n.index+n[0].length,v.lineNumber++;v.columnNumber=t-h+1}for(var x=[{currentNSMap:r}],E=[],D=0;;){try{var O=e.indexOf(`<`,D);if(O<0){if(!d&&E.length>0)return c.fatalError(`unclosed xml tag(s): `+E.join(`, `));if(!e.substring(D).match(/^\s*$/)){var A=o.doc,j=A.createTextNode(e.substring(D));if(A.documentElement)return c.error(`Extra content at the end of the document`);A.appendChild(j),o.currentElement=j}return}if(O>D){var ne=e.substring(D,O);!d&&E.length===0&&(ne=ne.replace(new RegExp(n.S_OPT.source,`g`),``),ne&&c.error(`Unexpected content outside root element: '`+ne+`'`)),m(O)}switch(e.charAt(O+1)){case`/`:var M=e.indexOf(`>`,O+2),N=e.substring(O+2,M>0?M:void 0);if(!N)return c.fatalError(`end tag name missing`);var P=n.reg(`^`,n.QName_group,n.S_OPT,`$`),F=M>0&&P.exec(N);if(!F){var I=M>0&&n.reg(`^`,n.QName_group).exec(N);if(d&&I)c.warning(`end tag name contains invalid trailing characters: "`+N+`"`),F=I;else if(I&&new RegExp(P.source,P.flags+`m`).test(N))c.error(`end tag name is followed by a line break and trailing content: "`+N+`"`),F=I;else return c.fatalError(`end tag name contains invalid characters: "`+N+`"`)}if(!o.currentElement&&!o.doc.documentElement)return;var re=E[E.length-1]||o.currentElement.tagName||o.doc.documentElement.tagName||``;if(re!==F[1]){var L=F[1].toLowerCase();if(!d||re.toLowerCase()!==L)return c.fatalError(`Opening and ending tag mismatch: "`+re+`" != "`+N+`"`)}var R=x.pop();E.pop();var z=R.localNSMap;if(o.endElement(R.uri,R.localName,re),z)for(var ie in z)s(z,ie)&&o.endPrefixMapping(ie);M++;break;case`?`:v&&y(O),M=k(e,O,o,c);break;case`!`:v&&y(O),M=ee(e,O,o,c,d);break;default:v&&y(O);var ae=new te,oe=x[x.length-1].currentNSMap,M=C(e,O,ae,oe,p,c,d),se=ae.length;if(ae.closed||(d&&t.isHTMLVoidElement(ae.tagName)?ae.closed=!0:E.push(ae.tagName)),v&&se){for(var ce=S(v,{}),le=0;le<se;le++){var ue=ae[le];y(ue.offset),ue.locator=S(v,{})}o.locator=ce,w(ae,o,oe)&&x.push(ae),o.locator=v}else w(ae,o,oe)&&x.push(ae);d&&!ae.closed?M=T(e,M,ae.tagName,p,o):M++}}catch(e){if(e instanceof l)throw e;if(e instanceof u)return c.fatalError(`Error constructing the DOM: `+e.name+`: `+e.message,e);c.error(`element parse error: `+e),M=-1}M>D?D=M:m(Math.max(O,D)+1)}}function S(e,t){return t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber,t}function C(e,t,n,r,i,a,o){function c(e,t,r){if(s(n.attributeNames,e))return a.fatalError(`Attribute `+e+` redefined`);if(!o&&t.indexOf(`<`)>=0)return a.fatalError(`Unescaped '<' not allowed in attributes values`);n.addValue(e,t.replace(/[\t\n\r]/g,` `).replace(b,i),r)}for(var l,u,y=++t,x=d;;){var S=e.charAt(y);if(x===d&&S===`<`)throw Error(`unexpected < in tag name: `+e.slice(t,y));switch(S){case`=`:if(x===f)l=e.slice(t,y),x=m;else if(x===p)x=m;else throw Error(`attribute equal must after attrName`);break;case`'`:case`"`:if(x===m||x===f)if(x===f&&(a.warning(`attribute value must after "="`),l=e.slice(t,y)),t=y+1,y=e.indexOf(S,t),y>0)u=e.slice(t,y),c(l,u,t-1),x=g;else throw Error(`attribute value no end '`+S+`' match`);else if(x==h)u=e.slice(t,y),c(l,u,t),a.warning(`attribute "`+l+`" missed start quot(`+S+`)!!`),t=y+1,x=g;else throw Error(`attribute value must after "="`);break;case`/`:switch(x){case d:n.setTagName(e.slice(t,y));case g:case _:case v:x=v,n.closed=!0;case h:case f:break;case p:n.closed=!0;break;default:throw Error(`attribute invalid close char('/')`)}break;case``:return a.error(`unexpected end of input`),x==d&&n.setTagName(e.slice(t,y)),y;case`>`:switch(x){case d:n.setTagName(e.slice(t,y));case g:case _:case v:break;case h:case f:u=e.slice(t,y),u.slice(-1)===`/`&&(n.closed=!0,u=u.slice(0,-1));case p:x===p&&(u=l),x==h?(a.warning(`attribute "`+u+`" missed quot(")!`),c(l,u,t)):(o||a.warning(`attribute "`+u+`" missed value!! "`+u+`" instead!!`),c(u,u,t));break;case m:if(!o)return a.fatalError(`AttValue: ' or " expected`)}return y;case``:S=` `;default:if(S<=` `)switch(x){case d:n.setTagName(e.slice(t,y)),x=_;break;case f:l=e.slice(t,y),x=p;break;case h:var u=e.slice(t,y);a.warning(`attribute "`+u+`" missed quot(")!!`),c(l,u,t);case g:x=_;break}else switch(x){case p:o||a.warning(`attribute "`+l+`" missed value!! "`+l+`" instead2!!`),c(l,l,t),t=y,x=f;break;case g:a.warning(`attribute space is required"`+l+`"!!`);case _:x=f,t=y;break;case m:x=h,t=y;break;case v:throw Error(`elements closed character '/' and '>' must be connected to`)}}y++}}function w(e,t,n){for(var r=e.tagName,i=null,a=e.length;a--;){var o=e[a],l=o.qName,u=o.value,d=l.indexOf(`:`);if(d>0)var f=o.prefix=l.slice(0,d),p=l.slice(d+1),m=f===`xmlns`&&p;else p=l,f=null,m=l===`xmlns`&&``;o.localName=p,m!==!1&&(i??(i=Object.create(null),n=Object.create(n)),n[m]=i[m]=u,o.uri=c.XMLNS,t.startPrefixMapping(m,u))}for(var a=e.length;a--;)o=e[a],o.prefix&&(o.prefix===`xml`&&(o.uri=c.XML),o.prefix!==`xmlns`&&(o.uri=n[o.prefix]));var d=r.indexOf(`:`);d>0?(f=e.prefix=r.slice(0,d),p=e.localName=r.slice(d+1)):(f=null,p=e.localName=r);var h=e.uri=n[f||``];if(t.startElement(h,p,r,e),e.closed){if(t.endElement(h,p,r),i)for(f in i)s(i,f)&&t.endPrefixMapping(f)}else return e.currentNSMap=n,e.localNSMap=i,!0}function T(e,t,n,r,a){var s=i(n);if(s||o(n)){var c=RegExp(`</`+n.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)+`>`,`ig`);c.lastIndex=t;var l=c.exec(e),u=l?l.index:-1;if(u<0)return t+1;var d=e.substring(t+1,u);return s&&(d=d.replace(b,r)),a.characters(d,0,d.length),u}return t+1}function E(e,t){for(var n in e)s(e,n)&&(t[n]=e[n])}function D(e,t){var r=t;function i(t){return t||=0,e.charAt(r+t)}function a(e){e||=1,r+=e}function o(){for(var t=0;r<e.length;){var n=i();if(n!==` `&&n!==`
`&&n!==`	`&&n!==`\r`)return t;t++,a()}return-1}function s(){return e.substring(r)}function c(t){return e.substring(r,r+t.length)===t}function l(t){return e.substring(r,r+t.length).toUpperCase()===t.toUpperCase()}function u(e){var t=n.reg(`^`,e).exec(s());return t?(a(t[0].length),t[0]):null}return{char:i,getIndex:function(){return r},getMatch:u,getSource:function(){return e},skip:a,skipBlanks:o,substringFromIndex:s,substringStartsWith:c,substringStartsWithCaseInsensitive:l}}function O(e,t){function r(e,t){var r=n.PI.exec(e.substringFromIndex());return r?r[1].toLowerCase()===`xml`?t.fatalError(`xml declaration is only allowed at the start of the document, but found at position `+e.getIndex()):(e.skip(r[0].length),r[0]):t.fatalError(`processing instruction is not well-formed at position `+e.getIndex())}var i=e.getSource();if(e.char()===`[`){e.skip(1);for(var a=e.getIndex();e.getIndex()<i.length;){if(e.skipBlanks(),e.char()===`]`){var o=i.substring(a,e.getIndex());return e.skip(1),o}var s=null;if(e.char()===`<`&&e.char(1)===`!`)switch(e.char(2)){case`E`:e.char(3)===`L`?s=e.getMatch(n.elementdecl):e.char(3)===`N`&&(s=e.getMatch(n.EntityDecl));break;case`A`:s=e.getMatch(n.AttlistDecl);break;case`N`:s=e.getMatch(n.NotationDecl);break;case`-`:s=e.getMatch(n.Comment);break}else if(e.char()===`<`&&e.char(1)===`?`)s=r(e,t);else if(e.char()===`%`)s=e.getMatch(n.PEReference);else return t.fatalError(`Error detected in Markup declaration`);if(!s)return t.fatalError(`Error in internal subset at position `+e.getIndex())}return t.fatalError(`doctype internal subset is not well-formed, missing ]`)}}function ee(e,t,r,i,a){var o=D(e,t);switch(a?o.char(2).toUpperCase():o.char(2)){case`-`:var s=o.getMatch(n.Comment);return s?(r.comment(s,n.COMMENT_START.length,s.length-n.COMMENT_START.length-n.COMMENT_END.length),o.getIndex()):i.fatalError(`comment is not well-formed at position `+o.getIndex());case`[`:var c=o.getMatch(n.CDSect);return c?!a&&!r.currentElement?i.fatalError(`CDATA outside of element`):(r.startCDATA(),r.characters(c,n.CDATA_START.length,c.length-n.CDATA_START.length-n.CDATA_END.length),r.endCDATA(),o.getIndex()):i.fatalError(`Invalid CDATA starting at position `+t);case`D`:if(r.doc&&r.doc.documentElement)return i.fatalError(`Doctype not allowed inside or after documentElement at position `+o.getIndex());if(a?!o.substringStartsWithCaseInsensitive(n.DOCTYPE_DECL_START):!o.substringStartsWith(n.DOCTYPE_DECL_START))return i.fatalError(`Expected `+n.DOCTYPE_DECL_START+` at position `+o.getIndex());if(o.skip(n.DOCTYPE_DECL_START.length),o.skipBlanks()<1)return i.fatalError(`Expected whitespace after `+n.DOCTYPE_DECL_START+` at position `+o.getIndex());var l={name:void 0,publicId:void 0,systemId:void 0,internalSubset:void 0};if(l.name=o.getMatch(n.Name),!l.name)return i.fatalError(`doctype name missing or contains unexpected characters at position `+o.getIndex());if(a&&l.name.toLowerCase()!==`html`&&i.warning(`Unexpected DOCTYPE in HTML document at position `+o.getIndex()),o.skipBlanks(),o.substringStartsWith(n.PUBLIC)||o.substringStartsWith(n.SYSTEM)){var u=n.ExternalID_match.exec(o.substringFromIndex());if(!u)return i.fatalError(`doctype external id is not well-formed at position `+o.getIndex());u.groups.SystemLiteralOnly===void 0?(l.systemId=u.groups.SystemLiteral,l.publicId=u.groups.PubidLiteral):l.systemId=u.groups.SystemLiteralOnly,o.skip(u[0].length)}else if(a&&o.substringStartsWithCaseInsensitive(n.SYSTEM)){if(o.skip(n.SYSTEM.length),o.skipBlanks()<1)return i.fatalError(`Expected whitespace after `+n.SYSTEM+` at position `+o.getIndex());if(l.systemId=o.getMatch(n.ABOUT_LEGACY_COMPAT_SystemLiteral),!l.systemId)return i.fatalError(`Expected `+n.ABOUT_LEGACY_COMPAT+` in single or double quotes after `+n.SYSTEM+` at position `+o.getIndex())}return a&&l.systemId&&!n.ABOUT_LEGACY_COMPAT_SystemLiteral.test(l.systemId)&&i.warning(`Unexpected doctype.systemId in HTML document at position `+o.getIndex()),a||(o.skipBlanks(),l.internalSubset=O(o,i)),o.skipBlanks(),o.char()===`>`?(o.skip(1),r.startDTD(l.name,l.publicId,l.systemId,l.internalSubset),r.endDTD(),o.getIndex()):i.fatalError(`doctype not terminated with > at position `+o.getIndex());default:return i.fatalError(`Not well-formed XML starting with "<!" at position `+t)}}function k(e,t,r,i){var a=e.substring(t).match(n.PI);if(!a)return i.fatalError(`Invalid processing instruction starting at position `+t);if(a[1].toLowerCase()===`xml`){if(t>0)return i.fatalError(`processing instruction at position `+t+` is an xml declaration which is only at the start of the document`);if(!n.XMLDecl.test(e.substring(t)))return i.fatalError(`xml declaration is not well-formed`)}return r.processingInstruction(a[1],a[2]),t+a[0].length}function te(){this.attributeNames=Object.create(null)}te.prototype={setTagName:function(e){if(!n.QName_exact.test(e))throw Error(`invalid tagName:`+e);this.tagName=e},addValue:function(e,t,r){if(!n.QName_exact.test(e))throw Error(`invalid attribute:`+e);this.attributeNames[e]=this.length,this[this.length++]={qName:e,value:t,offset:r}},length:0,getLocalName:function(e){return this[e].localName},getLocator:function(e){return this[e].locator},getQName:function(e){return this[e].qName},getURI:function(e){return this[e].uri},getValue:function(e){return this[e].value}},e.XMLReader=y,e.parseUtils=D,e.parseDoctypeCommentOrCData=ee})),_o=n((e=>{var t=uo(),n=mo(),r=fo(),i=ho(),a=go(),o=n.DOMImplementation,s=t.hasDefaultHTMLNamespace,c=t.isHTMLMimeType,l=t.isValidMimeType,u=t.MIME_TYPE,d=t.NAMESPACE,f=r.ParseError,p=a.XMLReader;function m(e){return e.replace(/\r[\n\u0085]/g,`
`).replace(/[\r\u0085\u2028\u2029]/g,`
`)}function h(e){if(e||={},e.locator===void 0&&(e.locator=!0),this.assign=e.assign||t.assign,this.domHandler=e.domHandler||g,this.onError=e.onError||e.errorHandler,e.errorHandler&&typeof e.errorHandler!=`function`)throw TypeError(`errorHandler object is no longer supported, switch to onError!`);e.errorHandler&&e.errorHandler(`warning`,"The `errorHandler` option has been deprecated, use `onError` instead!",this),this.normalizeLineEndings=e.normalizeLineEndings||m,this.locator=!!e.locator,this.xmlns=this.assign(Object.create(null),e.xmlns)}h.prototype.parseFromString=function(e,n){if(!l(n))throw TypeError(`DOMParser.parseFromString: the provided mimeType "`+n+`" is not valid.`);var r=this.assign(Object.create(null),this.xmlns),a=i.XML_ENTITIES,o=r[``]||null;s(n)?(a=i.HTML_ENTITIES,o=d.HTML):n===u.XML_SVG_IMAGE&&(o=d.SVG),r[``]=o,r.xml=r.xml||d.XML;var c=new this.domHandler({mimeType:n,defaultNamespace:o,onError:this.onError}),f=this.locator?{}:void 0;this.locator&&c.setDocumentLocator(f);var m=new p;return m.errorHandler=c,m.domBuilder=c,!t.isHTMLMimeType(n)&&typeof e!=`string`&&m.errorHandler.fatalError(`source is not a string`),m.parse(this.normalizeLineEndings(String(e)),r,a),c.doc.documentElement||m.errorHandler.fatalError(`missing root element`),c.doc};function g(e){var t=e||{};this.mimeType=t.mimeType||u.XML_APPLICATION,this.defaultNamespace=t.defaultNamespace||null,this.cdata=!1,this.currentElement=void 0,this.doc=void 0,this.locator=void 0,this.onError=t.onError}function _(e,t){t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber}g.prototype={startDocument:function(){var e=new o;this.doc=c(this.mimeType)?e.createHTMLDocument(!1):e.createDocument(this.defaultNamespace,``)},startElement:function(e,t,n,r){var i=this.doc,a=i.createElementNS(e,n||t),o=r.length;b(this,a),this.currentElement=a,this.locator&&_(this.locator,a);for(var s=0;s<o;s++){var e=r.getURI(s),c=r.getValue(s),n=r.getQName(s),l=i.createAttributeNS(e,n);this.locator&&_(r.getLocator(s),l),l.value=l.nodeValue=c,a.setAttributeNode(l)}},endElement:function(e,t,n){this.currentElement=this.currentElement.parentNode},startPrefixMapping:function(e,t){},endPrefixMapping:function(e){},processingInstruction:function(e,t){var n=this.doc.createProcessingInstruction(e,t);this.locator&&_(this.locator,n),b(this,n)},ignorableWhitespace:function(e,t,n){},characters:function(e,t,n){if(e=y.apply(this,arguments),e){if(this.cdata)var r=this.doc.createCDATASection(e);else var r=this.doc.createTextNode(e);this.currentElement?this.currentElement.appendChild(r):/^\s*$/.test(e)&&this.doc.appendChild(r),this.locator&&_(this.locator,r)}},skippedEntity:function(e){},endDocument:function(){this.doc.normalize()},setDocumentLocator:function(e){e&&(e.lineNumber=0),this.locator=e},comment:function(e,t,n){e=y.apply(this,arguments);var r=this.doc.createComment(e);this.locator&&_(this.locator,r),b(this,r)},startCDATA:function(){this.cdata=!0},endCDATA:function(){this.cdata=!1},startDTD:function(e,t,n,r){var i=this.doc.implementation;if(i&&i.createDocumentType){var a=i.createDocumentType(e,t,n,r);this.locator&&_(this.locator,a),b(this,a),this.doc.doctype=a}},reportError:function(e,t){if(typeof this.onError==`function`)try{this.onError(e,t,this)}catch(n){throw new f(`Reporting `+e+` "`+t+`" caused `+n,this.locator)}else console.error(`[xmldom `+e+`]	`+t,v(this.locator))},warning:function(e){this.reportError(`warning`,e)},error:function(e){this.reportError(`error`,e)},fatalError:function(e,t){throw this.reportError(`fatalError`,e),new f(e,this.locator,t)}};function v(e){if(e)return`
@#[line:`+e.lineNumber+`,col:`+e.columnNumber+`]`}function y(e,t,n){return typeof e==`string`?e.substr(t,n):e.length>=t+n||t?new java.lang.String(e,t,n)+``:e}`endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl`.replace(/\w+/g,function(e){g.prototype[e]=function(){return null}});function b(e,t){e.currentElement?e.currentElement.appendChild(t):e.doc.appendChild(t)}function x(e){if(e===`error`)throw`onErrorStopParsing`}function S(){throw`onWarningStopParsing`}e.__DOMHandler=g,e.DOMParser=h,e.normalizeLineEndings=m,e.onErrorStopParsing=x,e.onWarningStopParsing=S})),vo=n((e=>{var t=uo();e.assign=t.assign,e.hasDefaultHTMLNamespace=t.hasDefaultHTMLNamespace,e.isHTMLMimeType=t.isHTMLMimeType,e.isValidMimeType=t.isValidMimeType,e.MIME_TYPE=t.MIME_TYPE,e.NAMESPACE=t.NAMESPACE;var n=fo();e.DOMException=n.DOMException,e.DOMExceptionName=n.DOMExceptionName,e.ExceptionCode=n.ExceptionCode,e.ParseError=n.ParseError;var r=mo();e.Attr=r.Attr,e.CDATASection=r.CDATASection,e.CharacterData=r.CharacterData,e.Comment=r.Comment,e.Document=r.Document,e.DocumentFragment=r.DocumentFragment,e.DocumentType=r.DocumentType,e.DOMImplementation=r.DOMImplementation,e.Element=r.Element,e.Entity=r.Entity,e.EntityReference=r.EntityReference,e.LiveNodeList=r.LiveNodeList,e.NamedNodeMap=r.NamedNodeMap,e.Node=r.Node,e.NodeList=r.NodeList,e.Notation=r.Notation,e.ProcessingInstruction=r.ProcessingInstruction,e.Text=r.Text,e.XMLSerializer=r.XMLSerializer;var i=_o();e.DOMParser=i.DOMParser,e.normalizeLineEndings=i.normalizeLineEndings,e.onErrorStopParsing=i.onErrorStopParsing,e.onWarningStopParsing=i.onWarningStopParsing}));
/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.8.2
*/
function yo(e,t){return es(e,{i:2},t&&t.out,t&&t.dictionary)}function bo(e,t){t||={};var n=ps(),r=e.length;n.p(e);var i=ms(e,t,bs(t),8),a=i.length;return ys(i,t),vs(i,a-8,n.d()),vs(i,a-4,r),i}function xo(e,t){return es(e.subarray(xs(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary)}function So(e,t){if(t){for(var n=``,r=0;r<e.length;r+=16384)n+=String.fromCharCode.apply(null,e.subarray(r,r+16384));return n}else if(Ss)return Ss.decode(e);else{var i=Cs(e),a=i.s,n=i.r;return n.length&&$o(8),a}}function Co(e,t){for(var n={},r=e.length-22;gs(e,r)!=101010256;--r)(!r||e.length-r>65558)&&$o(13);var i=hs(e,r+8);if(!i)return{};var a=gs(e,r+16),o=a==4294967295||i==65535;if(o){var s=gs(e,r-12);o=gs(e,s)==101075792,o&&(i=gs(e,s+32),a=gs(e,s+48))}for(var c=t&&t.filter,l=0;l<i;++l){var u=Ts(e,a,o),d=u[0],f=u[1],p=u[2],m=u[3],h=u[4],g=u[5],_=ws(e,g);a=h,(!c||c({name:m,size:f,originalSize:p,compression:d}))&&(d?d==8?n[m]=yo(e.subarray(_,_+f),{out:new wo(p)}):$o(14,`unknown compression type `+d):n[m]=Zo(e,_,_+f))}return n}var wo,To,Eo,Do,Oo,ko,Ao,jo,Mo,No,Po,Fo,Io,Lo,Ro,zo,Bo,Vo,Ho,Uo,Wo,Go,Ko,qo,Jo,Yo,Xo,Zo,Qo,$o,es,ts,ns,rs,is,as,os,ss,cs,ls,us,ds,fs,ps,ms,hs,gs,_s,vs,ys,bs,xs,Ss,Cs,ws,Ts,Es,Ds=t((()=>{for(wo=Uint8Array,To=Uint16Array,Eo=Int32Array,Do=new wo([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Oo=new wo([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),ko=new wo([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Ao=function(e,t){for(var n=new To(31),r=0;r<31;++r)n[r]=t+=1<<e[r-1];for(var i=new Eo(n[30]),r=1;r<30;++r)for(var a=n[r];a<n[r+1];++a)i[a]=a-n[r]<<5|r;return{b:n,r:i}},jo=Ao(Do,2),Mo=jo.b,No=jo.r,Mo[28]=258,No[258]=28,Po=Ao(Oo,0),Fo=Po.b,Io=Po.r,Lo=new To(32768),Ro=0;Ro<32768;++Ro)zo=(Ro&43690)>>1|(Ro&21845)<<1,zo=(zo&52428)>>2|(zo&13107)<<2,zo=(zo&61680)>>4|(zo&3855)<<4,Lo[Ro]=((zo&65280)>>8|(zo&255)<<8)>>1;for(Bo=(function(e,t,n){for(var r=e.length,i=0,a=new To(t);i<r;++i)e[i]&&++a[e[i]-1];var o=new To(t);for(i=1;i<t;++i)o[i]=o[i-1]+a[i-1]<<1;var s;if(n){s=new To(1<<t);var c=15-t;for(i=0;i<r;++i)if(e[i])for(var l=i<<4|e[i],u=t-e[i],d=o[e[i]-1]++<<u,f=d|(1<<u)-1;d<=f;++d)s[Lo[d]>>c]=l}else for(s=new To(r),i=0;i<r;++i)e[i]&&(s[i]=Lo[o[e[i]-1]++]>>15-e[i]);return s}),Vo=new wo(288),Ro=0;Ro<144;++Ro)Vo[Ro]=8;for(Ro=144;Ro<256;++Ro)Vo[Ro]=9;for(Ro=256;Ro<280;++Ro)Vo[Ro]=7;for(Ro=280;Ro<288;++Ro)Vo[Ro]=8;for(Ho=new wo(32),Ro=0;Ro<32;++Ro)Ho[Ro]=5;Uo=Bo(Vo,9,0),Wo=Bo(Vo,9,1),Go=Bo(Ho,5,0),Ko=Bo(Ho,5,1),qo=function(e){for(var t=e[0],n=1;n<e.length;++n)e[n]>t&&(t=e[n]);return t},Jo=function(e,t,n){var r=t/8|0;return(e[r]|e[r+1]<<8)>>(t&7)&n},Yo=function(e,t){var n=t/8|0;return(e[n]|e[n+1]<<8|e[n+2]<<16)>>(t&7)},Xo=function(e){return(e+7)/8|0},Zo=function(e,t,n){return(t==null||t<0)&&(t=0),(n==null||n>e.length)&&(n=e.length),new wo(e.subarray(t,n))},Qo=[`unexpected EOF`,`invalid block type`,`invalid length/literal`,`invalid distance`,`stream finished`,`no stream handler`,,`no callback`,`invalid UTF-8 data`,`extra field too long`,`date not in range 1980-2099`,`filename too long`,`stream finishing`,`invalid zip data`],$o=function(e,t,n){var r=Error(t||Qo[e]);if(r.code=e,Error.captureStackTrace&&Error.captureStackTrace(r,$o),!n)throw r;return r},es=function(e,t,n,r){var i=e.length,a=r?r.length:0;if(!i||t.f&&!t.l)return n||new wo(0);var o=!n,s=o||t.i!=2,c=t.i;o&&(n=new wo(i*3));var l=function(e){var t=n.length;if(e>t){var r=new wo(Math.max(t*2,e));r.set(n),n=r}},u=t.f||0,d=t.p||0,f=t.b||0,p=t.l,m=t.d,h=t.m,g=t.n,_=i*8;do{if(!p){u=Jo(e,d,1);var v=Jo(e,d+1,3);if(d+=3,!v){var y=Xo(d)+4,b=e[y-4]|e[y-3]<<8,x=y+b;if(x>i){c&&$o(0);break}s&&l(f+b),n.set(e.subarray(y,x),f),t.b=f+=b,t.p=d=x*8,t.f=u;continue}else if(v==1)p=Wo,m=Ko,h=9,g=5;else if(v==2){var S=Jo(e,d,31)+257,C=Jo(e,d+10,15)+4,w=S+Jo(e,d+5,31)+1;d+=14;for(var T=new wo(w),E=new wo(19),D=0;D<C;++D)E[ko[D]]=Jo(e,d+D*3,7);d+=C*3;for(var O=qo(E),ee=(1<<O)-1,k=Bo(E,O,1),D=0;D<w;){var te=k[Jo(e,d,ee)];d+=te&15;var y=te>>4;if(y<16)T[D++]=y;else{var A=0,j=0;for(y==16?(j=3+Jo(e,d,3),d+=2,A=T[D-1]):y==17?(j=3+Jo(e,d,7),d+=3):y==18&&(j=11+Jo(e,d,127),d+=7);j--;)T[D++]=A}}var ne=T.subarray(0,S),M=T.subarray(S);h=qo(ne),g=qo(M),p=Bo(ne,h,1),m=Bo(M,g,1)}else $o(1);if(d>_){c&&$o(0);break}}s&&l(f+131072);for(var N=(1<<h)-1,P=(1<<g)-1,F=d;;F=d){var A=p[Yo(e,d)&N],I=A>>4;if(d+=A&15,d>_){c&&$o(0);break}if(A||$o(2),I<256)n[f++]=I;else if(I==256){F=d,p=null;break}else{var re=I-254;if(I>264){var D=I-257,L=Do[D];re=Jo(e,d,(1<<L)-1)+Mo[D],d+=L}var R=m[Yo(e,d)&P],z=R>>4;R||$o(3),d+=R&15;var M=Fo[z];if(z>3){var L=Oo[z];M+=Yo(e,d)&(1<<L)-1,d+=L}if(d>_){c&&$o(0);break}s&&l(f+131072);var ie=f+re;if(f<M){var ae=a-M,oe=Math.min(M,ie);for(ae+f<0&&$o(3);f<oe;++f)n[f]=r[ae+f]}for(;f<ie;++f)n[f]=n[f-M]}}t.l=p,t.p=F,t.b=f,t.f=u,p&&(u=1,t.m=h,t.d=m,t.n=g)}while(!u);return f!=n.length&&o?Zo(n,0,f):n.subarray(0,f)},ts=function(e,t,n){n<<=t&7;var r=t/8|0;e[r]|=n,e[r+1]|=n>>8},ns=function(e,t,n){n<<=t&7;var r=t/8|0;e[r]|=n,e[r+1]|=n>>8,e[r+2]|=n>>16},rs=function(e,t){for(var n=[],r=0;r<e.length;++r)e[r]&&n.push({s:r,f:e[r]});var i=n.length,a=n.slice();if(!i)return{t:us,l:0};if(i==1){var o=new wo(n[0].s+1);return o[n[0].s]=1,{t:o,l:1}}n.sort(function(e,t){return e.f-t.f}),n.push({s:-1,f:25001});var s=n[0],c=n[1],l=0,u=1,d=2;for(n[0]={s:-1,f:s.f+c.f,l:s,r:c};u!=i-1;)s=n[n[l].f<n[d].f?l++:d++],c=n[l!=u&&n[l].f<n[d].f?l++:d++],n[u++]={s:-1,f:s.f+c.f,l:s,r:c};for(var f=a[0].s,r=1;r<i;++r)a[r].s>f&&(f=a[r].s);var p=new To(f+1),m=is(n[u-1],p,0);if(m>t){var r=0,h=0,g=m-t,_=1<<g;for(a.sort(function(e,t){return p[t.s]-p[e.s]||e.f-t.f});r<i;++r){var v=a[r].s;if(p[v]>t)h+=_-(1<<m-p[v]),p[v]=t;else break}for(h>>=g;h>0;){var y=a[r].s;p[y]<t?h-=1<<t-p[y]++-1:++r}for(;r>=0&&h;--r){var b=a[r].s;p[b]==t&&(--p[b],++h)}m=t}return{t:new wo(p),l:m}},is=function(e,t,n){return e.s==-1?Math.max(is(e.l,t,n+1),is(e.r,t,n+1)):t[e.s]=n},as=function(e){for(var t=e.length;t&&!e[--t];);for(var n=new To(++t),r=0,i=e[0],a=1,o=function(e){n[r++]=e},s=1;s<=t;++s)if(e[s]==i&&s!=t)++a;else{if(!i&&a>2){for(;a>138;a-=138)o(32754);a>2&&(o(a>10?a-11<<5|28690:a-3<<5|12305),a=0)}else if(a>3){for(o(i),--a;a>6;a-=6)o(8304);a>2&&(o(a-3<<5|8208),a=0)}for(;a--;)o(i);a=1,i=e[s]}return{c:n.subarray(0,r),n:t}},os=function(e,t){for(var n=0,r=0;r<t.length;++r)n+=e[r]*t[r];return n},ss=function(e,t,n){var r=n.length,i=Xo(t+2);e[i]=r&255,e[i+1]=r>>8,e[i+2]=e[i]^255,e[i+3]=e[i+1]^255;for(var a=0;a<r;++a)e[i+a+4]=n[a];return(i+4+r)*8},cs=function(e,t,n,r,i,a,o,s,c,l,u){ts(t,u++,n),++i[256];for(var d=rs(i,15),f=d.t,p=d.l,m=rs(a,15),h=m.t,g=m.l,_=as(f),v=_.c,y=_.n,b=as(h),x=b.c,S=b.n,C=new To(19),w=0;w<v.length;++w)++C[v[w]&31];for(var w=0;w<x.length;++w)++C[x[w]&31];for(var T=rs(C,7),E=T.t,D=T.l,O=19;O>4&&!E[ko[O-1]];--O);var ee=l+5<<3,k=os(i,Vo)+os(a,Ho)+o,te=os(i,f)+os(a,h)+o+14+3*O+os(C,E)+2*C[16]+3*C[17]+7*C[18];if(c>=0&&ee<=k&&ee<=te)return ss(t,u,e.subarray(c,c+l));var A,j,ne,M;if(ts(t,u,1+(te<k)),u+=2,te<k){A=Bo(f,p,0),j=f,ne=Bo(h,g,0),M=h;var N=Bo(E,D,0);ts(t,u,y-257),ts(t,u+5,S-1),ts(t,u+10,O-4),u+=14;for(var w=0;w<O;++w)ts(t,u+3*w,E[ko[w]]);u+=3*O;for(var P=[v,x],F=0;F<2;++F)for(var I=P[F],w=0;w<I.length;++w){var re=I[w]&31;ts(t,u,N[re]),u+=E[re],re>15&&(ts(t,u,I[w]>>5&127),u+=I[w]>>12)}}else A=Uo,j=Vo,ne=Go,M=Ho;for(var w=0;w<s;++w){var L=r[w];if(L>255){var re=L>>18&31;ns(t,u,A[re+257]),u+=j[re+257],re>7&&(ts(t,u,L>>23&31),u+=Do[re]);var R=L&31;ns(t,u,ne[R]),u+=M[R],R>3&&(ns(t,u,L>>5&8191),u+=Oo[R])}else ns(t,u,A[L]),u+=j[L]}return ns(t,u,A[256]),u+j[256]},ls=new Eo([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),us=new wo(0),ds=function(e,t,n,r,i,a){var o=a.z||e.length,s=new wo(r+o+5*(1+Math.ceil(o/7e3))+i),c=s.subarray(r,s.length-i),l=a.l,u=(a.r||0)&7;if(t){u&&(c[0]=a.r>>3);for(var d=ls[t-1],f=d>>13,p=d&8191,m=(1<<n)-1,h=a.p||new To(32768),g=a.h||new To(m+1),_=Math.ceil(n/3),v=2*_,y=function(t){return(e[t]^e[t+1]<<_^e[t+2]<<v)&m},b=new Eo(25e3),x=new To(288),S=new To(32),C=0,w=0,T=a.i||0,E=0,D=a.w||0,O=0;T+2<o;++T){var ee=y(T),k=T&32767,te=g[ee];if(h[k]=te,g[ee]=k,D<=T){var A=o-T;if((C>7e3||E>24576)&&(A>423||!l)){u=cs(e,c,0,b,x,S,w,E,O,T-O,u),E=C=w=0,O=T;for(var j=0;j<286;++j)x[j]=0;for(var j=0;j<30;++j)S[j]=0}var ne=2,M=0,N=p,P=k-te&32767;if(A>2&&ee==y(T-P))for(var F=Math.min(f,A)-1,I=Math.min(32767,T),re=Math.min(258,A);P<=I&&--N&&k!=te;){if(e[T+ne]==e[T+ne-P]){for(var L=0;L<re&&e[T+L]==e[T+L-P];++L);if(L>ne){if(ne=L,M=P,L>F)break;for(var R=Math.min(P,L-2),z=0,j=0;j<R;++j){var ie=T-P+j&32767,ae=ie-h[ie]&32767;ae>z&&(z=ae,te=ie)}}}k=te,te=h[k],P+=k-te&32767}if(M){b[E++]=268435456|No[ne]<<18|Io[M];var oe=No[ne]&31,se=Io[M]&31;w+=Do[oe]+Oo[se],++x[257+oe],++S[se],D=T+ne,++C}else b[E++]=e[T],++x[e[T]]}}for(T=Math.max(T,D);T<o;++T)b[E++]=e[T],++x[e[T]];u=cs(e,c,l,b,x,S,w,E,O,T-O,u),l||(a.r=u&7|c[u/8|0]<<3,u-=7,a.h=g,a.p=h,a.i=T,a.w=D)}else{for(var T=a.w||0;T<o+l;T+=65535){var ce=T+65535;ce>=o&&(c[u/8|0]=l,ce=o),u=ss(c,u+1,e.subarray(T,ce))}a.i=o}return Zo(s,0,r+Xo(u)+i)},fs=(function(){for(var e=new Int32Array(256),t=0;t<256;++t){for(var n=t,r=9;--r;)n=(n&1&&-306674912)^n>>>1;e[t]=n}return e})(),ps=function(){var e=-1;return{p:function(t){for(var n=e,r=0;r<t.length;++r)n=fs[n&255^t[r]]^n>>>8;e=n},d:function(){return~e}}},ms=function(e,t,n,r,i){if(!i&&(i={l:1},t.dictionary)){var a=t.dictionary.subarray(-32768),o=new wo(a.length+e.length);o.set(a),o.set(e,a.length),e=o,i.w=a.length}return ds(e,t.level==null?6:t.level,t.mem==null?i.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,n,r,i)},hs=function(e,t){return e[t]|e[t+1]<<8},gs=function(e,t){return(e[t]|e[t+1]<<8|e[t+2]<<16|e[t+3]<<24)>>>0},_s=function(e,t){return gs(e,t)+gs(e,t+4)*4294967296},vs=function(e,t,n){for(;n;++t)e[t]=n,n>>>=8},ys=function(e,t){var n=t.filename;if(e[0]=31,e[1]=139,e[2]=8,e[8]=t.level<2?4:t.level==9?2:0,e[9]=3,t.mtime!=0&&vs(e,4,Math.floor(new Date(t.mtime||Date.now())/1e3)),n){e[3]=8;for(var r=0;r<=n.length;++r)e[r+10]=n.charCodeAt(r)}},bs=function(e){return 10+(e.filename?e.filename.length+1:0)},xs=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&$o(6,`invalid zlib data`),(e[1]>>5&1)==+!t&&$o(6,`invalid zlib data: `+(e[1]&32?`need`:`unexpected`)+` dictionary`),(e[1]>>3&4)+2},Ss=typeof TextDecoder<`u`&&new TextDecoder;try{Ss.decode(us,{stream:!0})}catch{}Cs=function(e){for(var t=``,n=0;;){var r=e[n++],i=(r>127)+(r>223)+(r>239);if(n+i>e.length)return{s:t,r:Zo(e,n-1)};i?i==3?(r=((r&15)<<18|(e[n++]&63)<<12|(e[n++]&63)<<6|e[n++]&63)-65536,t+=String.fromCharCode(55296|r>>10,56320|r&1023)):i&1?t+=String.fromCharCode((r&31)<<6|e[n++]&63):t+=String.fromCharCode((r&15)<<12|(e[n++]&63)<<6|e[n++]&63):t+=String.fromCharCode(r)}},ws=function(e,t){return t+30+hs(e,t+26)+hs(e,t+28)},Ts=function(e,t,n){var r=hs(e,t+28),i=So(e.subarray(t+46,t+46+r),!(hs(e,t+8)&2048)),a=t+46+r,o=gs(e,t+20),s=n&&o==4294967295?Es(e,a):[o,gs(e,t+24),gs(e,t+42)],c=s[0],l=s[1],u=s[2];return[hs(e,t+10),c,l,i,a+hs(e,t+30)+hs(e,t+32),u]},Es=function(e,t){for(;hs(e,t)!=1;t+=4+hs(e,t+2));return[_s(e,t+12),_s(e,t+4),_s(e,t+20)]}})),Os=vo();Ds();function ks(e){let t=new Uint8Array(e.buffer,e.byteOffset,e.byteLength),n=``;for(let e=0;e<t.length;e+=16384)n+=String.fromCharCode(...t.subarray(e,e+16384));return btoa(n)}function As(e,t,n){let r=e.getAttribute(`position`);if(!r||r.itemSize!==3||!Number.isInteger(r.count)||!r.count)throw Error(`Mesh "${t}" has no valid 3D vertex positions.`);let i={position:``,encoding:`gzip`,byteLengths:{}},a=(e,t)=>{i.byteLengths[e]=t.byteLength,i[e]=ks(bo(new Uint8Array(t.buffer,t.byteOffset,t.byteLength),{level:3,mtime:0}))};for(let i of[`position`,`normal`,`uv`]){let o=e.getAttribute(i);if(!o)continue;let s=i===`uv`?2:3,c=o.itemSize!==s||o.count!==r.count,l=new Float32Array(r.count*s);if(!c){outer:for(let e=0;e<r.count;e++)for(let n=0;n<s;n++)if(l[e*s+n]=o.getComponent(e,n),!Number.isFinite(l[e*s+n])){if(i===`position`)throw Error(`Mesh "${t}" has an invalid vertex position at vertex ${e+1} (${[`X`,`Y`,`Z`][n]}). Check this mesh in the source application and export it again.`);c=!0;break outer}}if(c){n(i===`normal`?`Mesh "${t}": invalid normals were regenerated from its surfaces.`:`Mesh "${t}": invalid UV coordinates were omitted; stage shading does not require source textures.`);continue}a(i,l)}if((e.index?.count||r.count)%3)throw Error(`Mesh "${t}" contains incomplete triangle data.`);if(e.index){if(e.index.array.some(e=>!Number.isInteger(e)||e<0||e>=r.count))throw Error(`Mesh "${t}" has triangle indices referencing missing vertices.`);a(`index`,new Uint32Array(e.index.array))}return i}Uint32Array.from({length:256},(e,t)=>{for(let e=0;e<8;e++)t=t>>>1^(t&1?3988292384:0);return t>>>0});function js(e,t){if(t===0)return console.warn(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles.`),e;if(t===2||t===1){let n=e.getIndex();if(n===null){let t=[],r=e.getAttribute(`position`);if(r!==void 0){for(let e=0;e<r.count;e++)t.push(e);e.setIndex(t),n=e.getIndex()}else return console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible.`),e}let r=n.count-2,i=[];if(t===2)for(let e=1;e<=r;e++)i.push(n.getX(0)),i.push(n.getX(e)),i.push(n.getX(e+1));else for(let e=0;e<r;e++)e%2==0?(i.push(n.getX(e)),i.push(n.getX(e+1)),i.push(n.getX(e+2))):(i.push(n.getX(e+2)),i.push(n.getX(e+1)),i.push(n.getX(e)));i.length/3!==r&&console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.`);let a=e.clone();return a.setIndex(i),a.clearGroups(),a}else return console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:`,t),e}var Ms=t((()=>{lo()}));function Ns(e){let t=new Map,n=new Map,r=e.clone();return Ps(e,r,function(e,r){t.set(r,e),n.set(e,r)}),r.traverse(function(e){if(!e.isSkinnedMesh)return;let r=e,i=t.get(e),a=i.skeleton.bones;r.skeleton=i.skeleton.clone(),r.bindMatrix.copy(i.bindMatrix),r.skeleton.bones=a.map(function(e){return n.get(e)}),r.bind(r.skeleton,r.bindMatrix)}),r}function Ps(e,t,n){n(e,t);for(let r=0;r<e.children.length;r++)Ps(e.children[r],t.children[r],n)}var Fs=t((()=>{})),Is=r({GLTFLoader:()=>Xs});function Ls(){let e={};return{get:function(t){return e[t]},add:function(t,n){e[t]=n},remove:function(t){delete e[t]},removeAll:function(){e={}}}}function Rs(e,t,n){let r=e.json.materials[t];return r.extensions&&r.extensions[n]?r.extensions[n]:null}function zs(e){return e.DefaultMaterial===void 0&&(e.DefaultMaterial=new qi({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:0})),e.DefaultMaterial}function Bs(e,t,n){for(let r in n.extensions)e[r]===void 0&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[r]=n.extensions[r])}function Vs(e,t){t.extras!==void 0&&(typeof t.extras==`object`?Object.assign(e.userData,t.extras):console.warn(`THREE.GLTFLoader: Ignoring primitive type .extras, `+t.extras))}function Hs(e,t,n){let r=!1,i=!1,a=!1;for(let e=0,n=t.length;e<n;e++){let n=t[e];if(n.POSITION!==void 0&&(r=!0),n.NORMAL!==void 0&&(i=!0),n.COLOR_0!==void 0&&(a=!0),r&&i&&a)break}if(!r&&!i&&!a)return Promise.resolve(e);let o=[],s=[],c=[];for(let l=0,u=t.length;l<u;l++){let u=t[l];if(r){let t=u.POSITION===void 0?e.attributes.position:n.getDependency(`accessor`,u.POSITION);o.push(t)}if(i){let t=u.NORMAL===void 0?e.attributes.normal:n.getDependency(`accessor`,u.NORMAL);s.push(t)}if(a){let t=u.COLOR_0===void 0?e.attributes.color:n.getDependency(`accessor`,u.COLOR_0);c.push(t)}}return Promise.all([Promise.all(o),Promise.all(s),Promise.all(c)]).then(function(t){let n=t[0],o=t[1],s=t[2];return r&&(e.morphAttributes.position=n),i&&(e.morphAttributes.normal=o),a&&(e.morphAttributes.color=s),e.morphTargetsRelative=!0,e})}function Us(e,t){if(e.updateMorphTargets(),t.weights!==void 0)for(let n=0,r=t.weights.length;n<r;n++)e.morphTargetInfluences[n]=t.weights[n];if(t.extras&&Array.isArray(t.extras.targetNames)){let n=t.extras.targetNames;if(e.morphTargetInfluences.length===n.length){e.morphTargetDictionary={};for(let t=0,r=n.length;t<r;t++)e.morphTargetDictionary[n[t]]=t}else console.warn(`THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.`)}}function Ws(e){let t,n=e.extensions&&e.extensions[Z.KHR_DRACO_MESH_COMPRESSION];if(t=n?`draco:`+n.bufferView+`:`+n.indices+`:`+Gs(n.attributes):e.indices+`:`+Gs(e.attributes)+`:`+e.mode,e.targets!==void 0)for(let n=0,r=e.targets.length;n<r;n++)t+=`:`+Gs(e.targets[n]);return t}function Gs(e){let t=``,n=Object.keys(e).sort();for(let r=0,i=n.length;r<i;r++)t+=n[r]+`:`+e[n[r]]+`;`;return t}function Ks(e){switch(e){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw Error(`THREE.GLTFLoader: Unsupported normalized accessor component type.`)}}function qs(e){return e.search(/\.jpe?g($|\?)/i)>0||e.search(/^data\:image\/jpeg/)===0?`image/jpeg`:e.search(/\.webp($|\?)/i)>0||e.search(/^data\:image\/webp/)===0?`image/webp`:e.search(/\.ktx2($|\?)/i)>0||e.search(/^data\:image\/ktx2/)===0?`image/ktx2`:`image/png`}function Js(e,t,n){let r=t.attributes,i=new Rn;if(r.POSITION!==void 0){let e=n.json.accessors[r.POSITION],t=e.min,a=e.max;if(t!==void 0&&a!==void 0){if(i.set(new W(t[0],t[1],t[2]),new W(a[0],a[1],a[2])),e.normalized){let t=Ks(Ec[e.componentType]);i.min.multiplyScalar(t),i.max.multiplyScalar(t)}}else{console.warn(`THREE.GLTFLoader: Missing min/max properties for accessor POSITION.`);return}}else return;let a=t.targets;if(a!==void 0){let e=new W,t=new W;for(let r=0,i=a.length;r<i;r++){let i=a[r];if(i.POSITION!==void 0){let r=n.json.accessors[i.POSITION],a=r.min,o=r.max;if(a!==void 0&&o!==void 0){if(t.setX(Math.max(Math.abs(a[0]),Math.abs(o[0]))),t.setY(Math.max(Math.abs(a[1]),Math.abs(o[1]))),t.setZ(Math.max(Math.abs(a[2]),Math.abs(o[2]))),r.normalized){let e=Ks(Ec[r.componentType]);t.multiplyScalar(e)}e.max(t)}else console.warn(`THREE.GLTFLoader: Missing min/max properties for accessor POSITION.`)}}i.expandByVector(e)}e.boundingBox=i;let o=new sr;i.getCenter(o.center),o.radius=i.min.distanceTo(i.max)/2,e.boundingSphere=o}function Ys(e,t,n){let r=t.attributes,i=[];function a(t,r){return n.getDependency(`accessor`,t).then(function(t){e.setAttribute(r,t)})}for(let t in r){let n=Ac[t]||t.toLowerCase();n in e.attributes||i.push(a(r[t],n))}if(t.indices!==void 0&&!e.index){let r=n.getDependency(`accessor`,t.indices).then(function(t){e.setIndex(t)});i.push(r)}return Ft.workingColorSpace!==`srgb-linear`&&`COLOR_0`in r&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${Ft.workingColorSpace}" not supported.`),Vs(e,t),Js(e,t,n),Promise.all(i).then(function(){return t.targets===void 0?e:Hs(e,t.targets,n)})}var Xs,Z,Zs,Qs,$s,ec,tc,nc,rc,ic,ac,oc,sc,cc,lc,uc,dc,fc,pc,mc,hc,gc,_c,vc,yc,bc,xc,Sc,Cc,wc,Tc,Ec,Dc,Oc,kc,Ac,jc,Mc,Nc,Pc,Fc,Ic=t((()=>{lo(),Ms(),Fs(),Xs=class extends ma{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(e){return new ec(e)}),this.register(function(e){return new tc(e)}),this.register(function(e){return new uc(e)}),this.register(function(e){return new dc(e)}),this.register(function(e){return new fc(e)}),this.register(function(e){return new rc(e)}),this.register(function(e){return new ic(e)}),this.register(function(e){return new ac(e)}),this.register(function(e){return new oc(e)}),this.register(function(e){return new $s(e)}),this.register(function(e){return new sc(e)}),this.register(function(e){return new nc(e)}),this.register(function(e){return new lc(e)}),this.register(function(e){return new cc(e)}),this.register(function(e){return new Zs(e)}),this.register(function(e){return new pc(e,Z.EXT_MESHOPT_COMPRESSION)}),this.register(function(e){return new pc(e,Z.KHR_MESHOPT_COMPRESSION)}),this.register(function(e){return new mc(e)})}load(e,t,n,r){let i=this,a;if(this.resourcePath!==``)a=this.resourcePath;else if(this.path!==``){let t=Wa.extractUrlBase(e);a=Wa.resolveURL(t,this.path)}else a=Wa.extractUrlBase(e);this.manager.itemStart(e);let o=function(t){r?r(t):console.error(t),i.manager.itemError(e),i.manager.itemEnd(e)},s=new _a(this.manager);s.setPath(this.path),s.setResponseType(`arraybuffer`),s.setRequestHeader(this.requestHeader),s.setWithCredentials(this.withCredentials),s.load(e,function(n){try{i.parse(n,a,function(n){t(n),i.manager.itemEnd(e)},o)}catch(e){o(e)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,r){let i,a={},o={},s=new TextDecoder;if(typeof e==`string`)i=JSON.parse(e);else if(e instanceof ArrayBuffer)if(s.decode(new Uint8Array(e,0,4))===hc){try{a[Z.KHR_BINARY_GLTF]=new vc(e)}catch(e){r&&r(e);return}i=JSON.parse(a[Z.KHR_BINARY_GLTF].content)}else i=JSON.parse(s.decode(e));else i=e;if(i.asset===void 0||i.asset.version[0]<2){r&&r(Error(`THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported.`));return}let c=new Fc(i,{path:t||this.resourcePath||``,crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let e=0;e<this.pluginCallbacks.length;e++){let t=this.pluginCallbacks[e](c);t.name||console.error(`THREE.GLTFLoader: Invalid plugin found: missing name`),o[t.name]=t,a[t.name]=!0}if(i.extensionsUsed)for(let e=0;e<i.extensionsUsed.length;++e){let t=i.extensionsUsed[e],n=i.extensionsRequired||[];switch(t){case Z.KHR_MATERIALS_UNLIT:a[t]=new Qs;break;case Z.KHR_DRACO_MESH_COMPRESSION:a[t]=new yc(i,this.dracoLoader);break;case Z.KHR_TEXTURE_TRANSFORM:a[t]=new bc;break;case Z.KHR_MESH_QUANTIZATION:a[t]=new xc;break;default:n.indexOf(t)>=0&&o[t]===void 0&&console.warn(`THREE.GLTFLoader: Unknown extension "`+t+`".`)}}c.setExtensions(a),c.setPlugins(o),c.parse(n,r)}parseAsync(e,t){let n=this;return new Promise(function(r,i){n.parse(e,t,r,i)})}},Z={KHR_BINARY_GLTF:`KHR_binary_glTF`,KHR_DRACO_MESH_COMPRESSION:`KHR_draco_mesh_compression`,KHR_LIGHTS_PUNCTUAL:`KHR_lights_punctual`,KHR_MATERIALS_CLEARCOAT:`KHR_materials_clearcoat`,KHR_MATERIALS_DISPERSION:`KHR_materials_dispersion`,KHR_MATERIALS_IOR:`KHR_materials_ior`,KHR_MATERIALS_SHEEN:`KHR_materials_sheen`,KHR_MATERIALS_SPECULAR:`KHR_materials_specular`,KHR_MATERIALS_TRANSMISSION:`KHR_materials_transmission`,KHR_MATERIALS_IRIDESCENCE:`KHR_materials_iridescence`,KHR_MATERIALS_ANISOTROPY:`KHR_materials_anisotropy`,KHR_MATERIALS_UNLIT:`KHR_materials_unlit`,KHR_MATERIALS_VOLUME:`KHR_materials_volume`,KHR_TEXTURE_BASISU:`KHR_texture_basisu`,KHR_TEXTURE_TRANSFORM:`KHR_texture_transform`,KHR_MESH_QUANTIZATION:`KHR_mesh_quantization`,KHR_MATERIALS_EMISSIVE_STRENGTH:`KHR_materials_emissive_strength`,EXT_MATERIALS_BUMP:`EXT_materials_bump`,EXT_TEXTURE_WEBP:`EXT_texture_webp`,EXT_TEXTURE_AVIF:`EXT_texture_avif`,EXT_MESHOPT_COMPRESSION:`EXT_meshopt_compression`,KHR_MESHOPT_COMPRESSION:`KHR_meshopt_compression`,EXT_MESH_GPU_INSTANCING:`EXT_mesh_gpu_instancing`},Zs=class{constructor(e){this.parser=e,this.name=Z.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,r=t.length;n<r;n++){let r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n=`light:`+e,r=t.cache.get(n);if(r)return r;let i=t.json,a=((i.extensions&&i.extensions[this.name]||{}).lights||[])[e],o,s=new q(16777215);a.color!==void 0&&s.setRGB(a.color[0],a.color[1],a.color[2],ht);let c=a.range===void 0?0:a.range;switch(a.type){case`directional`:o=new Va(s),o.target.position.set(0,0,-1),o.add(o.target);break;case`point`:o=new Ra(s),o.distance=c;break;case`spot`:o=new Ia(s),o.distance=c,a.spot=a.spot||{},a.spot.innerConeAngle=a.spot.innerConeAngle===void 0?0:a.spot.innerConeAngle,a.spot.outerConeAngle=a.spot.outerConeAngle===void 0?Math.PI/4:a.spot.outerConeAngle,o.angle=a.spot.outerConeAngle,o.penumbra=1-a.spot.innerConeAngle/a.spot.outerConeAngle,o.target.position.set(0,0,-1),o.add(o.target);break;default:throw Error(`THREE.GLTFLoader: Unexpected light type: `+a.type)}return o.position.set(0,0,0),Vs(o,a),a.intensity!==void 0&&(o.intensity=a.intensity),o.name=t.createUniqueName(a.name||`light_`+e),r=Promise.resolve(o),t.cache.add(n,r),r}getDependency(e,t){if(e===`light`)return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,r=n.json.nodes[e],i=(r.extensions&&r.extensions[this.name]||{}).light;return i===void 0?null:this._loadLight(i).then(function(e){return n._getNodeRef(t.cache,i,e)})}},Qs=class{constructor(){this.name=Z.KHR_MATERIALS_UNLIT}getMaterialType(){return kr}extendParams(e,t,n){let r=[];e.color=new q(1,1,1),e.opacity=1;let i=t.pbrMetallicRoughness;if(i){if(Array.isArray(i.baseColorFactor)){let t=i.baseColorFactor;e.color.setRGB(t[0],t[1],t[2],ht),e.opacity=t[3]}i.baseColorTexture!==void 0&&r.push(n.assignTexture(e,`map`,i.baseColorTexture,H))}return Promise.all(r)}},$s=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);return n===null||n.emissiveStrength!==void 0&&(t.emissiveIntensity=n.emissiveStrength),Promise.resolve()}},ec=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];if(n.clearcoatFactor!==void 0&&(t.clearcoat=n.clearcoatFactor),n.clearcoatTexture!==void 0&&r.push(this.parser.assignTexture(t,`clearcoatMap`,n.clearcoatTexture)),n.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=n.clearcoatRoughnessFactor),n.clearcoatRoughnessTexture!==void 0&&r.push(this.parser.assignTexture(t,`clearcoatRoughnessMap`,n.clearcoatRoughnessTexture)),n.clearcoatNormalTexture!==void 0&&(r.push(this.parser.assignTexture(t,`clearcoatNormalMap`,n.clearcoatNormalTexture)),n.clearcoatNormalTexture.scale!==void 0)){let e=n.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new U(e,e)}return Promise.all(r)}},tc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_DISPERSION}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);return n===null||(t.dispersion=n.dispersion===void 0?0:n.dispersion),Promise.resolve()}},nc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.iridescenceFactor!==void 0&&(t.iridescence=n.iridescenceFactor),n.iridescenceTexture!==void 0&&r.push(this.parser.assignTexture(t,`iridescenceMap`,n.iridescenceTexture)),n.iridescenceIor!==void 0&&(t.iridescenceIOR=n.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),n.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=n.iridescenceThicknessMinimum),n.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=n.iridescenceThicknessMaximum),n.iridescenceThicknessTexture!==void 0&&r.push(this.parser.assignTexture(t,`iridescenceThicknessMap`,n.iridescenceThicknessTexture)),Promise.all(r)}},rc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_SHEEN}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];if(t.sheenColor=new q(0,0,0),t.sheenRoughness=0,t.sheen=1,n.sheenColorFactor!==void 0){let e=n.sheenColorFactor;t.sheenColor.setRGB(e[0],e[1],e[2],ht)}return n.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=n.sheenRoughnessFactor),n.sheenColorTexture!==void 0&&r.push(this.parser.assignTexture(t,`sheenColorMap`,n.sheenColorTexture,H)),n.sheenRoughnessTexture!==void 0&&r.push(this.parser.assignTexture(t,`sheenRoughnessMap`,n.sheenRoughnessTexture)),Promise.all(r)}},ic=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.transmissionFactor!==void 0&&(t.transmission=n.transmissionFactor),n.transmissionTexture!==void 0&&r.push(this.parser.assignTexture(t,`transmissionMap`,n.transmissionTexture)),Promise.all(r)}},ac=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_VOLUME}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];t.thickness=n.thicknessFactor===void 0?0:n.thicknessFactor,n.thicknessTexture!==void 0&&r.push(this.parser.assignTexture(t,`thicknessMap`,n.thicknessTexture)),t.attenuationDistance=n.attenuationDistance||1/0;let i=n.attenuationColor||[1,1,1];return t.attenuationColor=new q().setRGB(i[0],i[1],i[2],ht),Promise.all(r)}},oc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_IOR}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);return n===null?Promise.resolve():(t.ior=n.ior===void 0?1.5:n.ior,t.ior===0&&(t.ior=1e3),Promise.resolve())}},sc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_SPECULAR}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];t.specularIntensity=n.specularFactor===void 0?1:n.specularFactor,n.specularTexture!==void 0&&r.push(this.parser.assignTexture(t,`specularIntensityMap`,n.specularTexture));let i=n.specularColorFactor||[1,1,1];return t.specularColor=new q().setRGB(i[0],i[1],i[2],ht),n.specularColorTexture!==void 0&&r.push(this.parser.assignTexture(t,`specularColorMap`,n.specularColorTexture,H)),Promise.all(r)}},cc=class{constructor(e){this.parser=e,this.name=Z.EXT_MATERIALS_BUMP}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return t.bumpScale=n.bumpFactor===void 0?1:n.bumpFactor,n.bumpTexture!==void 0&&r.push(this.parser.assignTexture(t,`bumpMap`,n.bumpTexture)),Promise.all(r)}},lc=class{constructor(e){this.parser=e,this.name=Z.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return Rs(this.parser,e,this.name)===null?null:Ji}extendMaterialParams(e,t){let n=Rs(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.anisotropyStrength!==void 0&&(t.anisotropy=n.anisotropyStrength),n.anisotropyRotation!==void 0&&(t.anisotropyRotation=n.anisotropyRotation),n.anisotropyTexture!==void 0&&r.push(this.parser.assignTexture(t,`anisotropyMap`,n.anisotropyTexture)),Promise.all(r)}},uc=class{constructor(e){this.parser=e,this.name=Z.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,r=n.textures[e];if(!r.extensions||!r.extensions[this.name])return null;let i=r.extensions[this.name],a=t.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw Error(`THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures`);return null}return t.loadTextureImage(e,i.source,a)}},dc=class{constructor(e){this.parser=e,this.name=Z.EXT_TEXTURE_WEBP}loadTexture(e){let t=this.name,n=this.parser,r=n.json,i=r.textures[e];if(!i.extensions||!i.extensions[t])return null;let a=i.extensions[t],o=r.images[a.source],s=n.textureLoader;if(o.uri){let e=n.options.manager.getHandler(o.uri);e!==null&&(s=e)}return n.loadTextureImage(e,a.source,s)}},fc=class{constructor(e){this.parser=e,this.name=Z.EXT_TEXTURE_AVIF}loadTexture(e){let t=this.name,n=this.parser,r=n.json,i=r.textures[e];if(!i.extensions||!i.extensions[t])return null;let a=i.extensions[t],o=r.images[a.source],s=n.textureLoader;if(o.uri){let e=n.options.manager.getHandler(o.uri);e!==null&&(s=e)}return n.loadTextureImage(e,a.source,s)}},pc=class{constructor(e,t){this.name=t,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let e=n.extensions[this.name],r=this.parser.getDependency(`buffer`,e.buffer),i=this.parser.options.meshoptDecoder;if(!i||!i.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw Error(`THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files`);return null}return r.then(function(t){let n=e.byteOffset||0,r=e.byteLength||0,a=e.count,o=e.byteStride,s=new Uint8Array(t,n,r);return i.decodeGltfBufferAsync?i.decodeGltfBufferAsync(a,o,s,e.mode,e.filter).then(function(e){return e.buffer}):i.ready.then(function(){let t=new ArrayBuffer(a*o);return i.decodeGltfBuffer(new Uint8Array(t),a,o,s,e.mode,e.filter),t})})}else return null}},mc=class{constructor(e){this.name=Z.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let r=t.meshes[n.mesh];for(let e of r.primitives)if(e.mode!==Tc.TRIANGLES&&e.mode!==Tc.TRIANGLE_STRIP&&e.mode!==Tc.TRIANGLE_FAN&&e.mode!==void 0)return null;let i=n.extensions[this.name].attributes,a=[],o={};for(let e in i)a.push(this.parser.getDependency(`accessor`,i[e]).then(t=>(o[e]=t,o[e])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(e=>{let t=e.pop(),n=t.isGroup?t.children:[t],r=e[0].count,i=[];for(let e of n){let t=new K,n=new W,a=new kt,s=new W(1,1,1),c=new di(e.geometry,e.material,r);for(let e=0;e<r;e++)o.TRANSLATION&&n.fromBufferAttribute(o.TRANSLATION,e),o.ROTATION&&a.fromBufferAttribute(o.ROTATION,e),o.SCALE&&s.fromBufferAttribute(o.SCALE,e),c.setMatrixAt(e,t.compose(n,a,s));for(let t in o)if(t===`_COLOR_0`){let e=o[t];c.instanceColor=new ri(e.array,e.itemSize,e.normalized)}else t!==`TRANSLATION`&&t!==`ROTATION`&&t!==`SCALE`&&e.geometry.setAttribute(t,o[t]);_n.prototype.copy.call(c,e),this.parser.assignFinalMaterial(c),i.push(c)}return t.isGroup?(t.clear(),t.add(...i),t):i[0]}))}},hc=`glTF`,gc=12,_c={JSON:1313821514,BIN:5130562},vc=class{constructor(e){this.name=Z.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,gc),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==hc)throw Error(`THREE.GLTFLoader: Unsupported glTF-Binary header.`);if(this.header.version<2)throw Error(`THREE.GLTFLoader: Legacy binary file detected.`);let r=this.header.length-gc,i=new DataView(e,gc),a=0;for(;a<r;){let t=i.getUint32(a,!0);a+=4;let r=i.getUint32(a,!0);if(a+=4,r===_c.JSON){let r=new Uint8Array(e,gc+a,t);this.content=n.decode(r)}else if(r===_c.BIN){let n=gc+a;this.body=e.slice(n,n+t)}a+=t}if(this.content===null)throw Error(`THREE.GLTFLoader: JSON content not found.`)}},yc=class{constructor(e,t){if(!t)throw Error(`THREE.GLTFLoader: No DRACOLoader instance provided.`);this.name=Z.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,r=this.dracoLoader,i=e.extensions[this.name].bufferView,a=e.extensions[this.name].attributes,o={},s={},c={};for(let e in a){let t=Ac[e]||e.toLowerCase();o[t]=a[e]}for(let t in e.attributes){let r=Ac[t]||t.toLowerCase();if(a[t]!==void 0){let i=n.accessors[e.attributes[t]];c[r]=Ec[i.componentType].name,s[r]=i.normalized===!0}}return t.getDependency(`bufferView`,i).then(function(e){return new Promise(function(t,n){r.decodeDracoFile(e,function(e){for(let t in e.attributes){let n=e.attributes[t],r=s[t];r!==void 0&&(n.normalized=r)}t(e)},o,c,ht,n)})})}},bc=class{constructor(){this.name=Z.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0?e:(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0,e)}},xc=class{constructor(){this.name=Z.KHR_MESH_QUANTIZATION}},Sc=class extends Zi{constructor(e,t,n,r){super(e,t,n,r)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r*3+r;for(let e=0;e!==r;e++)t[e]=n[i+e];return t}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=o*2,c=o*3,l=r-t,u=(n-t)/l,d=u*u,f=d*u,p=e*c,m=p-c,h=-2*f+3*d,g=f-d,_=1-h,v=g-d+u;for(let e=0;e!==o;e++){let t=a[m+e+o],n=a[m+e+s]*l,r=a[p+e+o],c=a[p+e]*l;i[e]=_*t+v*n+h*r+g*c}return i}},Cc=new kt,wc=class extends Sc{interpolate_(e,t,n,r){let i=super.interpolate_(e,t,n,r);return Cc.fromArray(i).normalize().toArray(i),i}},Tc={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Ec={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Dc={9728:Ze,9729:et,9984:Qe,9985:tt,9986:$e,9987:nt},Oc={33071:Ye,33648:Xe,10497:Je},kc={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Ac={POSITION:`position`,NORMAL:`normal`,TANGENT:`tangent`,TEXCOORD_0:`uv`,TEXCOORD_1:`uv1`,TEXCOORD_2:`uv2`,TEXCOORD_3:`uv3`,COLOR_0:`color`,WEIGHTS_0:`skinWeight`,JOINTS_0:`skinIndex`},jc={scale:`scale`,translation:`position`,rotation:`quaternion`,weights:`morphTargetInfluences`},Mc={CUBICSPLINE:void 0,LINEAR:ct,STEP:st},Nc={OPAQUE:`OPAQUE`,MASK:`MASK`,BLEND:`BLEND`},Pc=new K,Fc=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Ls,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,r=-1,i=!1,a=-1;if(typeof navigator<`u`&&navigator.userAgent!==void 0){let e=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(e)===!0;let t=e.match(/Version\/(\d+)/);r=n&&t?parseInt(t[1],10):-1,i=e.indexOf(`Firefox`)>-1,a=i?e.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>`u`||n&&r<17||i&&a<98?this.textureLoader=new xa(this.options.manager):this.textureLoader=new Ka(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new _a(this.options.manager),this.fileLoader.setResponseType(`arraybuffer`),this.options.crossOrigin===`use-credentials`&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,r=this.json,i=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(e){return e._markDefs&&e._markDefs()}),Promise.all(this._invokeAll(function(e){return e.beforeRoot&&e.beforeRoot()})).then(function(){return Promise.all([n.getDependencies(`scene`),n.getDependencies(`animation`),n.getDependencies(`camera`)])}).then(function(t){let a={scene:t[0][r.scene||0],scenes:t[0],animations:t[1],cameras:t[2],asset:r.asset,parser:n,userData:{}};return Bs(i,a,r),Vs(a,r),Promise.all(n._invokeAll(function(e){return e.afterRoot&&e.afterRoot(a)})).then(function(){for(let e of a.scenes)e.updateMatrixWorld();e(a)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let n=0,r=t.length;n<r;n++){let r=t[n].joints;for(let t=0,n=r.length;t<n;t++)e[r[t]].isBone=!0}for(let t=0,r=e.length;t<r;t++){let r=e[t];r.mesh!==void 0&&(this._addNodeRef(this.meshCache,r.mesh),r.skin!==void 0&&(n[r.mesh].isSkinnedMesh=!0)),r.camera!==void 0&&this._addNodeRef(this.cameraCache,r.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let r=n.clone(),i=(e,t)=>{let n=this.associations.get(e);n!=null&&this.associations.set(t,n);for(let[n,r]of e.children.entries())i(r,t.children[n])};return i(n,r),r.name+=`_instance_`+ e.uses[t]++,r}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let r=e(t[n]);if(r)return r}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let r=0;r<t.length;r++){let i=e(t[r]);i&&n.push(i)}return n}getDependency(e,t){let n=e+`:`+t,r=this.cache.get(n);if(!r){switch(e){case`scene`:r=this.loadScene(t);break;case`node`:r=this._invokeOne(function(e){return e.loadNode&&e.loadNode(t)});break;case`mesh`:r=this._invokeOne(function(e){return e.loadMesh&&e.loadMesh(t)});break;case`accessor`:r=this.loadAccessor(t);break;case`bufferView`:r=this._invokeOne(function(e){return e.loadBufferView&&e.loadBufferView(t)});break;case`buffer`:r=this.loadBuffer(t);break;case`material`:r=this._invokeOne(function(e){return e.loadMaterial&&e.loadMaterial(t)});break;case`texture`:r=this._invokeOne(function(e){return e.loadTexture&&e.loadTexture(t)});break;case`skin`:r=this.loadSkin(t);break;case`animation`:r=this._invokeOne(function(e){return e.loadAnimation&&e.loadAnimation(t)});break;case`camera`:r=this.loadCamera(t);break;default:if(r=this._invokeOne(function(n){return n!=this&&n.getDependency&&n.getDependency(e,t)}),!r)throw Error(`Unknown type: `+e);break}this.cache.add(n,r)}return r}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,r=this.json[e+(e===`mesh`?`es`:`s`)]||[];t=Promise.all(r.map(function(t,r){return n.getDependency(e,r)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!==`arraybuffer`)throw Error(`THREE.GLTFLoader: `+t.type+` buffer type is not supported.`);if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Z.KHR_BINARY_GLTF].body);let r=this.options;return new Promise(function(e,i){n.load(Wa.resolveURL(t.uri,r.path),e,void 0,function(){i(Error(`THREE.GLTFLoader: Failed to load buffer "`+t.uri+`".`))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency(`buffer`,t.buffer).then(function(e){let n=t.byteLength||0,r=t.byteOffset||0;return e.slice(r,r+n)})}loadAccessor(e){let t=this,n=this.json,r=this.json.accessors[e];if(r.bufferView===void 0&&r.sparse===void 0){let e=kc[r.type],t=Ec[r.componentType],n=r.normalized===!0,i=new t(r.count*e);return Promise.resolve(new tr(i,e,n))}let i=[];return r.bufferView===void 0?i.push(null):i.push(this.getDependency(`bufferView`,r.bufferView)),r.sparse!==void 0&&(i.push(this.getDependency(`bufferView`,r.sparse.indices.bufferView)),i.push(this.getDependency(`bufferView`,r.sparse.values.bufferView))),Promise.all(i).then(function(e){let i=e[0],a=kc[r.type],o=Ec[r.componentType],s=o.BYTES_PER_ELEMENT,c=s*a,l=r.byteOffset||0,u=r.bufferView===void 0?void 0:n.bufferViews[r.bufferView].byteStride,d=r.normalized===!0,f,p;if(u&&u!==c){let e=Math.floor(l/u),n=`InterleavedBuffer:`+r.bufferView+`:`+r.componentType+`:`+e+`:`+r.count,c=t.cache.get(n);c||(f=new o(i,e*u,r.count*u/s),c=new gr(f,u/s),t.cache.add(n,c)),p=new vr(c,a,l%u/s,d)}else f=i===null?new o(r.count*a):new o(i,l,r.count*a),p=new tr(f,a,d);if(r.sparse!==void 0){let t=kc.SCALAR,n=Ec[r.sparse.indices.componentType],s=r.sparse.indices.byteOffset||0,c=r.sparse.values.byteOffset||0,l=new n(e[1],s,r.sparse.count*t),u=new o(e[2],c,r.sparse.count*a);i!==null&&(p=new tr(p.array.slice(),p.itemSize,p.normalized)),p.normalized=!1;for(let e=0,t=l.length;e<t;e++){let t=l[e];if(p.setX(t,u[e*a]),a>=2&&p.setY(t,u[e*a+1]),a>=3&&p.setZ(t,u[e*a+2]),a>=4&&p.setW(t,u[e*a+3]),a>=5)throw Error(`THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.`)}p.normalized=d}return p})}loadTexture(e){let t=this.json,n=this.options,r=t.textures[e].source,i=t.images[r],a=this.textureLoader;if(i.uri){let e=n.manager.getHandler(i.uri);e!==null&&(a=e)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){let r=this,i=this.json,a=i.textures[e],o=i.images[t],s=(o.uri||o.bufferView)+`:`+a.sampler;if(this.textureCache[s])return this.textureCache[s];let c=this.loadImageSource(t,n).then(function(t){t.flipY=!1,t.name=a.name||o.name||``,t.name===``&&typeof o.uri==`string`&&o.uri.startsWith(`data:image/`)===!1&&(t.name=o.uri);let n=(i.samplers||{})[a.sampler]||{};return t.magFilter=Dc[n.magFilter]||1006,t.minFilter=Dc[n.minFilter]||1008,t.wrapS=Oc[n.wrapS]||1e3,t.wrapT=Oc[n.wrapT]||1e3,t.generateMipmaps=!t.isCompressedTexture&&t.minFilter!==1003&&t.minFilter!==1006,r.associations.set(t,{textures:e}),t}).catch(function(){return null});return this.textureCache[s]=c,c}loadImageSource(e,t){let n=this,r=this.json,i=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(e=>e.clone());let a=r.images[e],o=self.URL||self.webkitURL,s=a.uri||``,c=!1;if(a.bufferView!==void 0)s=n.getDependency(`bufferView`,a.bufferView).then(function(e){c=!0;let t=new Blob([e],{type:a.mimeType});return s=o.createObjectURL(t),s});else if(a.uri===void 0)throw Error(`THREE.GLTFLoader: Image `+e+` is missing URI and bufferView`);let l=Promise.resolve(s).then(function(e){return new Promise(function(n,r){let a=n;t.isImageBitmapLoader===!0&&(a=function(e){let t=new Ht(e);t.needsUpdate=!0,n(t)}),t.load(Wa.resolveURL(e,i.path),a,void 0,r)})}).then(function(e){return c===!0&&o.revokeObjectURL(s),Vs(e,a),e.userData.mimeType=a.mimeType||qs(a.uri),e}).catch(function(e){throw console.error(`THREE.GLTFLoader: Couldn't load texture`,s),e});return this.sourceCache[e]=l,l}assignTexture(e,t,n,r){let i=this;return this.getDependency(`texture`,n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),i.extensions[Z.KHR_TEXTURE_TRANSFORM]){let e=n.extensions===void 0?void 0:n.extensions[Z.KHR_TEXTURE_TRANSFORM];if(e){let t=i.associations.get(a);a=i.extensions[Z.KHR_TEXTURE_TRANSFORM].extendTexture(a,e),i.associations.set(a,t)}}return r!==void 0&&(a.colorSpace=r),e[t]=a,a})}assignFinalMaterial(e){let t=e.geometry,n=e.material,r=t.attributes.tangent===void 0,i=t.attributes.color!==void 0,a=t.attributes.normal===void 0;if(e.isPoints){let e=`PointsMaterial:`+n.uuid,t=this.cache.get(e);t||(t=new Ni,br.prototype.copy.call(t,n),t.color.copy(n.color),t.map=n.map,t.sizeAttenuation=!1,this.cache.add(e,t)),n=t}else if(e.isLine){let e=`LineBasicMaterial:`+n.uuid,t=this.cache.get(e);t||(t=new bi,br.prototype.copy.call(t,n),t.color.copy(n.color),t.map=n.map,this.cache.add(e,t)),n=t}if(r||i||a){let e=`ClonedMaterial:`+n.uuid+`:`;r&&(e+=`derivative-tangents:`),i&&(e+=`vertex-colors:`),a&&(e+=`flat-shading:`);let t=this.cache.get(e);t||(t=n.clone(),i&&(t.vertexColors=!0),a&&(t.flatShading=!0),r&&(t.normalScale&&(t.normalScale.y*=-1),t.clearcoatNormalScale&&(t.clearcoatNormalScale.y*=-1)),this.cache.add(e,t),this.associations.set(t,this.associations.get(n))),n=t}e.material=n}getMaterialType(){return qi}loadMaterial(e){let t=this,n=this.json,r=this.extensions,i=n.materials[e],a,o={},s=i.extensions||{},c=[];if(s[Z.KHR_MATERIALS_UNLIT]){let e=r[Z.KHR_MATERIALS_UNLIT];a=e.getMaterialType(),c.push(e.extendParams(o,i,t))}else{let n=i.pbrMetallicRoughness||{};if(o.color=new q(1,1,1),o.opacity=1,Array.isArray(n.baseColorFactor)){let e=n.baseColorFactor;o.color.setRGB(e[0],e[1],e[2],ht),o.opacity=e[3]}n.baseColorTexture!==void 0&&c.push(t.assignTexture(o,`map`,n.baseColorTexture,H)),o.metalness=n.metallicFactor===void 0?1:n.metallicFactor,o.roughness=n.roughnessFactor===void 0?1:n.roughnessFactor,n.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(o,`metalnessMap`,n.metallicRoughnessTexture)),c.push(t.assignTexture(o,`roughnessMap`,n.metallicRoughnessTexture))),a=this._invokeOne(function(t){return t.getMaterialType&&t.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(t){return t.extendMaterialParams&&t.extendMaterialParams(e,o)})))}i.doubleSided===!0&&(o.side=2);let l=i.alphaMode||Nc.OPAQUE;if(l===Nc.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,l===Nc.MASK&&(o.alphaTest=i.alphaCutoff===void 0?.5:i.alphaCutoff)),i.normalTexture!==void 0&&a!==kr&&(c.push(t.assignTexture(o,`normalMap`,i.normalTexture)),o.normalScale=new U(1,1),i.normalTexture.scale!==void 0)){let e=i.normalTexture.scale;o.normalScale.set(e,e)}if(i.occlusionTexture!==void 0&&a!==kr&&(c.push(t.assignTexture(o,`aoMap`,i.occlusionTexture)),i.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=i.occlusionTexture.strength)),i.emissiveFactor!==void 0&&a!==kr){let e=i.emissiveFactor;o.emissive=new q().setRGB(e[0],e[1],e[2],ht)}return i.emissiveTexture!==void 0&&a!==kr&&c.push(t.assignTexture(o,`emissiveMap`,i.emissiveTexture,H)),Promise.all(c).then(function(){let n=new a(o);return i.name&&(n.name=i.name),Vs(n,i),t.associations.set(n,{materials:e}),i.extensions&&Bs(r,n,i),n})}createUniqueName(e){let t=io.sanitizeNodeName(e||``);return t in this.nodeNamesUsed?t+`_`+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,r=this.primitiveCache;function i(e){return n[Z.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e,t).then(function(n){return Ys(n,e,t)})}let a=[];for(let n=0,o=e.length;n<o;n++){let o=e[n],s=Ws(o),c=r[s];if(c)a.push(c.promise);else{let e;e=o.extensions&&o.extensions[Z.KHR_DRACO_MESH_COMPRESSION]?i(o):Ys(new hr,o,t),r[s]={primitive:o,promise:e},a.push(e)}}return Promise.all(a)}loadMesh(e){let t=this,n=this.json,r=this.extensions,i=n.meshes[e],a=i.primitives,o=[];for(let e=0,t=a.length;e<t;e++){let t=a[e].material===void 0?zs(this.cache):this.getDependency(`material`,a[e].material);o.push(t)}return o.push(t.loadGeometries(a)),Promise.all(o).then(function(n){let o=n.slice(0,n.length-1),s=n[n.length-1],c=[];for(let n=0,l=s.length;n<l;n++){let l=s[n],u=a[n],d,f=o[n];if(u.mode===Tc.TRIANGLES||u.mode===Tc.TRIANGLE_STRIP||u.mode===Tc.TRIANGLE_FAN||u.mode===void 0)d=i.isSkinnedMesh===!0?new Zr(l,f):new Vr(l,f),d.isSkinnedMesh===!0&&d.normalizeSkinWeights(),u.mode===Tc.TRIANGLE_STRIP?d.geometry=js(d.geometry,1):u.mode===Tc.TRIANGLE_FAN&&(d.geometry=js(d.geometry,2));else if(u.mode===Tc.LINES)d=new ji(l,f);else if(u.mode===Tc.LINE_STRIP)d=new Oi(l,f);else if(u.mode===Tc.LINE_LOOP)d=new Mi(l,f);else if(u.mode===Tc.POINTS)d=new Ri(l,f);else throw Error(`THREE.GLTFLoader: Primitive mode unsupported: `+u.mode);Object.keys(d.geometry.morphAttributes).length>0&&Us(d,i),d.name=t.createUniqueName(i.name||`mesh_`+e),Vs(d,i),u.extensions&&Bs(r,d,u),t.assignFinalMaterial(d),c.push(d)}for(let n=0,r=c.length;n<r;n++)t.associations.set(c[n],{meshes:e,primitives:n});if(c.length===1)return i.extensions&&Bs(r,c[0],i),c[0];let l=new vn;i.extensions&&Bs(r,l,i),t.associations.set(l,{meshes:e});for(let e=0,t=c.length;e<t;e++)l.add(c[e]);return l})}loadCamera(e){let t,n=this.json.cameras[e],r=n[n.type];if(!r){console.warn(`THREE.GLTFLoader: Missing camera parameters.`);return}return n.type===`perspective`?t=new Pa(Ot.radToDeg(r.yfov),r.aspectRatio||1,r.znear||1,r.zfar||2e6):n.type===`orthographic`&&(t=new za(-r.xmag,r.xmag,r.ymag,-r.ymag,r.znear,r.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Vs(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let e=0,r=t.joints.length;e<r;e++)n.push(this._loadNodeShallow(t.joints[e]));return t.inverseBindMatrices===void 0?n.push(null):n.push(this.getDependency(`accessor`,t.inverseBindMatrices)),Promise.all(n).then(function(e){let n=e.pop(),r=e,i=[],a=[];for(let e=0,o=r.length;e<o;e++){let o=r[e];if(o){i.push(o);let t=new K;n!==null&&t.fromArray(n.array,e*16),a.push(t)}else console.warn(`THREE.GLTFLoader: Joint "%s" could not be found.`,t.joints[e])}return new ni(i,a)})}loadAnimation(e){let t=this.json,n=this,r=t.animations[e],i=r.name?r.name:`animation_`+e,a=[],o=[],s=[],c=[],l=[];for(let e=0,t=r.channels.length;e<t;e++){let t=r.channels[e],n=r.samplers[t.sampler],i=t.target,u=i.node,d=r.parameters===void 0?n.input:r.parameters[n.input],f=r.parameters===void 0?n.output:r.parameters[n.output];i.node!==void 0&&(a.push(this.getDependency(`node`,u)),o.push(this.getDependency(`accessor`,d)),s.push(this.getDependency(`accessor`,f)),c.push(n),l.push(i))}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(s),Promise.all(c),Promise.all(l)]).then(function(e){let t=e[0],a=e[1],o=e[2],s=e[3],c=e[4],l=[];for(let e=0,r=t.length;e<r;e++){let r=t[e],i=a[e],u=o[e],d=s[e],f=c[e];if(r===void 0)continue;r.updateMatrix&&r.updateMatrix();let p=n._createAnimationTracks(r,i,u,d,f);if(p)for(let e=0;e<p.length;e++)l.push(p[e])}let u=new ua(i,void 0,l);return Vs(u,r),u})}createNodeMesh(e){let t=this.json,n=this,r=t.nodes[e];return r.mesh===void 0?null:n.getDependency(`mesh`,r.mesh).then(function(e){let t=n._getNodeRef(n.meshCache,r.mesh,e);return r.weights!==void 0&&t.traverse(function(e){if(e.isMesh)for(let t=0,n=r.weights.length;t<n;t++)e.morphTargetInfluences[t]=r.weights[t]}),t})}loadNode(e){let t=this.json,n=this,r=t.nodes[e],i=n._loadNodeShallow(e),a=[],o=r.children||[];for(let e=0,t=o.length;e<t;e++)a.push(n.getDependency(`node`,o[e]));let s=r.skin===void 0?Promise.resolve(null):n.getDependency(`skin`,r.skin);return Promise.all([i,Promise.all(a),s]).then(function(e){let t=e[0],n=e[1],r=e[2];r!==null&&t.traverse(function(e){e.isSkinnedMesh&&e.bind(r,Pc)});for(let e=0,r=n.length;e<r;e++)t.add(n[e]);if(t.userData.pivot!==void 0&&n.length>0){let e=t.userData.pivot,r=n[0];t.pivot=new W().fromArray(e),t.position.x-=e[0],t.position.y-=e[1],t.position.z-=e[2],r.position.set(0,0,0),delete t.userData.pivot}return t})}_loadNodeShallow(e){let t=this.json,n=this.extensions,r=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let i=t.nodes[e],a=i.name?r.createUniqueName(i.name):``,o=[],s=r._invokeOne(function(t){return t.createNodeMesh&&t.createNodeMesh(e)});return s&&o.push(s),i.camera!==void 0&&o.push(r.getDependency(`camera`,i.camera).then(function(e){return r._getNodeRef(r.cameraCache,i.camera,e)})),r._invokeAll(function(t){return t.createNodeAttachment&&t.createNodeAttachment(e)}).forEach(function(e){o.push(e)}),this.nodeCache[e]=Promise.all(o).then(function(t){let o;if(o=i.isBone===!0?new Qr:t.length>1?new vn:t.length===1?t[0]:new _n,o!==t[0])for(let e=0,n=t.length;e<n;e++)o.add(t[e]);if(i.name&&(o.userData.name=i.name,o.name=a),Vs(o,i),i.extensions&&Bs(n,o,i),i.matrix!==void 0){let e=new K;e.fromArray(i.matrix),o.applyMatrix4(e)}else i.translation!==void 0&&o.position.fromArray(i.translation),i.rotation!==void 0&&o.quaternion.fromArray(i.rotation),i.scale!==void 0&&o.scale.fromArray(i.scale);if(!r.associations.has(o))r.associations.set(o,{});else if(i.mesh!==void 0&&r.meshCache.refs[i.mesh]>1){let e=r.associations.get(o);r.associations.set(o,{...e})}return r.associations.get(o).nodes=e,o}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],r=this,i=new vn;n.name&&(i.name=r.createUniqueName(n.name)),Vs(i,n),n.extensions&&Bs(t,i,n);let a=n.nodes||[],o=[];for(let e=0,t=a.length;e<t;e++)o.push(r.getDependency(`node`,a[e]));return Promise.all(o).then(function(e){for(let t=0,n=e.length;t<n;t++){let n=e[t];n.parent===null?i.add(n):i.add(Ns(n))}return r.associations=(e=>{let t=new Map;for(let[e,n]of r.associations)(e instanceof br||e instanceof Ht)&&t.set(e,n);return e.traverse(e=>{let n=r.associations.get(e);n!=null&&t.set(e,n)}),t})(i),i})}_createAnimationTracks(e,t,n,r,i){let a=[],o=e.name?e.name:e.uuid,s=[];function c(e){e.morphTargetInfluences&&s.push(e.name?e.name:e.uuid)}jc[i.path]===jc.weights?(c(e),e.isGroup&&e.children.forEach(c)):s.push(o);let l;switch(jc[i.path]){case jc.weights:l=aa;break;case jc.rotation:l=sa;break;case jc.translation:case jc.scale:l=la;break;default:switch(n.itemSize){case 1:l=aa;break;default:l=la;break}break}let u=r.interpolation===void 0?ct:Mc[r.interpolation],d=this._getArrayFromAccessor(n);for(let e=0,n=s.length;e<n;e++){let n=new l(s[e]+`.`+jc[i.path],t.array,d,u);r.interpolation===`CUBICSPLINE`&&this._createCubicSplineTrackInterpolant(n),a.push(n)}return a}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let e=Ks(t.constructor),n=new Float32Array(t.length);for(let r=0,i=t.length;r<i;r++)n[r]=t[r]*e;t=n}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(e){return new(this instanceof sa?wc:Sc)(this.times,this.values,this.getValueSize()/3,e)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}})),Lc=r({OBJLoader:()=>Xc});function Rc(){let e={objects:[],object:{},vertices:[],normals:[],colors:[],uvs:[],materials:{},materialLibraries:[],startObject:function(e,t){if(this.object&&this.object.fromDeclaration===!1){this.object.name=e,this.object.fromDeclaration=t!==!1;return}let n=this.object&&typeof this.object.currentMaterial==`function`?this.object.currentMaterial():void 0;if(this.object&&typeof this.object._finalize==`function`&&this.object._finalize(!0),this.object={name:e||``,fromDeclaration:t!==!1,geometry:{vertices:[],normals:[],colors:[],uvs:[],hasUVIndices:!1},materials:[],smooth:!0,startMaterial:function(e,t){let n=this._finalize(!1);n&&(n.inherited||n.groupCount<=0)&&this.materials.splice(n.index,1);let r={index:this.materials.length,name:e||``,mtllib:Array.isArray(t)&&t.length>0?t[t.length-1]:``,smooth:n===void 0?this.smooth:n.smooth,groupStart:n===void 0?0:n.groupEnd,groupEnd:-1,groupCount:-1,inherited:!1,clone:function(e){let t={index:typeof e==`number`?e:this.index,name:this.name,mtllib:this.mtllib,smooth:this.smooth,groupStart:0,groupEnd:-1,groupCount:-1,inherited:!1};return t.clone=this.clone.bind(t),t}};return this.materials.push(r),r},currentMaterial:function(){if(this.materials.length>0)return this.materials[this.materials.length-1]},_finalize:function(e){let t=this.currentMaterial();if(t&&t.groupEnd===-1&&(t.groupEnd=this.geometry.vertices.length/3,t.groupCount=t.groupEnd-t.groupStart,t.inherited=!1),e&&this.materials.length>1)for(let e=this.materials.length-1;e>=0;e--)this.materials[e].groupCount<=0&&this.materials.splice(e,1);return e&&this.materials.length===0&&this.materials.push({name:``,smooth:this.smooth}),t}},n&&n.name&&typeof n.clone==`function`){let e=n.clone(0);e.inherited=!0,this.object.materials.push(e)}this.objects.push(this.object)},finalize:function(){this.object&&typeof this.object._finalize==`function`&&this.object._finalize(!0)},parseVertexIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseNormalIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseUVIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/2)*2},addVertex:function(e,t,n){let r=this.vertices,i=this.object.geometry.vertices;i.push(r[e+0],r[e+1],r[e+2]),i.push(r[t+0],r[t+1],r[t+2]),i.push(r[n+0],r[n+1],r[n+2])},addVertexPoint:function(e){let t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addVertexLine:function(e){let t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addNormal:function(e,t,n){let r=this.normals,i=this.object.geometry.normals;i.push(r[e+0],r[e+1],r[e+2]),i.push(r[t+0],r[t+1],r[t+2]),i.push(r[n+0],r[n+1],r[n+2])},addFaceNormal:function(e,t,n){let r=this.vertices,i=this.object.geometry.normals;Wc.fromArray(r,e),Gc.fromArray(r,t),Kc.fromArray(r,n),Jc.subVectors(Kc,Gc),qc.subVectors(Wc,Gc),Jc.cross(qc),Jc.normalize(),i.push(Jc.x,Jc.y,Jc.z),i.push(Jc.x,Jc.y,Jc.z),i.push(Jc.x,Jc.y,Jc.z)},addColor:function(e,t,n){let r=this.colors,i=this.object.geometry.colors;r[e]!==void 0&&i.push(r[e+0],r[e+1],r[e+2]),r[t]!==void 0&&i.push(r[t+0],r[t+1],r[t+2]),r[n]!==void 0&&i.push(r[n+0],r[n+1],r[n+2])},addUV:function(e,t,n){let r=this.uvs,i=this.object.geometry.uvs;i.push(r[e+0],r[e+1]),i.push(r[t+0],r[t+1]),i.push(r[n+0],r[n+1])},addDefaultUV:function(){let e=this.object.geometry.uvs;e.push(0,0),e.push(0,0),e.push(0,0)},addUVLine:function(e){let t=this.uvs;this.object.geometry.uvs.push(t[e+0],t[e+1])},addFace:function(e,t,n,r,i,a,o,s,c){let l=this.vertices.length,u=this.parseVertexIndex(e,l),d=this.parseVertexIndex(t,l),f=this.parseVertexIndex(n,l);if(this.addVertex(u,d,f),this.addColor(u,d,f),o!==void 0&&o!==``){let e=this.normals.length;u=this.parseNormalIndex(o,e),d=this.parseNormalIndex(s,e),f=this.parseNormalIndex(c,e),this.addNormal(u,d,f)}else this.addFaceNormal(u,d,f);if(r!==void 0&&r!==``){let e=this.uvs.length;u=this.parseUVIndex(r,e),d=this.parseUVIndex(i,e),f=this.parseUVIndex(a,e),this.addUV(u,d,f),this.object.geometry.hasUVIndices=!0}else this.addDefaultUV()},addPointGeometry:function(e){this.object.geometry.type=`Points`;let t=this.vertices.length;for(let n=0,r=e.length;n<r;n++){let r=this.parseVertexIndex(e[n],t);this.addVertexPoint(r),this.addColor(r)}},addLineGeometry:function(e,t){this.object.geometry.type=`Line`;let n=this.vertices.length,r=this.uvs.length;for(let t=0,r=e.length;t<r;t++)this.addVertexLine(this.parseVertexIndex(e[t],n));for(let e=0,n=t.length;e<n;e++)this.addUVLine(this.parseUVIndex(t[e],r))}};return e.startObject(``,!1),e}var zc,Bc,Vc,Hc,Uc,Wc,Gc,Kc,qc,Jc,Yc,Xc,Zc=t((()=>{lo(),zc=/^[og]\s*(.+)?/,Bc=/^mtllib /,Vc=/^usemtl /,Hc=/^usemap /,Uc=/\s+/,Wc=new W,Gc=new W,Kc=new W,qc=new W,Jc=new W,Yc=new q,Xc=class extends ma{constructor(e){super(e),this.materials=null}load(e,t,n,r){let i=this,a=new _a(this.manager);a.setPath(this.path),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(n){try{t(i.parse(n))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}setMaterials(e){return this.materials=e,this}parse(e){let t=new Rc;e.indexOf(`\r
`)!==-1&&(e=e.replace(/\r\n/g,`
`)),e.indexOf(`\\
`)!==-1&&(e=e.replace(/\\\n/g,``));let n=e.split(`
`),r=[];for(let e=0,i=n.length;e<i;e++){let i=n[e].trimStart();if(i.length===0)continue;let a=i.charAt(0);if(a!==`#`)if(a===`v`){let e=i.split(Uc);switch(e[0]){case`v`:t.vertices.push(parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])),e.length>=7?(Yc.setRGB(parseFloat(e[4]),parseFloat(e[5]),parseFloat(e[6]),H),t.colors.push(Yc.r,Yc.g,Yc.b)):t.colors.push(void 0,void 0,void 0);break;case`vn`:t.normals.push(parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3]));break;case`vt`:t.uvs.push(parseFloat(e[1]),parseFloat(e[2]));break}}else if(a===`f`){let e=i.slice(1).trim().split(Uc),n=[];for(let t=0,r=e.length;t<r;t++){let r=e[t];if(r.length>0){let e=r.split(`/`);n.push(e)}}let r=n[0];for(let e=1,i=n.length-1;e<i;e++){let i=n[e],a=n[e+1];t.addFace(r[0],i[0],a[0],r[1],i[1],a[1],r[2],i[2],a[2])}}else if(a===`l`){let e=i.substring(1).trim().split(` `),n=[],r=[];if(i.indexOf(`/`)===-1)n=e;else for(let t=0,i=e.length;t<i;t++){let i=e[t].split(`/`);i[0]!==``&&n.push(i[0]),i[1]!==``&&r.push(i[1])}t.addLineGeometry(n,r)}else if(a===`p`){let e=i.slice(1).trim().split(` `);t.addPointGeometry(e)}else if((r=zc.exec(i))!==null){let e=(` `+r[0].slice(1).trim()).slice(1);t.startObject(e)}else if(Vc.test(i))t.object.startMaterial(i.substring(7).trim(),t.materialLibraries);else if(Bc.test(i))t.materialLibraries.push(i.substring(7).trim());else if(Hc.test(i))console.warn(`THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.`);else if(a===`s`){if(r=i.split(` `),r.length>1){let e=r[1].trim().toLowerCase();t.object.smooth=e!==`0`&&e!==`off`}else t.object.smooth=!0;let e=t.object.currentMaterial();e&&(e.smooth=t.object.smooth)}else{if(i===`\0`)continue;console.warn(`THREE.OBJLoader: Unexpected line: "`+i+`"`)}}t.finalize();let i=new vn;if(i.materialLibraries=[].concat(t.materialLibraries),!(t.objects.length===1&&t.objects[0].geometry.vertices.length===0))for(let e=0,n=t.objects.length;e<n;e++){let n=t.objects[e],r=n.geometry,a=n.materials,o=r.type===`Line`,s=r.type===`Points`,c=!1;if(r.vertices.length===0)continue;let l=new hr;l.setAttribute(`position`,new J(r.vertices,3)),r.normals.length>0&&l.setAttribute(`normal`,new J(r.normals,3)),r.colors.length>0&&(c=!0,l.setAttribute(`color`,new J(r.colors,3))),r.hasUVIndices===!0&&l.setAttribute(`uv`,new J(r.uvs,2));let u=[];for(let e=0,n=a.length;e<n;e++){let n=a[e],r=n.name+`_`+n.smooth+`_`+c,i=t.materials[r];if(this.materials!==null){if(i=this.materials.create(n.name),o&&i&&!(i instanceof bi)){let e=new bi;br.prototype.copy.call(e,i),e.color.copy(i.color),i=e}else if(s&&i&&!(i instanceof Ni)){let e=new Ni({size:10,sizeAttenuation:!1});br.prototype.copy.call(e,i),e.color.copy(i.color),e.map=i.map,i=e}}i===void 0&&(i=o?new bi:s?new Ni({size:1,sizeAttenuation:!1}):new Yi,i.name=n.name,i.flatShading=!n.smooth,i.vertexColors=c,t.materials[r]=i),u.push(i)}let d;if(u.length>1){for(let e=0,t=a.length;e<t;e++){let t=a[e];l.addGroup(t.groupStart,t.groupCount,e)}d=o?new ji(l,u):s?new Ri(l,u):new Vr(l,u)}else d=o?new ji(l,u[0]):s?new Ri(l,u[0]):new Vr(l,u[0]);d.name=n.name,i.add(d)}else if(t.vertices.length>0){let e=new Ni({size:1,sizeAttenuation:!1}),n=new hr;n.setAttribute(`position`,new J(t.vertices,3)),t.colors.length>0&&t.colors[0]!==void 0&&(n.setAttribute(`color`,new J(t.colors,3)),e.vertexColors=!0);let r=new Ri(n,e);i.add(r)}return i}}}));function Qc(e){let t=e.length;if(t<6||t%2)return null;let n=[1/0,1/0,1/0],r=[-1/0,-1/0,-1/0],i=[0,0,0];for(let a=0;a<t;a++){let o=e[a],s=e[(a+1)%t];for(let[e,t]of[o.x,o.y,o.z].entries()){if(!Number.isFinite(t))return null;n[e]=Math.min(n[e],t),r[e]=Math.max(r[e],t)}i[0]+=(o.y-s.y)*(o.z+s.z),i[1]+=(o.z-s.z)*(o.x+s.x),i[2]+=(o.x-s.x)*(o.y+s.y)}let a=Math.hypot(...r.map((e,t)=>e-n[t])),o=Math.hypot(...i);if(!a||o<a*a*1e-12)return null;let s=e[0];if(!e.some(e=>Math.abs((e.x-s.x)*i[0]+(e.y-s.y)*i[1]+(e.z-s.z)*i[2])/o>a*1e-6))return null;let c=t/2,l=a*1e-7;for(let n=0;n<t;n++){let r=e=>(n+e)%t,i=e[r(0)],o=e[r(t-1)],s=o.x-i.x,u=o.y-i.y,d=o.z-i.z;if(Math.hypot(s,u,d)<=l)continue;let f=!0;for(let n=1;n<c;n++){let i=e[r(n)],o=e[r(t-1-n)],c=e[r(n-1)],p=i.x-c.x,m=i.y-c.y,h=i.z-c.z;if(Math.hypot(o.x-i.x-s,o.y-i.y-u,o.z-i.z-d)>l||Math.hypot(m*d-h*u,h*s-p*d,p*u-m*s)<=l*a){f=!1;break}}if(!f)continue;let p=[];for(let e=0;e<c-1;e++){let n=r(e),i=r(e+1),a=r(t-2-e),o=r(t-1-e);p.push([n,i,a],[n,a,o])}return p}return null}var $c=t((()=>{}));function el(e,t,n){let r=n.length-e-1;if(t>=n[r])return r-1;if(t<=n[e])return e;let i=e,a=r,o=Math.floor((i+a)/2);for(;t<n[o]||t>=n[o+1];)t<n[o]?a=o:i=o,o=Math.floor((i+a)/2);return o}function tl(e,t,n,r){let i=[],a=[],o=[];i[0]=1;for(let s=1;s<=n;++s){a[s]=t-r[e+1-s],o[s]=r[e+s]-t;let n=0;for(let e=0;e<s;++e){let t=o[e+1],r=a[s-e],c=i[e]/(t+r);i[e]=n+t*c,n=r*c}i[s]=n}return i}function nl(e,t,n,r){let i=el(e,r,t),a=tl(i,r,e,t),o=new Ut(0,0,0,0);for(let t=0;t<=e;++t){let r=n[i-e+t],s=a[t],c=r.w*s;o.x+=r.x*c,o.y+=r.y*c,o.z+=r.z*c,o.w+=r.w*s}return o}function rl(e,t,n,r,i){let a=[];for(let e=0;e<=n;++e)a[e]=0;let o=[];for(let e=0;e<=r;++e)o[e]=a.slice(0);let s=[];for(let e=0;e<=n;++e)s[e]=a.slice(0);s[0][0]=1;let c=a.slice(0),l=a.slice(0);for(let r=1;r<=n;++r){c[r]=t-i[e+1-r],l[r]=i[e+r]-t;let n=0;for(let e=0;e<r;++e){let t=l[e+1],i=c[r-e];s[r][e]=t+i;let a=s[e][r-1]/s[r][e];s[e][r]=n+t*a,n=i*a}s[r][r]=n}for(let e=0;e<=n;++e)o[0][e]=s[e][n];for(let e=0;e<=n;++e){let t=0,i=1,c=[];for(let e=0;e<=n;++e)c[e]=a.slice(0);c[0][0]=1;for(let a=1;a<=r;++a){let r=0,l=e-a,u=n-a;e>=a&&(c[i][0]=c[t][0]/s[u+1][l],r=c[i][0]*s[l][u]);let d=l>=-1?1:-l,f=e-1<=u?a-1:n-e;for(let e=d;e<=f;++e)c[i][e]=(c[t][e]-c[t][e-1])/s[u+1][l+e],r+=c[i][e]*s[l+e][u];e<=u&&(c[i][a]=-c[t][a-1]/s[u+1][e],r+=c[i][a]*s[e][u]),o[a][e]=r;let p=t;t=i,i=p}}let u=n;for(let e=1;e<=r;++e){for(let t=0;t<=n;++t)o[e][t]*=u;u*=n-e}return o}function il(e,t,n,r,i){let a=i<e?i:e,o=[],s=el(e,r,t),c=rl(s,r,e,a,t),l=[];for(let e=0;e<n.length;++e){let t=n[e].clone(),r=t.w;t.x*=r,t.y*=r,t.z*=r,l[e]=t}for(let t=0;t<=a;++t){let n=l[s-e].clone().multiplyScalar(c[t][0]);for(let r=1;r<=e;++r)n.add(l[s-e+r].clone().multiplyScalar(c[t][r]));o[t]=n}for(let e=a+1;e<=i+1;++e)o[e]=new Ut(0,0,0);return o}function al(e,t){let n=1;for(let t=2;t<=e;++t)n*=t;let r=1;for(let e=2;e<=t;++e)r*=e;for(let n=2;n<=e-t;++n)r*=n;return n/r}function ol(e){let t=e.length,n=[],r=[];for(let i=0;i<t;++i){let t=e[i];n[i]=new W(t.x,t.y,t.z),r[i]=t.w}let i=[];for(let e=0;e<t;++e){let t=n[e].clone();for(let n=1;n<=e;++n)t.sub(i[e-n].clone().multiplyScalar(al(e,n)*r[n]));i[e]=t.divideScalar(r[0])}return i}function sl(e,t,n,r,i){return ol(il(e,t,n,r,i))}var cl=t((()=>{lo()})),ll,ul=t((()=>{lo(),cl(),ll=class extends Ui{constructor(e,t,n,r,i){super();let a=t?t.length-1:0,o=n?n.length:0;this.degree=e,this.knots=t,this.controlPoints=[],this.startKnot=r||0,this.endKnot=i||a;for(let e=0;e<o;++e){let t=n[e];this.controlPoints[e]=new Ut(t.x,t.y,t.z,t.w)}}getPoint(e,t=new W){let n=t,r=this.knots[this.startKnot]+e*(this.knots[this.endKnot]-this.knots[this.startKnot]),i=nl(this.degree,this.knots,this.controlPoints,r);return i.w!==1&&i.divideScalar(i.w),n.set(i.x,i.y,i.z)}getTangent(e,t=new W){let n=t,r=this.knots[0]+e*(this.knots[this.knots.length-1]-this.knots[0]),i=sl(this.degree,this.knots,this.controlPoints,r,1);return n.copy(i[1]).normalize(),n}toJSON(){let e=super.toJSON();return e.degree=this.degree,e.knots=[...this.knots],e.controlPoints=this.controlPoints.map(e=>e.toArray()),e.startKnot=this.startKnot,e.endKnot=this.endKnot,e}fromJSON(e){return super.fromJSON(e),this.degree=e.degree,this.knots=[...e.knots],this.controlPoints=e.controlPoints.map(e=>new Ut(e[0],e[1],e[2],e[3])),this.startKnot=e.startKnot,this.endKnot=e.endKnot,this}}})),dl=r({FBXLoader:()=>Tl});function fl(e){return e.byteLength>=21&&bl(e,0,21)===`Kaydara FBX Binary  \0`}function pl(e){let t=[`K`,`a`,`y`,`d`,`a`,`r`,`a`,`\\`,`F`,`B`,`X`,`\\`,`B`,`i`,`n`,`a`,`r`,`y`,`\\`,`\\`],n=0;function r(t){let r=e[t-1];return e=e.slice(n+t),n++,r}for(let e=0;e<t.length;++e)if(r(1)===t[e])return!1;return!0}function ml(e){let t=e.match(/FBXVersion: (\d+)/);if(t)return parseInt(t[1]);throw Error(`THREE.FBXLoader: Cannot find the version number for the file given.`)}function hl(e){return e/46186158e3}function gl(e,t,n,r){let i;switch(r.mappingType){case`ByPolygonVertex`:i=e;break;case`ByPolygon`:i=t;break;case`ByVertice`:i=n;break;case`AllSame`:i=r.indices[0];break;default:console.warn(`THREE.FBXLoader: unknown attribute mapping type `+r.mappingType)}r.referenceType===`IndexToDirect`&&(i=r.indices[i]);let a=i*r.dataSize,o=a+r.dataSize;return Sl(Nl,r.buffer,a,o)}function _l(e){let t=new K,n=new K,r=new K,i=new K,a=new K,o=new K,s=new K,c=new K,l=new K,u=new K,d=new K,f=new K,p=e.inheritType?e.inheritType:0;e.translation&&t.setPosition(Fl.fromArray(e.translation));let m=vl(0);if(e.preRotation){let t=e.preRotation.map(Ot.degToRad);t.push(m),n.makeRotationFromEuler(Pl.fromArray(t))}if(e.rotation){let t=e.rotation.map(Ot.degToRad);t.push(e.eulerOrder||m),r.makeRotationFromEuler(Pl.fromArray(t))}if(e.postRotation){let t=e.postRotation.map(Ot.degToRad);t.push(m),i.makeRotationFromEuler(Pl.fromArray(t)),i.invert()}e.scale&&a.scale(Fl.fromArray(e.scale)),e.scalingOffset&&s.setPosition(Fl.fromArray(e.scalingOffset)),e.scalingPivot&&o.setPosition(Fl.fromArray(e.scalingPivot)),e.rotationOffset&&c.setPosition(Fl.fromArray(e.rotationOffset)),e.rotationPivot&&l.setPosition(Fl.fromArray(e.rotationPivot)),e.parentMatrixWorld&&(d.copy(e.parentMatrix),u.copy(e.parentMatrixWorld));let h=n.clone().multiply(r).multiply(i),g=new K;g.extractRotation(u);let _=new K;_.copyPosition(u);let v=_.clone().invert().multiply(u),y=g.clone().invert().multiply(v),b=a,x=new K;if(p===0)x.copy(g).multiply(h).multiply(y).multiply(b);else if(p===1)x.copy(g).multiply(y).multiply(h).multiply(b);else{let e=new K().scale(new W().setFromMatrixScale(d)).clone().invert(),t=y.clone().multiply(e);x.copy(g).multiply(h).multiply(t).multiply(b)}let S=l.clone().invert(),C=o.clone().invert(),w=t.clone().multiply(c).multiply(l).multiply(n).multiply(r).multiply(i).multiply(S).multiply(s).multiply(o).multiply(a).multiply(C),T=new K().copyPosition(w),E=u.clone().multiply(T);return f.copyPosition(E),w=f.clone().multiply(x),w.premultiply(u.invert()),w}function vl(e){e||=0;let t=[`ZYX`,`YZX`,`XZY`,`ZXY`,`YXZ`,`XYZ`];return e===6?(console.warn(`THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect.`),t[0]):t[e]}function yl(e){return e.split(`,`).map(function(e){return parseFloat(e)})}function bl(e,t,n){return t===void 0&&(t=0),n===void 0&&(n=e.byteLength),new TextDecoder().decode(new Uint8Array(e,t,n))}function xl(e,t){for(let n=0,r=e.length,i=t.length;n<i;n++,r++)e[r]=t[n]}function Sl(e,t,n,r){for(let i=n,a=0;i<r;i++,a++)e[a]=t[i];return e}var Q,Cl,wl,Tl,El,Dl,Ol,kl,Al,jl,Ml,Nl,Pl,Fl,Il=t((()=>{$c(),lo(),Ds(),ul(),Tl=class extends ma{constructor(e){super(e)}load(e,t,n,r){let i=this,a=i.path===``?Wa.extractUrlBase(e):i.path,o=new _a(this.manager);o.setPath(i.path),o.setResponseType(`arraybuffer`),o.setRequestHeader(i.requestHeader),o.setWithCredentials(i.withCredentials),o.load(e,function(n){try{t(i.parse(n,a))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e,t){if(fl(e))Q=new Al().parse(e);else{let t=bl(e);if(!pl(t))throw Error(`THREE.FBXLoader: Unknown format.`);if(ml(t)<7e3)throw Error(`THREE.FBXLoader: FBX version not supported, FileVersion: `+ml(t));Q=new kl().parse(t)}return new El(new xa(this.manager).setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin),this.manager).parse(Q)}},El=class{constructor(e,t){this.textureLoader=e,this.manager=t}parse(){Cl=this.parseConnections();let e=this.parseImages(),t=this.parseTextures(e),n=this.parseMaterials(t),r=this.parseDeformers(),i=new Dl().parse(r);return this.parseScene(r,i,n),wl}parseConnections(){let e=new Map;return`Connections`in Q&&Q.Connections.connections.forEach(function(t){let n=t[0],r=t[1],i=t[2];e.has(n)||e.set(n,{parents:[],children:[]});let a={ID:r,relationship:i};e.get(n).parents.push(a),e.has(r)||e.set(r,{parents:[],children:[]});let o={ID:n,relationship:i};e.get(r).children.push(o)}),e}parseImages(){let e={},t={};if(`Video`in Q.Objects){let n=Q.Objects.Video;for(let r in n){let i=n[r],a=parseInt(r);if(e[a]=i.RelativeFilename||i.Filename,`Content`in i){let e=i.Content instanceof ArrayBuffer&&i.Content.byteLength>0,a=typeof i.Content==`string`&&i.Content!==``;if(e||a){let e=this.parseImage(n[r]);t[i.RelativeFilename||i.Filename]=e}}}}for(let n in e){let r=e[n];t[r]===void 0?e[n]=e[n].split(`\\`).pop():e[n]=t[r]}return e}parseImage(e){let t=e.Content,n=e.RelativeFilename||e.Filename,r=n.slice(n.lastIndexOf(`.`)+1).toLowerCase(),i;switch(r){case`bmp`:i=`image/bmp`;break;case`jpg`:case`jpeg`:i=`image/jpeg`;break;case`png`:i=`image/png`;break;case`tif`:i=`image/tiff`;break;case`tga`:this.manager.getHandler(`.tga`)===null&&console.warn(`FBXLoader: TGA loader not found, skipping `,n),i=`image/tga`;break;case`webp`:i=`image/webp`;break;default:console.warn(`FBXLoader: Image type "`+r+`" is not supported.`);return}if(typeof t==`string`)return`data:`+i+`;base64,`+t;{let e=new Uint8Array(t);return globalThis.URL.createObjectURL(new Blob([e],{type:i}))}}parseTextures(e){let t=new Map;if(`Texture`in Q.Objects){let n=Q.Objects.Texture;for(let r in n){let i=this.parseTexture(n[r],e);t.set(parseInt(r),i)}}return t}parseTexture(e,t){let n=this.loadTexture(e,t);n.ID=e.id,n.name=e.attrName;let r=e.WrapModeU,i=e.WrapModeV,a=r===void 0?0:r.value,o=i===void 0?0:i.value;if(n.wrapS=a===0?Je:Ye,n.wrapT=o===0?Je:Ye,`Scaling`in e){let t=e.Scaling.value;n.repeat.x=t[0],n.repeat.y=t[1]}if(`Translation`in e){let t=e.Translation.value;n.offset.x=t[0],n.offset.y=t[1]}return n}loadTexture(e,t){let n=e.FileName.split(`.`).pop().toLowerCase(),r=this.manager.getHandler(`.${n}`);r===null&&(r=this.textureLoader);let i=r.path;i||r.setPath(this.textureLoader.path);let a=Cl.get(e.id).children,o;if(a!==void 0&&a.length>0&&t[a[0].ID]!==void 0&&(o=t[a[0].ID],(o.indexOf(`blob:`)===0||o.indexOf(`data:`)===0)&&r.setPath(void 0)),o===void 0)return console.warn(`FBXLoader: Undefined filename, creating placeholder texture.`),new Ht;let s=r.load(o);return r.setPath(i),s}parseMaterials(e){let t=new Map;if(`Material`in Q.Objects){let n=Q.Objects.Material;for(let r in n){let i=this.parseMaterial(n[r],e);i!==null&&t.set(parseInt(r),i)}}return t}parseMaterial(e,t){let n=e.id,r=e.attrName,i=e.ShadingModel;if(typeof i==`object`&&(i=i.value),!Cl.has(n))return null;let a=this.parseParameters(e,t,n),o;switch(i.toLowerCase()){case`phong`:o=new Yi;break;case`lambert`:o=new Xi;break;default:console.warn(`THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.`,i),o=new Yi;break}return o.setValues(a),o.name=r,o}parseParameters(e,t,n){let r={};e.BumpFactor&&(r.bumpScale=e.BumpFactor.value),e.Diffuse?r.color=Ft.colorSpaceToWorking(new q().fromArray(e.Diffuse.value),H):e.DiffuseColor&&(e.DiffuseColor.type===`Color`||e.DiffuseColor.type===`ColorRGB`)&&(r.color=Ft.colorSpaceToWorking(new q().fromArray(e.DiffuseColor.value),H)),e.DisplacementFactor&&(r.displacementScale=e.DisplacementFactor.value),e.Emissive?r.emissive=Ft.colorSpaceToWorking(new q().fromArray(e.Emissive.value),H):e.EmissiveColor&&(e.EmissiveColor.type===`Color`||e.EmissiveColor.type===`ColorRGB`)&&(r.emissive=Ft.colorSpaceToWorking(new q().fromArray(e.EmissiveColor.value),H)),e.EmissiveFactor&&(r.emissiveIntensity=parseFloat(e.EmissiveFactor.value)),r.opacity=1-(e.TransparencyFactor?parseFloat(e.TransparencyFactor.value):0),(r.opacity===1||r.opacity===0)&&(r.opacity=e.Opacity?parseFloat(e.Opacity.value):null,r.opacity===null&&(r.opacity=1)),r.opacity<1&&(r.transparent=!0),e.ReflectionFactor&&(r.reflectivity=e.ReflectionFactor.value),e.Shininess&&(r.shininess=e.Shininess.value),e.Specular?r.specular=Ft.colorSpaceToWorking(new q().fromArray(e.Specular.value),H):e.SpecularColor&&e.SpecularColor.type===`Color`&&(r.specular=Ft.colorSpaceToWorking(new q().fromArray(e.SpecularColor.value),H));let i=this;return Cl.get(n).children.forEach(function(e){let n=e.relationship;switch(n){case`Bump`:r.bumpMap=i.getTexture(t,e.ID);break;case`Maya|TEX_ao_map`:r.aoMap=i.getTexture(t,e.ID);break;case`DiffuseColor`:case`Maya|TEX_color_map`:r.map=i.getTexture(t,e.ID),r.map!==void 0&&(r.map.colorSpace=H);break;case`DisplacementColor`:r.displacementMap=i.getTexture(t,e.ID);break;case`EmissiveColor`:r.emissiveMap=i.getTexture(t,e.ID),r.emissiveMap!==void 0&&(r.emissiveMap.colorSpace=H);break;case`NormalMap`:case`Maya|TEX_normal_map`:r.normalMap=i.getTexture(t,e.ID);break;case`ReflectionColor`:r.envMap=i.getTexture(t,e.ID),r.envMap!==void 0&&(r.envMap.mapping=303,r.envMap.colorSpace=H);break;case`SpecularColor`:r.specularMap=i.getTexture(t,e.ID),r.specularMap!==void 0&&(r.specularMap.colorSpace=H);break;case`TransparentColor`:case`TransparencyFactor`:r.alphaMap=i.getTexture(t,e.ID),r.transparent=!0;break;default:console.warn(`THREE.FBXLoader: %s map is not supported in three.js, skipping texture.`,n);break}}),r}getTexture(e,t){return`LayeredTexture`in Q.Objects&&t in Q.Objects.LayeredTexture&&(console.warn(`THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer.`),t=Cl.get(t).children[0].ID),e.get(t)}parseDeformers(){let e={},t={};if(`Deformer`in Q.Objects){let n=Q.Objects.Deformer;for(let r in n){let i=n[r],a=Cl.get(parseInt(r));if(i.attrType===`Skin`){let t=this.parseSkeleton(a,n);t.ID=r,a.parents.length>1&&console.warn(`THREE.FBXLoader: skeleton attached to more than one geometry is not supported.`),t.geometryID=a.parents[0].ID,e[r]=t}else if(i.attrType===`BlendShape`){let e={id:r};e.rawTargets=this.parseMorphTargets(a,n),e.id=r,a.parents.length>1&&console.warn(`THREE.FBXLoader: morph target attached to more than one geometry is not supported.`),t[r]=e}}}return{skeletons:e,morphTargets:t}}parseSkeleton(e,t){let n=[];return e.children.forEach(function(e){let r=t[e.ID];if(r.attrType!==`Cluster`)return;let i={ID:e.ID,indices:[],weights:[],transformLink:new K().fromArray(r.TransformLink.a)};`Indexes`in r&&(i.indices=r.Indexes.a,i.weights=r.Weights.a),n.push(i)}),{rawBones:n,bones:[]}}parseMorphTargets(e,t){let n=[];for(let r=0;r<e.children.length;r++){let i=e.children[r],a=t[i.ID],o={name:a.attrName,initialWeight:a.DeformPercent,id:a.id,fullWeights:a.FullWeights.a};if(a.attrType!==`BlendShapeChannel`)return;o.geoID=Cl.get(parseInt(i.ID)).children.filter(function(e){return e.relationship===void 0})[0].ID,n.push(o)}return n}parseScene(e,t,n){wl=new vn;let r=this.parseModels(e.skeletons,t,n),i=Q.Objects.Model,a=this;r.forEach(function(e){let t=i[e.ID];a.setLookAtProperties(e,t),Cl.get(e.ID).parents.forEach(function(t){let n=r.get(t.ID);n!==void 0&&n.add(e)}),e.parent===null&&wl.add(e)}),this.addGlobalSceneSettings(),wl.traverse(function(e){if(e.userData.transformData){e.parent&&(e.userData.transformData.parentMatrix=e.parent.matrix,e.userData.transformData.parentMatrixWorld=e.parent.matrixWorld);let t=_l(e.userData.transformData);e.applyMatrix4(t),e.updateWorldMatrix()}});let o=this.parsePoseNodes(),s=new Set;for(let t in e.skeletons)e.skeletons[t].rawBones.forEach(function(n,r){let i=e.skeletons[t].bones[r];i&&s.add(i.ID)});let c=new K;wl.traverse(function(e){if(e.isBone&&e.ID!==void 0&&!s.has(e.ID)){let t=o[e.ID];t!==void 0&&(e.parent?(c.copy(e.parent.matrixWorld).invert(),c.multiply(t)):c.copy(t),c.decompose(e.position,e.quaternion,e.scale),e.updateMatrix(),e.matrixWorld.copy(t))}}),this.bindSkeleton(e.skeletons,t,r);let l=new Ol().parse();wl.children.length===1&&wl.children[0].isGroup&&(wl.children[0].animations=l,wl=wl.children[0]),wl.animations=l,`GlobalSettings`in Q&&`UpAxis`in Q.GlobalSettings&&Q.GlobalSettings.UpAxis.value===2&&(console.warn(`THREE.FBXLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted.`),wl.rotation.set(-Math.PI/2,0,0))}parseModels(e,t,n){let r=new Map,i=Q.Objects.Model;for(let a in i){let o=parseInt(a),s=i[a],c=Cl.get(o),l=this.buildSkeleton(c,e,o,s.attrName);if(!l){switch(s.attrType){case`Camera`:l=this.createCamera(c);break;case`Light`:l=this.createLight(c);break;case`Mesh`:l=this.createMesh(c,t,n);break;case`NurbsCurve`:l=this.createCurve(c,t);break;case`LimbNode`:case`Root`:l=new Qr;break;default:l=new vn;break}l.name=s.attrName?io.sanitizeNodeName(s.attrName):``,l.userData.originalName=s.attrName,l.ID=o}this.getTransformData(l,s),r.set(o,l)}return r}buildSkeleton(e,t,n,r){let i=null;return e.parents.forEach(function(e){for(let a in t){let o=t[a];o.rawBones.forEach(function(t,a){if(t.ID===e.ID){let e=i;i=new Qr,i.matrixWorld.copy(t.transformLink),i.name=r?io.sanitizeNodeName(r):``,i.userData.originalName=r,i.ID=n,o.bones[a]=i,e!==null&&i.add(e)}})}}),i}createCamera(e){let t,n;if(e.children.forEach(function(e){let t=Q.Objects.NodeAttribute[e.ID];t!==void 0&&(n=t)}),n===void 0)t=new _n;else{let e=0;n.CameraProjectionType!==void 0&&n.CameraProjectionType.value===1&&(e=1);let r=1;n.NearPlane!==void 0&&(r=n.NearPlane.value/1e3);let i=1e3;n.FarPlane!==void 0&&(i=n.FarPlane.value/1e3);let a=globalThis.innerWidth||1,o=globalThis.innerHeight||1;n.AspectWidth!==void 0&&n.AspectHeight!==void 0&&(a=n.AspectWidth.value,o=n.AspectHeight.value);let s=a/o,c=45;n.FieldOfView!==void 0&&(c=n.FieldOfView.value);let l=n.FocalLength?n.FocalLength.value:null;switch(e){case 0:t=new Pa(c,s,r,i),l!==null&&t.setFocalLength(l);break;case 1:console.warn(`THREE.FBXLoader: Orthographic cameras not supported yet.`),t=new _n;break;default:console.warn(`THREE.FBXLoader: Unknown camera type `+e+`.`),t=new _n;break}}return t}createLight(e){let t,n;if(e.children.forEach(function(e){let t=Q.Objects.NodeAttribute[e.ID];t!==void 0&&(n=t)}),n===void 0)t=new _n;else{let e;e=n.LightType===void 0?0:n.LightType.value;let r=16777215;n.Color!==void 0&&(r=Ft.colorSpaceToWorking(new q().fromArray(n.Color.value),H));let i=n.Intensity===void 0?1:n.Intensity.value/100;n.CastLightOnObject!==void 0&&n.CastLightOnObject.value===0&&(i=0);let a=0;switch(n.FarAttenuationEnd!==void 0&&(a=n.EnableFarAttenuation!==void 0&&n.EnableFarAttenuation.value===0?0:n.FarAttenuationEnd.value),e){case 0:t=new Ra(r,i,a,1);break;case 1:t=new Va(r,i);break;case 2:let e=Math.PI/3,o=0;n.OuterAngle===void 0?n.InnerAngle!==void 0&&(e=Ot.degToRad(n.InnerAngle.value)):(e=Ot.degToRad(n.OuterAngle.value),n.InnerAngle!==void 0&&(o=1-n.InnerAngle.value/n.OuterAngle.value,o=Math.max(0,o))),t=new Ia(r,i,a,e,o,1);break;default:console.warn(`THREE.FBXLoader: Unknown light type `+n.LightType.value+`, defaulting to a PointLight.`),t=new Ra(r,i);break}n.CastShadows!==void 0&&n.CastShadows.value===1&&(t.castShadow=!0)}return t}createMesh(e,t,n){let r,i=null,a=null,o=[];if(e.children.forEach(function(e){t.has(e.ID)&&(i=t.get(e.ID)),n.has(e.ID)&&o.push(n.get(e.ID))}),o.length>1?a=o:o.length>0?a=o[0]:(a=new Yi({name:ma.DEFAULT_MATERIAL_NAME,color:13421772}),o.push(a)),`color`in i.attributes&&o.forEach(function(e){e.vertexColors=!0}),i.groups.length>0){let e=!1;for(let t=0,n=i.groups.length;t<n;t++){let n=i.groups[t];(n.materialIndex<0||n.materialIndex>=o.length)&&(n.materialIndex=o.length,e=!0)}if(e){let e=new Yi;o.push(e)}}return i.FBX_Deformer?(r=new Zr(i,a),r.normalizeSkinWeights()):r=new Vr(i,a),r}createCurve(e,t){return new Oi(e.children.reduce(function(e,n){return t.has(n.ID)&&(e=t.get(n.ID)),e},null),new bi({name:ma.DEFAULT_MATERIAL_NAME,color:3342591,linewidth:1}))}getTransformData(e,t){let n={};`InheritType`in t&&(n.inheritType=parseInt(t.InheritType.value)),`RotationOrder`in t?n.eulerOrder=vl(t.RotationOrder.value):n.eulerOrder=vl(0),`Lcl_Translation`in t&&(n.translation=t.Lcl_Translation.value),`PreRotation`in t&&(n.preRotation=t.PreRotation.value),`Lcl_Rotation`in t&&(n.rotation=t.Lcl_Rotation.value),`PostRotation`in t&&(n.postRotation=t.PostRotation.value),`Lcl_Scaling`in t&&(n.scale=t.Lcl_Scaling.value),`ScalingOffset`in t&&(n.scalingOffset=t.ScalingOffset.value),`ScalingPivot`in t&&(n.scalingPivot=t.ScalingPivot.value),`RotationOffset`in t&&(n.rotationOffset=t.RotationOffset.value),`RotationPivot`in t&&(n.rotationPivot=t.RotationPivot.value),e.userData.transformData=n}setLookAtProperties(e,t){`LookAtProperty`in t&&Cl.get(e.ID).children.forEach(function(t){if(t.relationship===`LookAtProperty`){let n=Q.Objects.Model[t.ID];if(`Lcl_Translation`in n){let t=n.Lcl_Translation.value;e.target===void 0?e.lookAt(new W().fromArray(t)):(e.target.position.fromArray(t),wl.add(e.target))}}})}bindSkeleton(e,t,n){for(let r in e){let i=e[r],a=[];for(let e=0,t=i.bones.length;e<t;e++){let t=new K;i.bones[e]&&i.rawBones[e]&&t.copy(i.rawBones[e].transformLink).invert(),a.push(t)}Cl.get(parseInt(i.ID)).parents.forEach(function(e){if(t.has(e.ID)){let t=e.ID;Cl.get(t).parents.forEach(function(e){if(n.has(e.ID)){let t=n.get(e.ID);t.updateMatrixWorld(!0),t.bind(new ni(i.bones,a),t.matrixWorld)}})}})}}parsePoseNodes(){let e={};if(`Pose`in Q.Objects){let t=Q.Objects.Pose;for(let n in t)if(t[n].attrType===`BindPose`&&t[n].NbPoseNodes>0){let r=t[n].PoseNode;Array.isArray(r)?r.forEach(function(t){e[t.Node]=new K().fromArray(t.Matrix.a)}):e[r.Node]=new K().fromArray(r.Matrix.a)}}return e}addGlobalSceneSettings(){if(`GlobalSettings`in Q){if(`AmbientColor`in Q.GlobalSettings){let e=Q.GlobalSettings.AmbientColor.value,t=e[0],n=e[1],r=e[2];if(t!==0||n!==0||r!==0){let e=new q().setRGB(t,n,r,H);wl.add(new Ha(e,1))}}`UnitScaleFactor`in Q.GlobalSettings&&(wl.userData.unitScaleFactor=Q.GlobalSettings.UnitScaleFactor.value)}}},Dl=class{constructor(){this.negativeMaterialIndices=!1}parse(e){let t=new Map;if(`Geometry`in Q.Objects){let n=Q.Objects.Geometry;for(let r in n){let i=Cl.get(parseInt(r)),a=this.parseGeometry(i,n[r],e);t.set(parseInt(r),a)}}return this.negativeMaterialIndices===!0&&console.warn(`THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected.`),t}parseGeometry(e,t,n){switch(t.attrType){case`Mesh`:return this.parseMeshGeometry(e,t,n);case`NurbsCurve`:return this.parseNurbsGeometry(t)}}parseMeshGeometry(e,t,n){let r=n.skeletons,i=[],a=e.parents.map(function(e){return Q.Objects.Model[e.ID]});if(a.length===0)return;let o=e.children.reduce(function(e,t){return r[t.ID]!==void 0&&(e=r[t.ID]),e},null);e.children.forEach(function(e){n.morphTargets[e.ID]!==void 0&&i.push(n.morphTargets[e.ID])});let s=a[0],c={};`RotationOrder`in s&&(c.eulerOrder=vl(s.RotationOrder.value)),`InheritType`in s&&(c.inheritType=parseInt(s.InheritType.value)),`GeometricTranslation`in s&&(c.translation=s.GeometricTranslation.value),`GeometricRotation`in s&&(c.rotation=s.GeometricRotation.value),`GeometricScaling`in s&&(c.scale=s.GeometricScaling.value);let l=_l(c);return this.genGeometry(t,o,i,l)}genGeometry(e,t,n,r){let i=new hr;e.attrName&&(i.name=e.attrName);let a=this.parseGeoNode(e,t),o=this.genBuffers(a),s=new J(o.vertex,3);if(s.applyMatrix4(r),i.setAttribute(`position`,s),o.colors.length>0&&i.setAttribute(`color`,new J(o.colors,3)),t&&(i.setAttribute(`skinIndex`,new nr(o.weightsIndices,4)),i.setAttribute(`skinWeight`,new J(o.vertexWeights,4)),i.FBX_Deformer=t),o.normal.length>0){let e=new G().getNormalMatrix(r),t=new J(o.normal,3);t.applyNormalMatrix(e),i.setAttribute(`normal`,t)}if(o.uvs.forEach(function(e,t){let n=t===0?`uv`:`uv${t}`;i.setAttribute(n,new J(o.uvs[t],2))}),a.material&&a.material.mappingType!==`AllSame`){let e=o.materialIndex[0],t=0;if(o.materialIndex.forEach(function(n,r){n!==e&&(i.addGroup(t,r-t,e),e=n,t=r)}),i.groups.length>0){let t=i.groups[i.groups.length-1],n=t.start+t.count;n!==o.materialIndex.length&&i.addGroup(n,o.materialIndex.length-n,e)}i.groups.length===0&&i.addGroup(0,o.materialIndex.length,o.materialIndex[0])}return this.addMorphTargets(i,e,n,r),i}parseGeoNode(e,t){let n={};if(n.vertexPositions=e.Vertices===void 0?[]:e.Vertices.a,n.vertexIndices=e.PolygonVertexIndex===void 0?[]:e.PolygonVertexIndex.a,e.LayerElementColor&&e.LayerElementColor[0].Colors&&(n.color=this.parseVertexColors(e.LayerElementColor[0])),e.LayerElementMaterial&&(n.material=this.parseMaterialIndices(e.LayerElementMaterial[0])),e.LayerElementNormal&&(n.normal=this.parseNormals(e.LayerElementNormal[0])),e.LayerElementUV){n.uv=[];let t=0;for(;e.LayerElementUV[t];)e.LayerElementUV[t].UV&&n.uv.push(this.parseUVs(e.LayerElementUV[t])),t++}return n.weightTable={},t!==null&&(n.skeleton=t,t.rawBones.forEach(function(e,t){e.indices.forEach(function(r,i){n.weightTable[r]===void 0&&(n.weightTable[r]=[]),n.weightTable[r].push({id:t,weight:e.weights[i]})})})),n}genBuffers(e){let t={vertex:[],normal:[],colors:[],uvs:[],materialIndex:[],vertexWeights:[],weightsIndices:[]},n=0,r=0,i=!1,a=[],o=[],s=[],c=[],l=[],u=[],d=this;return e.vertexIndices.forEach(function(f,p){let m,h=!1;f<0&&(f^=-1,h=!0);let g=[],_=[];if(a.push(f*3,f*3+1,f*3+2),e.color){let t=gl(p,n,f,e.color);s.push(t[0],t[1],t[2])}if(e.skeleton){if(e.weightTable[f]!==void 0&&e.weightTable[f].forEach(function(e){_.push(e.weight),g.push(e.id)}),_.length>4){i||=(console.warn(`THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights.`),!0);let e=[0,0,0,0],t=[0,0,0,0];_.forEach(function(n,r){let i=n,a=g[r];t.forEach(function(t,n,r){if(i>t){r[n]=i,i=t;let o=e[n];e[n]=a,a=o}})}),g=e,_=t}for(;_.length<4;)_.push(0),g.push(0);for(let e=0;e<4;++e)l.push(_[e]),u.push(g[e])}if(e.normal){let t=gl(p,n,f,e.normal);o.push(t[0],t[1],t[2])}e.material&&e.material.mappingType!==`AllSame`&&(m=gl(p,n,f,e.material)[0],m<0&&(d.negativeMaterialIndices=!0,m=0)),e.uv&&e.uv.forEach(function(e,t){let r=gl(p,n,f,e);c[t]===void 0&&(c[t]=[]),c[t].push(r[0]),c[t].push(r[1])}),r++,h&&(d.genFace(t,e,a,m,o,s,c,l,u,r),n++,r=0,a=[],o=[],s=[],c=[],l=[],u=[])}),t}getNormalNewell(e){let t=new W(0,0,0);for(let n=0;n<e.length;n++){let r=e[n],i=e[(n+1)%e.length];t.x+=(r.y-i.y)*(r.z+i.z),t.y+=(r.z-i.z)*(r.x+i.x),t.z+=(r.x-i.x)*(r.y+i.y)}return t.normalize(),t}getNormalTangentAndBitangent(e){let t=this.getNormalNewell(e),n=(Math.abs(t.z)>.5?new W(0,1,0):new W(0,0,1)).cross(t).normalize();return{normal:t,tangent:n,bitangent:t.clone().cross(n).normalize()}}flattenVertex(e,t,n){return new U(e.dot(t),e.dot(n))}genFace(e,t,n,r,i,a,o,s,c,l){let u;if(l>3){let e=[],r=t.baseVertexPositions||t.vertexPositions;for(let t=0;t<n.length;t+=3)e.push(new W(r[n[t]],r[n[t+1]],r[n[t+2]]));let{tangent:i,bitangent:a}=this.getNormalTangentAndBitangent(e),o=[];for(let t of e)o.push(this.flattenVertex(t,i,a));u=Qc(e)??Gi.triangulateShape(o,[])}else u=[[0,1,2]];for(let[l,d,f]of u)e.vertex.push(t.vertexPositions[n[l*3]]),e.vertex.push(t.vertexPositions[n[l*3+1]]),e.vertex.push(t.vertexPositions[n[l*3+2]]),e.vertex.push(t.vertexPositions[n[d*3]]),e.vertex.push(t.vertexPositions[n[d*3+1]]),e.vertex.push(t.vertexPositions[n[d*3+2]]),e.vertex.push(t.vertexPositions[n[f*3]]),e.vertex.push(t.vertexPositions[n[f*3+1]]),e.vertex.push(t.vertexPositions[n[f*3+2]]),t.skeleton&&(e.vertexWeights.push(s[l*4]),e.vertexWeights.push(s[l*4+1]),e.vertexWeights.push(s[l*4+2]),e.vertexWeights.push(s[l*4+3]),e.vertexWeights.push(s[d*4]),e.vertexWeights.push(s[d*4+1]),e.vertexWeights.push(s[d*4+2]),e.vertexWeights.push(s[d*4+3]),e.vertexWeights.push(s[f*4]),e.vertexWeights.push(s[f*4+1]),e.vertexWeights.push(s[f*4+2]),e.vertexWeights.push(s[f*4+3]),e.weightsIndices.push(c[l*4]),e.weightsIndices.push(c[l*4+1]),e.weightsIndices.push(c[l*4+2]),e.weightsIndices.push(c[l*4+3]),e.weightsIndices.push(c[d*4]),e.weightsIndices.push(c[d*4+1]),e.weightsIndices.push(c[d*4+2]),e.weightsIndices.push(c[d*4+3]),e.weightsIndices.push(c[f*4]),e.weightsIndices.push(c[f*4+1]),e.weightsIndices.push(c[f*4+2]),e.weightsIndices.push(c[f*4+3])),t.color&&(e.colors.push(a[l*3]),e.colors.push(a[l*3+1]),e.colors.push(a[l*3+2]),e.colors.push(a[d*3]),e.colors.push(a[d*3+1]),e.colors.push(a[d*3+2]),e.colors.push(a[f*3]),e.colors.push(a[f*3+1]),e.colors.push(a[f*3+2])),t.material&&t.material.mappingType!==`AllSame`&&(e.materialIndex.push(r),e.materialIndex.push(r),e.materialIndex.push(r)),t.normal&&(e.normal.push(i[l*3]),e.normal.push(i[l*3+1]),e.normal.push(i[l*3+2]),e.normal.push(i[d*3]),e.normal.push(i[d*3+1]),e.normal.push(i[d*3+2]),e.normal.push(i[f*3]),e.normal.push(i[f*3+1]),e.normal.push(i[f*3+2])),t.uv&&t.uv.forEach(function(t,n){e.uvs[n]===void 0&&(e.uvs[n]=[]),e.uvs[n].push(o[n][l*2]),e.uvs[n].push(o[n][l*2+1]),e.uvs[n].push(o[n][d*2]),e.uvs[n].push(o[n][d*2+1]),e.uvs[n].push(o[n][f*2]),e.uvs[n].push(o[n][f*2+1])})}addMorphTargets(e,t,n,r){if(n.length===0)return;e.morphTargetsRelative=!0,e.morphAttributes.position=[];let i=r.clone().setPosition(0,0,0),a=this;n.forEach(function(n){n.rawTargets.forEach(function(n){let r=Q.Objects.Geometry[n.geoID];r!==void 0&&a.genMorphGeometry(e,t,r,i,n.name)})})}genMorphGeometry(e,t,n,r,i){let a=t.Vertices===void 0?[]:t.Vertices.a,o=t.PolygonVertexIndex===void 0?[]:t.PolygonVertexIndex.a,s=n.Vertices===void 0?[]:n.Vertices.a,c=n.Indexes===void 0?[]:n.Indexes.a,l=e.attributes.position.count*3,u=new Float32Array(l);for(let e=0;e<c.length;e++){let t=c[e]*3;u[t]=s[e*3],u[t+1]=s[e*3+1],u[t+2]=s[e*3+2]}let d={vertexIndices:o,vertexPositions:u,baseVertexPositions:a},f=new J(this.genBuffers(d).vertex,3);f.name=i||n.attrName,f.applyMatrix4(r),e.morphAttributes.position.push(f)}parseNormals(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.Normals.a,i=[];return n===`IndexToDirect`&&(`NormalIndex`in e?i=e.NormalIndex.a:`NormalsIndex`in e&&(i=e.NormalsIndex.a)),{dataSize:3,buffer:r,indices:i,mappingType:t,referenceType:n}}parseUVs(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.UV.a,i=[];return n===`IndexToDirect`&&(i=e.UVIndex.a),{dataSize:2,buffer:r,indices:i,mappingType:t,referenceType:n}}parseVertexColors(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.Colors.a,i=[];n===`IndexToDirect`&&(i=e.ColorIndex.a);for(let e=0,t=new q;e<r.length;e+=4)t.fromArray(r,e),Ft.colorSpaceToWorking(t,H),t.toArray(r,e);return{dataSize:4,buffer:r,indices:i,mappingType:t,referenceType:n}}parseMaterialIndices(e){let t=e.MappingInformationType,n=e.ReferenceInformationType;if(t===`NoMappingInformation`)return{dataSize:1,buffer:[0],indices:[0],mappingType:`AllSame`,referenceType:n};let r=e.Materials.a,i=[];for(let e=0;e<r.length;++e)i.push(e);return{dataSize:1,buffer:r,indices:i,mappingType:t,referenceType:n}}parseNurbsGeometry(e){let t=parseInt(e.Order);if(isNaN(t))return console.error(`THREE.FBXLoader: Invalid Order %s given for geometry ID: %s`,e.Order,e.id),new hr;let n=t-1,r=e.KnotVector.a,i=[],a=e.Points.a;for(let e=0,t=a.length;e<t;e+=4)i.push(new Ut().fromArray(a,e));let o,s;if(e.Form===`Closed`)i.push(i[0]);else if(e.Form===`Periodic`){o=n,s=r.length-1-o;for(let e=0;e<n;++e)i.push(i[e])}let c=new ll(n,r,i,o,s).getPoints(i.length*12);return new hr().setFromPoints(c)}},Ol=class{parse(){let e=[],t=this.parseClips();if(t!==void 0)for(let n in t){let r=t[n],i=this.addClip(r);e.push(i)}return e}parseClips(){if(Q.Objects.AnimationCurve===void 0)return;let e=this.parseAnimationCurveNodes();this.parseAnimationCurves(e);let t=this.parseAnimationLayers(e);return this.parseAnimStacks(t)}parseAnimationCurveNodes(){let e=Q.Objects.AnimationCurveNode,t=new Map;for(let n in e){let r=e[n];if(r.attrName.match(/S|R|T|DeformPercent/)!==null){let e={id:r.id,attr:r.attrName,curves:{}};t.set(e.id,e)}}return t}parseAnimationCurves(e){let t=Q.Objects.AnimationCurve;for(let n in t){let r={id:t[n].id,times:t[n].KeyTime.a.map(hl),values:t[n].KeyValueFloat.a},i=Cl.get(r.id);if(i!==void 0){let t=i.parents[0].ID,n=i.parents[0].relationship;n.match(/X/)?e.get(t).curves.x=r:n.match(/Y/)?e.get(t).curves.y=r:n.match(/Z/)?e.get(t).curves.z=r:n.match(/DeformPercent/)&&e.has(t)&&(e.get(t).curves.morph=r)}}}parseAnimationLayers(e){let t=Q.Objects.AnimationLayer,n=new Map;for(let r in t){let t=[],i=Cl.get(parseInt(r));i!==void 0&&(i.children.forEach(function(n,r){if(e.has(n.ID)){let i=e.get(n.ID);if(i.curves.x!==void 0||i.curves.y!==void 0||i.curves.z!==void 0){if(t[r]===void 0){let e=Cl.get(n.ID).parents.filter(function(e){return e.relationship!==void 0});if(e.length===0)return;let i=e[0].ID;if(i!==void 0){let e=Q.Objects.Model[i.toString()];if(e===void 0){console.warn(`THREE.FBXLoader: Encountered a unused curve.`,n);return}let a={modelName:e.attrName?io.sanitizeNodeName(e.attrName):``,ID:e.id,initialPosition:[0,0,0],initialRotation:[0,0,0],initialScale:[1,1,1]};wl.traverse(function(t){t.ID===e.id&&(a.transform=t.matrix,t.userData.transformData&&(a.eulerOrder=t.userData.transformData.eulerOrder,t.userData.transformData.rotation&&(a.initialRotation=t.userData.transformData.rotation)))}),a.transform||=new K,`PreRotation`in e&&(a.preRotation=e.PreRotation.value),`PostRotation`in e&&(a.postRotation=e.PostRotation.value),t[r]=a}}t[r]&&(t[r][i.attr]=i)}else if(i.curves.morph!==void 0){if(t[r]===void 0){let e=Cl.get(n.ID).parents.filter(function(e){return e.relationship!==void 0});if(e.length===0)return;let i=e[0].ID,a=Cl.get(i).parents[0].ID,o=Cl.get(a).parents[0].ID,s=Cl.get(o).parents[0].ID,c=Q.Objects.Model[s];t[r]={modelName:c.attrName?io.sanitizeNodeName(c.attrName):``,morphName:Q.Objects.Deformer[i].attrName}}t[r][i.attr]=i}}}),n.set(parseInt(r),t))}return n}parseAnimStacks(e){let t=Q.Objects.AnimationStack,n={};for(let r in t){let i=Cl.get(parseInt(r)).children;i.length>1&&console.warn(`THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.`);let a=e.get(i[0].ID);n[r]={name:t[r].attrName,layer:a}}return n}addClip(e){let t=[],n=this;return e.layer.forEach(function(e){t=t.concat(n.generateTracks(e))}),new ua(e.name,-1,t)}generateTracks(e){let t=[],n=new W,r=new W;if(e.transform&&e.transform.decompose(n,new kt,r),n=n.toArray(),r=r.toArray(),e.T!==void 0&&Object.keys(e.T.curves).length>0){let r=this.generateVectorTrack(e.modelName,e.T.curves,n,`position`);r!==void 0&&t.push(r)}if(e.R!==void 0&&Object.keys(e.R.curves).length>0){let n=this.generateRotationTrack(e.modelName,e.R.curves,e.preRotation,e.postRotation,e.eulerOrder,e.initialRotation);n!==void 0&&t.push(n)}if(e.S!==void 0&&Object.keys(e.S.curves).length>0){let n=this.generateVectorTrack(e.modelName,e.S.curves,r,`scale`);n!==void 0&&t.push(n)}if(e.DeformPercent!==void 0){let n=this.generateMorphTrack(e);n!==void 0&&t.push(n)}return t}generateVectorTrack(e,t,n,r){let i=this.getTimesForAllAxes(t),a=this.getKeyframeTrackValues(i,t,n);return new la(e+`.`+r,i,a)}generateRotationTrack(e,t,n,r,i,a){let o,s;if(t.x!==void 0||t.y!==void 0||t.z!==void 0){let e=this.getTimesForAllAxes(t);if(e.length>0){let n=a||[0,0,0],r=this.synchronizeCurve(t.x,e,n[0]),c=this.synchronizeCurve(t.y,e,n[1]),l=this.synchronizeCurve(t.z,e,n[2]),u=this.interpolateRotations(r,c,l,i);o=u[0],s=u[1]}}let c=vl(0);n!==void 0&&(n=n.map(Ot.degToRad),n.push(c),n=new $t().fromArray(n),n=new kt().setFromEuler(n)),r!==void 0&&(r=r.map(Ot.degToRad),r.push(c),r=new $t().fromArray(r),r=new kt().setFromEuler(r).invert());let l=new kt,u=new $t,d=[];if(!(!s||!o)){for(let e=0;e<s.length;e+=3)u.set(s[e],s[e+1],s[e+2],i),l.setFromEuler(u),n!==void 0&&l.premultiply(n),r!==void 0&&l.multiply(r),e>2&&new kt().fromArray(d,(e-3)/3*4).dot(l)<0&&l.set(-l.x,-l.y,-l.z,-l.w),l.toArray(d,e/3*4);return new sa(e+`.quaternion`,o,d)}}generateMorphTrack(e){let t=e.DeformPercent.curves.morph,n=t.values.map(function(e){return e/100}),r=wl.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];return new aa(e.modelName+`.morphTargetInfluences[`+r+`]`,t.times,n)}getTimesForAllAxes(e){let t=[];if(e.x!==void 0&&(t=t.concat(e.x.times)),e.y!==void 0&&(t=t.concat(e.y.times)),e.z!==void 0&&(t=t.concat(e.z.times)),t=t.sort(function(e,t){return e-t}),t.length>1){let e=1,n=t[0];for(let r=1;r<t.length;r++){let i=t[r];i!==n&&(t[e]=i,n=i,e++)}t=t.slice(0,e)}return t}getKeyframeTrackValues(e,t,n){let r=n,i=[],a=-1,o=-1,s=-1;return e.forEach(function(e){if(t.x&&(a=t.x.times.indexOf(e)),t.y&&(o=t.y.times.indexOf(e)),t.z&&(s=t.z.times.indexOf(e)),a!==-1){let e=t.x.values[a];i.push(e),r[0]=e}else i.push(r[0]);if(o!==-1){let e=t.y.values[o];i.push(e),r[1]=e}else i.push(r[1]);if(s!==-1){let e=t.z.values[s];i.push(e),r[2]=e}else i.push(r[2])}),i}synchronizeCurve(e,t,n){if(e===void 0)return{times:t,values:t.map(()=>n)};if(e.times.length===t.length)return e;let r=[];for(let i=0;i<t.length;i++)r.push(this.sampleCurveValue(e,t[i],n));return{times:t,values:r}}sampleCurveValue(e,t,n){let r=e.times,i=e.values;if(t<=r[0])return i[0];if(t>=r[r.length-1])return i[i.length-1];for(let e=0;e<r.length-1;e++)if(t>=r[e]&&t<=r[e+1]){if(r[e]===t)return i[e];let n=(t-r[e])/(r[e+1]-r[e]);return i[e]*(1-n)+i[e+1]*n}return n}interpolateRotations(e,t,n,r){let i=[],a=[];i.push(e.times[0]),a.push(Ot.degToRad(e.values[0])),a.push(Ot.degToRad(t.values[0])),a.push(Ot.degToRad(n.values[0]));for(let o=1;o<e.values.length;o++){let s=[e.values[o-1],t.values[o-1],n.values[o-1]];if(isNaN(s[0])||isNaN(s[1])||isNaN(s[2]))continue;let c=s.map(Ot.degToRad),l=[e.values[o],t.values[o],n.values[o]];if(isNaN(l[0])||isNaN(l[1])||isNaN(l[2]))continue;let u=l.map(Ot.degToRad),d=[l[0]-s[0],l[1]-s[1],l[2]-s[2]],f=[Math.abs(d[0]),Math.abs(d[1]),Math.abs(d[2])];if(f[0]>=180||f[1]>=180||f[2]>=180){let t=Math.max(...f)/180,n=new $t(...c,r),s=new $t(...u,r),l=new kt().setFromEuler(n),d=new kt().setFromEuler(s);l.dot(d)<0&&d.set(-d.x,-d.y,-d.z,-d.w);let p=e.times[o-1],m=e.times[o]-p,h=new kt,g=new $t;for(let e=0;e<1;e+=1/t)h.copy(l.clone().slerp(d.clone(),e)),i.push(p+e*m),g.setFromQuaternion(h,r),a.push(g.x),a.push(g.y),a.push(g.z)}else i.push(e.times[o]),a.push(Ot.degToRad(e.values[o])),a.push(Ot.degToRad(t.values[o])),a.push(Ot.degToRad(n.values[o]))}return[i,a]}},kl=class{getPrevNode(){return this.nodeStack[this.currentIndent-2]}getCurrentNode(){return this.nodeStack[this.currentIndent-1]}getCurrentProp(){return this.currentProp}pushStack(e){this.nodeStack.push(e),this.currentIndent+=1}popStack(){this.nodeStack.pop(),--this.currentIndent}setCurrentProp(e,t){this.currentProp=e,this.currentPropName=t}parse(e){this.currentIndent=0,this.allNodes=new Ml,this.nodeStack=[],this.currentProp=[],this.currentPropName=``;let t=this,n=e.split(/[\r\n]+/);return n.forEach(function(e,r){let i=e.match(/^[\s\t]*;/),a=e.match(/^[\s\t]*$/);if(i||a)return;let o=e.match(`^\\t{`+t.currentIndent+`}(\\w+):(.*){`,``),s=e.match(`^\\t{`+t.currentIndent+`}(\\w+):[\\s\\t\\r\\n](.*)`),c=e.match(`^\\t{`+(t.currentIndent-1)+`}}`);o?t.parseNodeBegin(e,o):s?t.parseNodeProperty(e,s,n[++r]):c?t.popStack():e.match(/^[^\s\t}]/)&&t.parseNodePropertyContinued(e)}),this.allNodes}parseNodeBegin(e,t){let n=t[1].trim().replace(/^"/,``).replace(/"$/,``),r=t[2].split(`,`).map(function(e){return e.trim().replace(/^"/,``).replace(/"$/,``)}),i={name:n},a=this.parseNodeAttr(r),o=this.getCurrentNode();this.currentIndent===0?this.allNodes.add(n,i):n in o?(n===`PoseNode`?o.PoseNode.push(i):o[n].id!==void 0&&(o[n]={},o[n][o[n].id]=o[n]),a.id!==``&&(o[n][a.id]=i)):typeof a.id==`number`?(o[n]={},o[n][a.id]=i):n!==`Properties70`&&(n===`PoseNode`?o[n]=[i]:o[n]=i),typeof a.id==`number`&&(i.id=a.id),a.name!==``&&(i.attrName=a.name),a.type!==``&&(i.attrType=a.type),this.pushStack(i)}parseNodeAttr(e){let t=e[0];e[0]!==``&&(t=parseInt(e[0]),isNaN(t)&&(t=e[0]));let n=``,r=``;return e.length>1&&(n=e[1].replace(/^(\w+)::/,``),r=e[2]),{id:t,name:n,type:r}}parseNodeProperty(e,t,n){let r=t[1].replace(/^"/,``).replace(/"$/,``).trim(),i=t[2].replace(/^"/,``).replace(/"$/,``).trim();r===`Content`&&i===`,`&&(i=n.replace(/"/g,``).replace(/,$/,``).trim());let a=this.getCurrentNode();if(a.name===`Properties70`){this.parseNodeSpecialProperty(e,r,i);return}if(r===`C`){let e=i.split(`,`).slice(1),t=parseInt(e[0]),n=parseInt(e[1]),o=i.split(`,`).slice(3);o=o.map(function(e){return e.trim().replace(/^"/,``)}),r=`connections`,i=[t,n],xl(i,o),a[r]===void 0&&(a[r]=[])}r===`Node`&&(a.id=i),r in a&&Array.isArray(a[r])?a[r].push(i):r===`a`?a.a=i:a[r]=i,this.setCurrentProp(a,r),r===`a`&&i.slice(-1)!==`,`&&(a.a=yl(i))}parseNodePropertyContinued(e){let t=this.getCurrentNode();t.a+=e,e.slice(-1)!==`,`&&(t.a=yl(t.a))}parseNodeSpecialProperty(e,t,n){let r=n.split(`",`).map(function(e){return e.trim().replace(/^\"/,``).replace(/\s/,`_`)}),i=r[0],a=r[1],o=r[2],s=r[3],c=r[4];switch(a){case`int`:case`enum`:case`bool`:case`ULongLong`:case`double`:case`Number`:case`FieldOfView`:c=parseFloat(c);break;case`Color`:case`ColorRGB`:case`Vector3D`:case`Lcl_Translation`:case`Lcl_Rotation`:case`Lcl_Scaling`:c=yl(c);break}this.getPrevNode()[i]={type:a,type2:o,flag:s,value:c},this.setCurrentProp(this.getPrevNode(),i)}},Al=class{parse(e){let t=new jl(e);t.skip(23);let n=t.getUint32();if(n<6400)throw Error(`THREE.FBXLoader: FBX version not supported, FileVersion: `+n);let r=new Ml;for(;!this.endOfContent(t);){let e=this.parseNode(t,n);e!==null&&r.add(e.name,e)}return r}endOfContent(e){return e.size()%16==0?(e.getOffset()+160+16&-16)>=e.size():e.getOffset()+160+16>=e.size()}parseNode(e,t){let n={},r=t>=7500?e.getUint64():e.getUint32(),i=t>=7500?e.getUint64():e.getUint32();t>=7500?e.getUint64():e.getUint32();let a=e.getUint8(),o=e.getString(a);if(r===0)return null;let s=[];for(let t=0;t<i;t++)s.push(this.parseProperty(e));let c=s.length>0?s[0]:``,l=s.length>1?s[1]:``,u=s.length>2?s[2]:``;for(n.singleProperty=i===1&&e.getOffset()===r;r>e.getOffset();){let r=this.parseNode(e,t);r!==null&&this.parseSubNode(o,n,r)}return n.propertyList=s,typeof c==`number`&&(n.id=c),l!==``&&(n.attrName=l),u!==``&&(n.attrType=u),o!==``&&(n.name=o),n}parseSubNode(e,t,n){if(n.singleProperty===!0){let e=n.propertyList[0];Array.isArray(e)?(t[n.name]=n,n.a=e):t[n.name]=e}else if(e===`Connections`&&n.name===`C`){let e=[];n.propertyList.forEach(function(t,n){n!==0&&e.push(t)}),t.connections===void 0&&(t.connections=[]),t.connections.push(e)}else if(n.name===`Properties70`)Object.keys(n).forEach(function(e){t[e]=n[e]});else if(e===`Properties70`&&n.name===`P`){let e=n.propertyList[0],r=n.propertyList[1],i=n.propertyList[2],a=n.propertyList[3],o;e.indexOf(`Lcl `)===0&&(e=e.replace(`Lcl `,`Lcl_`)),r.indexOf(`Lcl `)===0&&(r=r.replace(`Lcl `,`Lcl_`)),o=r===`Color`||r===`ColorRGB`||r===`Vector`||r===`Vector3D`||r.indexOf(`Lcl_`)===0?[n.propertyList[4],n.propertyList[5],n.propertyList[6]]:n.propertyList[4],t[e]={type:r,type2:i,flag:a,value:o}}else t[n.name]===void 0?typeof n.id==`number`?(t[n.name]={},t[n.name][n.id]=n):t[n.name]=n:n.name===`PoseNode`?(Array.isArray(t[n.name])||(t[n.name]=[t[n.name]]),t[n.name].push(n)):t[n.name][n.id]===void 0&&(t[n.name][n.id]=n)}parseProperty(e){let t=e.getString(1),n;switch(t){case`C`:return e.getBoolean();case`D`:return e.getFloat64();case`F`:return e.getFloat32();case`I`:return e.getInt32();case`L`:return e.getInt64();case`R`:return n=e.getUint32(),e.getArrayBuffer(n);case`S`:return n=e.getUint32(),e.getString(n);case`Y`:return e.getInt16();case`b`:case`c`:case`d`:case`f`:case`i`:case`l`:let r=e.getUint32(),i=e.getUint32(),a=e.getUint32();if(i===0)switch(t){case`b`:case`c`:return e.getBooleanArray(r);case`d`:return e.getFloat64Array(r);case`f`:return e.getFloat32Array(r);case`i`:return e.getInt32Array(r);case`l`:return e.getInt64Array(r)}let o=new jl(xo(new Uint8Array(e.getArrayBuffer(a))).buffer);switch(t){case`b`:case`c`:return o.getBooleanArray(r);case`d`:return o.getFloat64Array(r);case`f`:return o.getFloat32Array(r);case`i`:return o.getInt32Array(r);case`l`:return o.getInt64Array(r)}break;default:throw Error(`THREE.FBXLoader: Unknown property type `+t)}}},jl=class{constructor(e,t){this.dv=new DataView(e),this.offset=0,this.littleEndian=t===void 0?!0:t,this._textDecoder=new TextDecoder}getOffset(){return this.offset}size(){return this.dv.buffer.byteLength}skip(e){this.offset+=e}getBoolean(){return(this.getUint8()&1)==1}getBooleanArray(e){let t=[];for(let n=0;n<e;n++)t.push(this.getBoolean());return t}getUint8(){let e=this.dv.getUint8(this.offset);return this.offset+=1,e}getInt16(){let e=this.dv.getInt16(this.offset,this.littleEndian);return this.offset+=2,e}getInt32(){let e=this.dv.getInt32(this.offset,this.littleEndian);return this.offset+=4,e}getInt32Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getInt32());return t}getUint32(){let e=this.dv.getUint32(this.offset,this.littleEndian);return this.offset+=4,e}getInt64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t&2147483648?(t=~t&4294967295,e=~e&4294967295,e===4294967295&&(t=t+1&4294967295),e=e+1&4294967295,-(t*4294967296+e)):t*4294967296+e}getInt64Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getInt64());return t}getUint64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t*4294967296+e}getFloat32(){let e=this.dv.getFloat32(this.offset,this.littleEndian);return this.offset+=4,e}getFloat32Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getFloat32());return t}getFloat64(){let e=this.dv.getFloat64(this.offset,this.littleEndian);return this.offset+=8,e}getFloat64Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getFloat64());return t}getArrayBuffer(e){let t=this.dv.buffer.slice(this.offset,this.offset+e);return this.offset+=e,t}getString(e){let t=this.offset,n=new Uint8Array(this.dv.buffer,t,e);this.skip(e);let r=n.indexOf(0);return r>=0&&(n=new Uint8Array(this.dv.buffer,t,r)),this._textDecoder.decode(n)}},Ml=class{add(e,t){this[e]=t}},Nl=[],Pl=new $t,Fl=new W})),Ll=r({TDSLoader:()=>Rl}),Rl,zl,Bl,Vl,Hl,Ul,Wl,Gl,Kl,ql,Jl,Yl,Xl,Zl,Ql,$l,eu,tu,nu,ru,iu,au,ou,su,cu,lu,uu,du,fu,pu,mu,hu,gu,_u,vu,yu,bu,xu,Su,Cu,wu,Tu,Eu=t((()=>{lo(),Rl=class extends ma{constructor(e){super(e),this.debug=!1,this.group=null,this.materials=[],this.meshes=[]}load(e,t,n,r){let i=this,a=this.path===``?Wa.extractUrlBase(e):this.path,o=new _a(this.manager);o.setPath(this.path),o.setResponseType(`arraybuffer`),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(n){try{t(i.parse(n,a))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e,t){this.group=new vn,this.materials=[],this.meshes=[],this.readFile(e,t);for(let e=0;e<this.meshes.length;e++)this.group.add(this.meshes[e]);return this.group}readFile(e,t){let n=new zl(new DataView(e),0,this.debugMessage);if(n.id===Vl||n.id===Hl||n.id===Bl){let e=n.readChunk();for(;e;){if(e.id===Ul){let t=e.readDWord();this.debugMessage(`3DS file version: `+t)}else e.id===Xl?this.readMeshData(e,t):this.debugMessage(`Unknown main chunk: `+e.hexId);e=n.readChunk()}}this.debugMessage(`Parsed `+this.meshes.length+` meshes`)}readMeshData(e,t){let n=e.readChunk();for(;n;){if(n.id===Zl){let e=+n.readDWord();this.debugMessage(`Mesh Version: `+e)}else if(n.id===Ql){let e=n.readFloat();this.debugMessage(`Master scale: `+e),this.group.scale.set(e,e,e)}else n.id===yu?(this.debugMessage(`Named Object`),this.readNamedObject(n)):n.id===$l?(this.debugMessage(`Material`),this.readMaterialEntry(n,t)):this.debugMessage(`Unknown MDATA chunk: `+n.hexId);n=e.readChunk()}}readNamedObject(e){let t=e.readString(),n=e.readChunk();for(;n;){if(n.id===bu){let e=this.readMesh(n);e.name=t,this.meshes.push(e)}else this.debugMessage(`Unknown named object chunk: `+n.hexId);n=e.readChunk()}}readMaterialEntry(e,t){let n=e.readChunk(),r=new Yi;for(;n;){if(n.id===eu)r.name=n.readString(),this.debugMessage(`   Name: `+r.name);else if(n.id===cu)this.debugMessage(`   Wireframe`),r.wireframe=!0;else if(n.id===lu){let e=n.readByte();r.wireframeLinewidth=e,this.debugMessage(`   Wireframe Thickness: `+e)}else if(n.id===ou)r.side=2,this.debugMessage(`   DoubleSided`);else if(n.id===su)this.debugMessage(`   Additive Blending`),r.blending=2;else if(n.id===nu)this.debugMessage(`   Diffuse Color`),r.color=this.readColor(n);else if(n.id===ru)this.debugMessage(`   Specular Color`),r.specular=this.readColor(n);else if(n.id===tu)this.debugMessage(`   Ambient color`),r.color=this.readColor(n);else if(n.id===iu){let e=this.readPercentage(n);r.shininess=e*100,this.debugMessage(`   Shininess : `+e)}else if(n.id===au){let e=this.readPercentage(n);r.opacity=1-e,this.debugMessage(`  Transparency : `+e),r.transparent=r.opacity<1}else n.id===uu?(this.debugMessage(`   ColorMap`),r.map=this.readMap(n,t)):n.id===fu?(this.debugMessage(`   BumpMap`),r.bumpMap=this.readMap(n,t)):n.id===du?(this.debugMessage(`   OpacityMap`),r.alphaMap=this.readMap(n,t)):n.id===pu?(this.debugMessage(`   SpecularMap`),r.specularMap=this.readMap(n,t)):this.debugMessage(`   Unknown material chunk: `+n.hexId);n=e.readChunk()}this.materials[r.name]=r}readMesh(e){let t=e.readChunk(),n=new hr,r=new Vr(n,new Yi);for(r.name=`mesh`;t;){if(t.id===xu){let e=t.readWord();this.debugMessage(`   Vertex: `+e);let r=[];for(let n=0;n<e;n++)r.push(t.readFloat()),r.push(t.readFloat()),r.push(t.readFloat());n.setAttribute(`position`,new J(r,3))}else if(t.id===Su)this.readFaceArray(t,r);else if(t.id===wu){let e=t.readWord();this.debugMessage(`   UV: `+e);let r=[];for(let n=0;n<e;n++)r.push(t.readFloat()),r.push(t.readFloat());n.setAttribute(`uv`,new J(r,2))}else if(t.id===Tu){this.debugMessage(`   Transformation Matrix (TODO)`);let e=[];for(let n=0;n<12;n++)e[n]=t.readFloat();let i=new K;i.elements[0]=e[0],i.elements[1]=e[6],i.elements[2]=e[3],i.elements[3]=e[9],i.elements[4]=e[2],i.elements[5]=e[8],i.elements[6]=e[5],i.elements[7]=e[11],i.elements[8]=e[1],i.elements[9]=e[7],i.elements[10]=e[4],i.elements[11]=e[10],i.elements[12]=0,i.elements[13]=0,i.elements[14]=0,i.elements[15]=1,i.transpose();let a=new K;a.copy(i).invert(),n.applyMatrix4(a),i.decompose(r.position,r.quaternion,r.scale)}else this.debugMessage(`   Unknown mesh chunk: `+t.hexId);t=e.readChunk()}return n.computeVertexNormals(),r}readFaceArray(e,t){let n=e.readWord();this.debugMessage(`   Faces: `+n);let r=[];for(let t=0;t<n;++t)r.push(e.readWord(),e.readWord(),e.readWord()),e.readWord();t.geometry.setIndex(r);let i=0,a=0;for(;!e.endOfChunk;){let n=e.readChunk();if(n.id===Cu){this.debugMessage(`      Material Group`);let e=this.readMaterialGroup(n),r=e.index.length*3;t.geometry.addGroup(a,r,i),a+=r,i++;let o=this.materials[e.name];Array.isArray(t.material)===!1&&(t.material=[]),o!==void 0&&t.material.push(o)}else this.debugMessage(`      Unknown face array chunk: `+n.hexId)}t.material.length===1&&(t.material=t.material[0])}readMap(e,t){let n=e.readChunk(),r={},i=new xa(this.manager);for(i.setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);n;){if(n.id===mu){let e=n.readString();r=i.load(e),this.debugMessage(`      File: `+t+e)}else n.id===_u?(r.offset.x=n.readFloat(),this.debugMessage(`      OffsetX: `+r.offset.x)):n.id===vu?(r.offset.y=n.readFloat(),this.debugMessage(`      OffsetY: `+r.offset.y)):n.id===hu?(r.repeat.x=n.readFloat(),this.debugMessage(`      RepeatX: `+r.repeat.x)):n.id===gu?(r.repeat.y=n.readFloat(),this.debugMessage(`      RepeatY: `+r.repeat.y)):this.debugMessage(`      Unknown map chunk: `+n.hexId);n=e.readChunk()}return r}readMaterialGroup(e){let t=e.readString(),n=e.readWord();this.debugMessage(`         Name: `+t),this.debugMessage(`         Faces: `+n);let r=[];for(let t=0;t<n;++t)r.push(e.readWord());return{name:t,index:r}}readColor(e){let t=e.readChunk(),n=new q;if(t.id===Gl||t.id===Kl){let e=t.readByte(),r=t.readByte(),i=t.readByte();n.setRGB(e/255,r/255,i/255),this.debugMessage(`      Color: `+n.r+`, `+n.g+`, `+n.b)}else if(t.id===Wl||t.id===ql){let e=t.readFloat(),r=t.readFloat(),i=t.readFloat();n.setRGB(e,r,i),this.debugMessage(`      Color: `+n.r+`, `+n.g+`, `+n.b)}else this.debugMessage(`      Unknown color chunk: `+t.hexId);return n}readPercentage(e){let t=e.readChunk();switch(t.id){case Jl:return t.readShort()/100;case Yl:return t.readFloat();default:return this.debugMessage(`      Unknown percentage chunk: `+t.hexId),0}}debugMessage(e){this.debug&&console.log(e)}},zl=class e{constructor(e,t,n){this.data=e,this.offset=t,this.position=t,this.debugMessage=n,this.debugMessage instanceof Function&&(this.debugMessage=function(){}),this.id=this.readWord(),this.size=this.readDWord(),this.end=this.offset+this.size,this.end>e.byteLength&&this.debugMessage(`Bad chunk size for chunk at `+t)}readChunk(){if(this.endOfChunk)return null;try{let t=new e(this.data,this.position,this.debugMessage);return this.position+=t.size,t}catch{return this.debugMessage(`Unable to read chunk at `+this.position),null}}get hexId(){return this.id.toString(16)}get endOfChunk(){return this.position>=this.end}readByte(){let e=this.data.getUint8(this.position,!0);return this.position+=1,e}readFloat(){try{let e=this.data.getFloat32(this.position,!0);return this.position+=4,e}catch(e){return this.debugMessage(e+` `+this.position+` `+this.data.byteLength),0}}readInt(){let e=this.data.getInt32(this.position,!0);return this.position+=4,e}readShort(){let e=this.data.getInt16(this.position,!0);return this.position+=2,e}readDWord(){let e=this.data.getUint32(this.position,!0);return this.position+=4,e}readWord(){let e=this.data.getUint16(this.position,!0);return this.position+=2,e}readString(){let e=``,t=this.readByte();for(;t;)e+=String.fromCharCode(t),t=this.readByte();return e}},Bl=19789,Vl=15786,Hl=49725,Ul=2,Wl=16,Gl=17,Kl=18,ql=19,Jl=48,Yl=49,Xl=15677,Zl=15678,Ql=256,$l=45055,eu=40960,tu=40976,nu=40992,ru=41008,iu=41024,au=41040,ou=41089,su=41091,cu=41093,lu=41095,uu=41472,du=41488,fu=41520,pu=41476,mu=41728,hu=41812,gu=41814,_u=41816,vu=41818,yu=16384,bu=16640,xu=16656,Su=16672,Cu=16688,wu=16704,Tu=16736})),Du=r({STLLoader:()=>Ou}),Ou,ku=t((()=>{lo(),Ou=class extends ma{constructor(e){super(e)}load(e,t,n,r){let i=this,a=new _a(this.manager);a.setPath(this.path),a.setResponseType(`arraybuffer`),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(n){try{t(i.parse(n))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e){function t(e){let t=new DataView(e);if(84+t.getUint32(80,!0)*50===t.byteLength)return!0;let r=[115,111,108,105,100];for(let e=0;e<5;e++)if(n(r,t,e))return!1;return!0}function n(e,t,n){for(let r=0,i=e.length;r<i;r++)if(e[r]!==t.getUint8(n+r))return!1;return!0}function r(e){let t=new DataView(e),n=t.getUint32(80,!0),r,i,a,o=!1,s,c,l,u,d;for(let e=0;e<70;e++)t.getUint32(e,!1)==1129270351&&t.getUint8(e+4)==82&&t.getUint8(e+5)==61&&(o=!0,s=new Float32Array(n*3*3),c=t.getUint8(e+6)/255,l=t.getUint8(e+7)/255,u=t.getUint8(e+8)/255,d=t.getUint8(e+9)/255);let f=new hr,p=new Float32Array(n*3*3),m=new Float32Array(n*3*3),h=new q;for(let e=0;e<n;e++){let n=84+e*50,d=t.getFloat32(n,!0),f=t.getFloat32(n+4,!0),g=t.getFloat32(n+8,!0);if(o){let e=t.getUint16(n+48,!0);e&32768?(r=c,i=l,a=u):(r=(e&31)/31,i=(e>>5&31)/31,a=(e>>10&31)/31)}for(let c=1;c<=3;c++){let l=n+c*12,u=e*3*3+(c-1)*3;p[u]=t.getFloat32(l,!0),p[u+1]=t.getFloat32(l+4,!0),p[u+2]=t.getFloat32(l+8,!0),m[u]=d,m[u+1]=f,m[u+2]=g,o&&(h.setRGB(r,i,a,H),s[u]=h.r,s[u+1]=h.g,s[u+2]=h.b)}}return f.setAttribute(`position`,new tr(p,3)),f.setAttribute(`normal`,new tr(m,3)),o&&(f.setAttribute(`color`,new tr(s,3)),f.hasColors=!0,f.alpha=d),f}function i(e){let t=new hr,n=/solid([\s\S]*?)endsolid/g,r=/facet([\s\S]*?)endfacet/g,i=/solid\s(.+)/,a=0,o=`[\\s]+([+-]?(?:\\d*)(?:\\.\\d*)?(?:[eE][+-]?\\d+)?)`,s=RegExp(`vertex`+o+o+o,`g`),c=RegExp(`normal`+o+o+o,`g`),l=[],u=[],d=[],f=new W,p,m=0,h=0,g=0;for(;(p=n.exec(e))!==null;){h=g;let e=p[0],n=(p=i.exec(e))===null?``:p[1];for(d.push(n);(p=r.exec(e))!==null;){let e=0,t=0,n=p[0];for(;(p=c.exec(n))!==null;)f.x=parseFloat(p[1]),f.y=parseFloat(p[2]),f.z=parseFloat(p[3]),t++;for(;(p=s.exec(n))!==null;)l.push(parseFloat(p[1]),parseFloat(p[2]),parseFloat(p[3])),u.push(f.x,f.y,f.z),e++,g++;t!==1&&console.error(`THREE.STLLoader: Something isn't right with the normal of face number `+a),e!==3&&console.error(`THREE.STLLoader: Something isn't right with the vertices of face number `+a),a++}let o=h,_=g-h;t.userData.groupNames=d,t.addGroup(o,_,m),m++}return t.setAttribute(`position`,new J(l,3)),t.setAttribute(`normal`,new J(u,3)),t}function a(e){return typeof e==`string`?e:new TextDecoder().decode(e)}function o(e){if(typeof e==`string`){let t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n)&255;return t.buffer||t}else return e}let s=o(e);return t(s)?r(s):i(a(e))}}})),Au,ju=t((()=>{lo(),Au=class extends ba{constructor(e){super(e)}parse(e){function t(e){switch(e.image_type){case d:case m:if(e.colormap_length>256||e.colormap_size!==24||e.colormap_type!==1)throw Error(`THREE.TGALoader: Invalid type colormap data for indexed type.`);break;case f:case p:case h:case g:if(e.colormap_type)throw Error(`THREE.TGALoader: Invalid type colormap data for colormap type.`);break;case u:throw Error(`THREE.TGALoader: No data.`);default:throw Error(`THREE.TGALoader: Invalid type `+e.image_type)}if(e.width<=0||e.height<=0)throw Error(`THREE.TGALoader: Invalid image size.`);if(e.pixel_size!==8&&e.pixel_size!==16&&e.pixel_size!==24&&e.pixel_size!==32)throw Error(`THREE.TGALoader: Invalid pixel size `+e.pixel_size)}function n(e,t,n,r,i){let a,o,s=n.pixel_size>>3,c=n.width*n.height*s;if(t&&(o=i.subarray(r,r+=n.colormap_length*(n.colormap_size>>3))),e){a=new Uint8Array(c);let e,t,n,o=0,l=new Uint8Array(s);for(;o<c;)if(e=i[r++],t=(e&127)+1,e&128){for(n=0;n<s;++n)l[n]=i[r++];for(n=0;n<t;++n)a.set(l,o+n*s);o+=s*t}else{for(t*=s,n=0;n<t;++n)a[o+n]=i[r++];o+=t}}else a=i.subarray(r,r+=t?n.width*n.height:c);return{pixel_data:a,palettes:o}}function r(e,t,n,r,i,a,o,s,c){let l=c,u,d=0,f,p,m=T.width;for(p=t;p!==r;p+=n)for(f=i;f!==o;f+=a,d++)u=s[d],e[(f+m*p)*4+3]=255,e[(f+m*p)*4+2]=l[u*3+0],e[(f+m*p)*4+1]=l[u*3+1],e[(f+m*p)*4+0]=l[u*3+2];return e}function i(e,t,n,r,i,a,o,s){let c,l=0,u,d,f=T.width;for(d=t;d!==r;d+=n)for(u=i;u!==o;u+=a,l+=2)c=s[l+0]+(s[l+1]<<8),e[(u+f*d)*4+0]=(c&31744)>>7,e[(u+f*d)*4+1]=(c&992)>>2,e[(u+f*d)*4+2]=(c&31)<<3,e[(u+f*d)*4+3]=c&32768?0:255;return e}function a(e,t,n,r,i,a,o,s){let c=0,l,u,d=T.width;for(u=t;u!==r;u+=n)for(l=i;l!==o;l+=a,c+=3)e[(l+d*u)*4+3]=255,e[(l+d*u)*4+2]=s[c+0],e[(l+d*u)*4+1]=s[c+1],e[(l+d*u)*4+0]=s[c+2];return e}function o(e,t,n,r,i,a,o,s){let c=0,l,u,d=T.width;for(u=t;u!==r;u+=n)for(l=i;l!==o;l+=a,c+=4)e[(l+d*u)*4+2]=s[c+0],e[(l+d*u)*4+1]=s[c+1],e[(l+d*u)*4+0]=s[c+2],e[(l+d*u)*4+3]=s[c+3];return e}function s(e,t,n,r,i,a,o,s){let c,l=0,u,d,f=T.width;for(d=t;d!==r;d+=n)for(u=i;u!==o;u+=a,l++)c=s[l],e[(u+f*d)*4+0]=c,e[(u+f*d)*4+1]=c,e[(u+f*d)*4+2]=c,e[(u+f*d)*4+3]=255;return e}function c(e,t,n,r,i,a,o,s){let c=0,l,u,d=T.width;for(u=t;u!==r;u+=n)for(l=i;l!==o;l+=a,c+=2)e[(l+d*u)*4+0]=s[c+0],e[(l+d*u)*4+1]=s[c+0],e[(l+d*u)*4+2]=s[c+0],e[(l+d*u)*4+3]=s[c+1];return e}function l(e,t,n,l,u){let d,f,p,m,h,g;switch((T.flags&_)>>v){default:case x:d=0,p=1,h=t,f=0,m=1,g=n;break;case y:d=0,p=1,h=t,f=n-1,m=-1,g=-1;break;case S:d=t-1,p=-1,h=-1,f=0,m=1,g=n;break;case b:d=t-1,p=-1,h=-1,f=n-1,m=-1,g=-1;break}if(O)switch(T.pixel_size){case 8:s(e,f,m,g,d,p,h,l);break;case 16:c(e,f,m,g,d,p,h,l);break;default:throw Error(`THREE.TGALoader: Format not supported.`)}else switch(T.pixel_size){case 8:r(e,f,m,g,d,p,h,l,u);break;case 16:i(e,f,m,g,d,p,h,l);break;case 24:a(e,f,m,g,d,p,h,l);break;case 32:o(e,f,m,g,d,p,h,l);break;default:throw Error(`THREE.TGALoader: Format not supported.`)}return e}let u=0,d=1,f=2,p=3,m=9,h=10,g=11,_=48,v=4,y=0,b=1,x=2,S=3;if(e.length<19)throw Error(`THREE.TGALoader: Not enough data to contain header.`);let C=0,w=new Uint8Array(e),T={id_length:w[C++],colormap_type:w[C++],image_type:w[C++],colormap_index:w[C++]|w[C++]<<8,colormap_length:w[C++]|w[C++]<<8,colormap_size:w[C++],origin:[w[C++]|w[C++]<<8,w[C++]|w[C++]<<8],width:w[C++]|w[C++]<<8,height:w[C++]|w[C++]<<8,pixel_size:w[C++],flags:w[C++]};if(t(T),T.id_length+C>e.length)throw Error(`THREE.TGALoader: No data.`);C+=T.id_length;let E=!1,D=!1,O=!1;switch(T.image_type){case 9:E=!0,D=!0;break;case 1:D=!0;break;case 10:E=!0;break;case 2:break;case 11:E=!0,O=!0;break;case 3:O=!0;break}let ee=new Uint8Array(T.width*T.height*4),k=n(E,D,T,C,w);return l(ee,T.width,T.height,k.pixel_data,k.palettes),{data:ee,width:T.width,height:T.height,flipY:!0,generateMipmaps:!0,minFilter:nt}}}}));function Mu(e,t){let n=[],r=e.childNodes;for(let e=0,i=r.length;e<i;e++){let i=r[e];i.nodeName===t&&n.push(i)}return n}function Nu(e){return e.length===0?[]:e.trim().split(/\s+/)}function Pu(e){return e.length===0?[]:e.trim().split(/\s+/).map(parseFloat)}function Fu(e){return e.length===0?[]:e.trim().split(/\s+/).map(e=>parseInt(e))}function Iu(e){return e.substring(1)}var Lu,Ru=t((()=>{lo(),Lu=class{constructor(){this.count=0}generateId(){return`three_default_`+ this.count++}parse(e){if(e.length===0)return null;let t=new DOMParser().parseFromString(e,`application/xml`),n=Mu(t,`COLLADA`)[0],r=t.getElementsByTagName(`parsererror`)[0];if(r!==void 0){let e=Mu(r,`div`)[0],t;return t=e?e.textContent:this.parserErrorToText(r),console.error(`THREE.ColladaLoader: Failed to parse collada file.
`,t),null}let i=n.getAttribute(`version`);console.debug(`THREE.ColladaLoader: File version`,i);let a=this.parseAsset(Mu(n,`asset`)[0]),o={animations:{},clips:{},controllers:{},images:{},effects:{},materials:{},cameras:{},lights:{},geometries:{},nodes:{},visualScenes:{},kinematicsModels:{},physicsModels:{},kinematicsScenes:{},joints:{}};return this.library=o,this.collada=n,this.parseLibrary(n,`library_animations`,`animation`,this.parseAnimation.bind(this)),this.parseLibrary(n,`library_animation_clips`,`animation_clip`,this.parseAnimationClip.bind(this)),this.parseLibrary(n,`library_controllers`,`controller`,this.parseController.bind(this)),this.parseLibrary(n,`library_images`,`image`,this.parseImage.bind(this)),this.parseLibrary(n,`library_effects`,`effect`,this.parseEffect.bind(this)),this.parseLibrary(n,`library_materials`,`material`,this.parseMaterial.bind(this)),this.parseLibrary(n,`library_cameras`,`camera`,this.parseCamera.bind(this)),this.parseLibrary(n,`library_lights`,`light`,this.parseLight.bind(this)),this.parseLibrary(n,`library_geometries`,`geometry`,this.parseGeometry.bind(this)),this.parseLibrary(n,`library_nodes`,`node`,this.parseNode.bind(this)),this.parseLibrary(n,`library_visual_scenes`,`visual_scene`,this.parseVisualScene.bind(this)),this.parseLibrary(n,`library_joints`,`joint`,this.parseLibraryJoint.bind(this)),this.parseLibrary(n,`library_kinematics_models`,`kinematics_model`,this.parseKinematicsModel.bind(this)),this.parseLibrary(n,`library_physics_models`,`physics_model`,this.parsePhysicsModel.bind(this)),this.parseLibrary(n,`scene`,`instance_kinematics_scene`,this.parseKinematicsScene.bind(this)),{library:o,asset:a,collada:n}}parserErrorToText(e){let t=[],n=[e];for(;n.length;){let e=n.shift();e.nodeType===Node.TEXT_NODE?t.push(e.textContent):(t.push(`
`),n.push(...e.childNodes))}return t.join(``).trim()}parseAsset(e){return{unit:this.parseAssetUnit(Mu(e,`unit`)[0]),upAxis:this.parseAssetUpAxis(Mu(e,`up_axis`)[0])}}parseAssetUnit(e){return e!==void 0&&e.hasAttribute(`meter`)===!0?parseFloat(e.getAttribute(`meter`)):1}parseAssetUpAxis(e){return e===void 0?`Y_UP`:e.textContent}parseLibrary(e,t,n,r){let i=Mu(e,t)[0];if(i!==void 0){let e=Mu(i,n);for(let t=0;t<e.length;t++)r(e[t])}}parseAnimation(e){let t={sources:{},samplers:{},channels:{}},n=!1;for(let r=0,i=e.childNodes.length;r<i;r++){let i=e.childNodes[r];if(i.nodeType!==1)continue;let a;switch(i.nodeName){case`source`:a=i.getAttribute(`id`),t.sources[a]=this.parseSource(i);break;case`sampler`:a=i.getAttribute(`id`),t.samplers[a]=this.parseAnimationSampler(i);break;case`channel`:a=i.getAttribute(`target`),t.channels[a]=this.parseAnimationChannel(i);break;case`animation`:this.parseAnimation(i),n=!0;break;default:}}n===!1&&(this.library.animations[e.getAttribute(`id`)||Ot.generateUUID()]=t)}parseAnimationSampler(e){let t={inputs:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`input`:let e=Iu(r.getAttribute(`source`)),n=r.getAttribute(`semantic`);t.inputs[n]=e;break}}return t}parseAnimationChannel(e){let t={},n=e.getAttribute(`target`).split(`/`),r=n.shift(),i=n.shift(),a=i.indexOf(`(`)!==-1,o=i.indexOf(`.`)!==-1;if(o)n=i.split(`.`),i=n.shift(),t.member=n.shift();else if(a){let e=i.split(`(`);i=e.shift();for(let t=0;t<e.length;t++)e[t]=parseInt(e[t].replace(/\)/,``));t.indices=e}return t.id=r,t.sid=i,t.arraySyntax=a,t.memberSyntax=o,t.sampler=Iu(e.getAttribute(`source`)),t}parseAnimationClip(e){let t={name:e.getAttribute(`id`)||`default`,start:parseFloat(e.getAttribute(`start`)||0),end:parseFloat(e.getAttribute(`end`)||0),animations:[]};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`instance_animation`:t.animations.push(Iu(r.getAttribute(`url`)));break}}this.library.clips[e.getAttribute(`id`)]=t}parseController(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`skin`:t.id=Iu(r.getAttribute(`source`)),t.skin=this.parseSkin(r);break;case`morph`:t.id=Iu(r.getAttribute(`source`)),console.warn(`THREE.ColladaLoader: Morph target animation not supported yet.`);break}}this.library.controllers[e.getAttribute(`id`)]=t}parseSkin(e){let t={sources:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`bind_shape_matrix`:t.bindShapeMatrix=Pu(r.textContent);break;case`source`:let e=r.getAttribute(`id`);t.sources[e]=this.parseSource(r);break;case`joints`:t.joints=this.parseJoints(r);break;case`vertex_weights`:t.vertexWeights=this.parseVertexWeights(r);break}}return t}parseJoints(e){let t={inputs:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`input`:let e=r.getAttribute(`semantic`),n=Iu(r.getAttribute(`source`));t.inputs[e]=n;break}}return t}parseVertexWeights(e){let t={inputs:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`input`:let e=r.getAttribute(`semantic`),n=Iu(r.getAttribute(`source`)),i=parseInt(r.getAttribute(`offset`));t.inputs[e]={id:n,offset:i};break;case`vcount`:t.vcount=Fu(r.textContent);break;case`v`:t.v=Fu(r.textContent);break}}return t}parseImage(e){let t={init_from:Mu(e,`init_from`)[0].textContent};this.library.images[e.getAttribute(`id`)]=t}parseEffect(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`profile_COMMON`:t.profile=this.parseEffectProfileCOMMON(r);break}}this.library.effects[e.getAttribute(`id`)]=t}parseEffectProfileCOMMON(e){let t={surfaces:{},samplers:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`newparam`:this.parseEffectNewparam(r,t);break;case`technique`:t.technique=this.parseEffectTechnique(r);break;case`extra`:t.extra=this.parseEffectExtra(r);break}}return t}parseEffectNewparam(e,t){let n=e.getAttribute(`sid`);for(let r=0,i=e.childNodes.length;r<i;r++){let i=e.childNodes[r];if(i.nodeType===1)switch(i.nodeName){case`surface`:t.surfaces[n]=this.parseEffectSurface(i);break;case`sampler2D`:t.samplers[n]=this.parseEffectSampler(i);break}}}parseEffectSurface(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`init_from`:t.init_from=r.textContent;break}}return t}parseEffectSampler(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`source`:t.source=r.textContent;break}}return t}parseEffectTechnique(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`constant`:case`lambert`:case`blinn`:case`phong`:t.type=r.nodeName,t.parameters=this.parseEffectParameters(r);break;case`extra`:t.extra=this.parseEffectExtra(r);break}}return t}parseEffectParameters(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`emission`:case`diffuse`:case`specular`:case`bump`:case`ambient`:case`shininess`:case`transparency`:t[r.nodeName]=this.parseEffectParameter(r);break;case`transparent`:t[r.nodeName]={opaque:r.hasAttribute(`opaque`)?r.getAttribute(`opaque`):`A_ONE`,data:this.parseEffectParameter(r)};break}}return t}parseEffectParameter(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`color`:t[r.nodeName]=Pu(r.textContent);break;case`float`:t[r.nodeName]=parseFloat(r.textContent);break;case`texture`:t[r.nodeName]={id:r.getAttribute(`texture`),extra:this.parseEffectParameterTexture(r)};break}}return t}parseEffectParameterTexture(e){let t={technique:{}};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`extra`:this.parseEffectParameterTextureExtra(r,t);break}}return t}parseEffectParameterTextureExtra(e,t){for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`technique`:this.parseEffectParameterTextureExtraTechnique(r,t);break}}}parseEffectParameterTextureExtraTechnique(e,t){for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`repeatU`:case`repeatV`:case`offsetU`:case`offsetV`:t.technique[r.nodeName]=parseFloat(r.textContent);break;case`wrapU`:case`wrapV`:r.textContent.toUpperCase()===`TRUE`?t.technique[r.nodeName]=1:r.textContent.toUpperCase()===`FALSE`?t.technique[r.nodeName]=0:t.technique[r.nodeName]=parseInt(r.textContent);break;case`bump`:t[r.nodeName]=this.parseEffectExtraTechniqueBump(r);break}}}parseEffectExtra(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`technique`:t.technique=this.parseEffectExtraTechnique(r);break}}return t}parseEffectExtraTechnique(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`double_sided`:t[r.nodeName]=parseInt(r.textContent);break;case`bump`:t[r.nodeName]=this.parseEffectExtraTechniqueBump(r);break}}return t}parseEffectExtraTechniqueBump(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`texture`:t[r.nodeName]={id:r.getAttribute(`texture`),texcoord:r.getAttribute(`texcoord`),extra:this.parseEffectParameterTexture(r)};break}}return t}parseMaterial(e){let t={name:e.getAttribute(`name`)};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`instance_effect`:t.url=Iu(r.getAttribute(`url`));break}}this.library.materials[e.getAttribute(`id`)]=t}parseCamera(e){let t={name:e.getAttribute(`name`)};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`optics`:t.optics=this.parseCameraOptics(r);break}}this.library.cameras[e.getAttribute(`id`)]=t}parseCameraOptics(e){for(let t=0;t<e.childNodes.length;t++){let n=e.childNodes[t];switch(n.nodeName){case`technique_common`:return this.parseCameraTechnique(n)}}return{}}parseCameraTechnique(e){let t={};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];switch(r.nodeName){case`perspective`:case`orthographic`:t.technique=r.nodeName,t.parameters=this.parseCameraParameters(r);break}}return t}parseCameraParameters(e){let t={};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];switch(r.nodeName){case`xfov`:case`yfov`:case`xmag`:case`ymag`:case`znear`:case`zfar`:case`aspect_ratio`:t[r.nodeName]=parseFloat(r.textContent);break}}return t}parseLight(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`technique_common`:t=this.parseLightTechnique(r);break}}this.library.lights[e.getAttribute(`id`)]=t}parseLightTechnique(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`directional`:case`point`:case`spot`:case`ambient`:t.technique=r.nodeName,t.parameters=this.parseLightParameters(r);break}}return t}parseLightParameters(e){let t={};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`color`:let e=Pu(r.textContent);t.color=new q().fromArray(e),Ft.colorSpaceToWorking(t.color,H);break;case`falloff_angle`:t.falloffAngle=parseFloat(r.textContent);break;case`quadratic_attenuation`:let n=parseFloat(r.textContent);t.distance=n?Math.sqrt(1/n):0;break}}return t}parseGeometry(e){let t={name:e.getAttribute(`name`),sources:{},vertices:{},primitives:[]},n=Mu(e,`mesh`)[0];if(n!==void 0){for(let e=0;e<n.childNodes.length;e++){let r=n.childNodes[e];if(r.nodeType!==1)continue;let i=r.getAttribute(`id`);switch(r.nodeName){case`source`:t.sources[i]=this.parseSource(r);break;case`vertices`:t.vertices=this.parseGeometryVertices(r);break;case`polygons`:case`lines`:case`linestrips`:case`polylist`:case`triangles`:t.primitives.push(this.parseGeometryPrimitive(r));break;default:}}this.library.geometries[e.getAttribute(`id`)]=t}}parseSource(e){let t={array:[],stride:3};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`float_array`:t.array=Pu(r.textContent);break;case`Name_array`:t.array=Nu(r.textContent);break;case`technique_common`:let e=Mu(r,`accessor`)[0];e!==void 0&&(t.stride=parseInt(e.getAttribute(`stride`)));break}}return t}parseGeometryVertices(e){let t={};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];r.nodeType===1&&(t[r.getAttribute(`semantic`)]=Iu(r.getAttribute(`source`)))}return t}parseGeometryPrimitive(e){let t={type:e.nodeName,material:e.getAttribute(`material`),count:parseInt(e.getAttribute(`count`)),inputs:{},stride:0,hasUV:!1};for(let n=0,r=e.childNodes.length;n<r;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`input`:let e=Iu(r.getAttribute(`source`)),n=r.getAttribute(`semantic`),i=parseInt(r.getAttribute(`offset`)),a=parseInt(r.getAttribute(`set`)),o=a>0?n+a:n;t.inputs[o]={id:e,offset:i},t.stride=Math.max(t.stride,i+1),n===`TEXCOORD`&&(t.hasUV=!0);break;case`vcount`:t.vcount=Fu(r.textContent);break;case`p`:t.p=Fu(r.textContent);break}}return t.type===`polygons`&&(t.vcount=[t.p.length/t.stride]),t}parseLibraryJoint(e){this.library.joints[e.getAttribute(`id`)]=this.parseKinematicsJoint(e)}parseKinematicsModel(e){let t={name:e.getAttribute(`name`)||``,joints:{},links:[]};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`technique_common`:this.parseKinematicsTechniqueCommon(r,t);break}}this.library.kinematicsModels[e.getAttribute(`id`)]=t}parseKinematicsTechniqueCommon(e,t){for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`joint`:t.joints[r.getAttribute(`sid`)]=this.parseKinematicsJoint(r);break;case`instance_joint`:t.joints[r.getAttribute(`sid`)]=this.library.joints[Iu(r.getAttribute(`url`))];break;case`link`:t.links.push(this.parseKinematicsLink(r));break}}}parseKinematicsJoint(e){let t;for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`prismatic`:case`revolute`:t=this.parseKinematicsJointParameter(r);break}}return t}parseKinematicsJointParameter(e){let t={sid:e.getAttribute(`sid`),name:e.getAttribute(`name`)||``,axis:new W,limits:{min:0,max:0},type:e.nodeName,static:!1,zeroPosition:0,middlePosition:0};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`axis`:let e=Pu(r.textContent);t.axis.fromArray(e);break;case`limits`:let n=r.getElementsByTagName(`max`)[0],i=r.getElementsByTagName(`min`)[0];t.limits.max=parseFloat(n.textContent),t.limits.min=parseFloat(i.textContent);break}}return t.limits.min>=t.limits.max&&(t.static=!0),t.middlePosition=(t.limits.min+t.limits.max)/2,t}parseKinematicsLink(e){let t={sid:e.getAttribute(`sid`),name:e.getAttribute(`name`)||``,attachments:[],transforms:[]};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`attachment_full`:t.attachments.push(this.parseKinematicsAttachment(r));break;case`matrix`:case`translate`:case`rotate`:t.transforms.push(this.parseKinematicsTransform(r));break}}return t}parseKinematicsAttachment(e){let t={joint:e.getAttribute(`joint`).split(`/`).pop(),transforms:[],links:[]};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`link`:t.links.push(this.parseKinematicsLink(r));break;case`matrix`:case`translate`:case`rotate`:t.transforms.push(this.parseKinematicsTransform(r));break}}return t}parseKinematicsTransform(e){let t={type:e.nodeName},n=Pu(e.textContent);switch(t.type){case`matrix`:t.obj=new K,t.obj.fromArray(n).transpose();break;case`translate`:t.obj=new W,t.obj.fromArray(n);break;case`rotate`:t.obj=new W,t.obj.fromArray(n),t.angle=Ot.degToRad(n[3]);break}return t}parsePhysicsModel(e){let t={name:e.getAttribute(`name`)||``,rigidBodies:{}};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`rigid_body`:t.rigidBodies[r.getAttribute(`name`)]={},this.parsePhysicsRigidBody(r,t.rigidBodies[r.getAttribute(`name`)]);break}}this.library.physicsModels[e.getAttribute(`id`)]=t}parsePhysicsRigidBody(e,t){for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`technique_common`:this.parsePhysicsTechniqueCommon(r,t);break}}}parsePhysicsTechniqueCommon(e,t){for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`inertia`:t.inertia=Pu(r.textContent);break;case`mass`:t.mass=Pu(r.textContent)[0];break}}}parseKinematicsScene(e){let t={bindJointAxis:[]};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`bind_joint_axis`:t.bindJointAxis.push(this.parseKinematicsBindJointAxis(r));break}}this.library.kinematicsScenes[Iu(e.getAttribute(`url`))]=t}parseKinematicsBindJointAxis(e){let t={target:e.getAttribute(`target`).split(`/`).pop()};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];if(r.nodeType===1)switch(r.nodeName){case`axis`:t.axis=r.getElementsByTagName(`param`)[0].textContent;let e=t.axis.split(`inst_`).pop().split(`axis`)[0];t.jointIndex=e.substring(0,e.length-1);break}}return t}prepareNodes(e){let t=e.getElementsByTagName(`node`);for(let e=0;e<t.length;e++){let n=t[e];n.hasAttribute(`id`)===!1&&n.setAttribute(`id`,this.generateId())}}parseNode(e){let t=new K,n=new W,r={name:e.getAttribute(`name`)||``,type:e.getAttribute(`type`),id:e.getAttribute(`id`),sid:e.getAttribute(`sid`),matrix:new K,nodes:[],instanceCameras:[],instanceControllers:[],instanceLights:[],instanceGeometries:[],instanceNodes:[],transforms:{},transformData:{},transformOrder:[]};for(let i=0;i<e.childNodes.length;i++){let a=e.childNodes[i];if(a.nodeType!==1)continue;let o;switch(a.nodeName){case`node`:r.nodes.push(a.getAttribute(`id`)),this.parseNode(a);break;case`instance_camera`:r.instanceCameras.push(Iu(a.getAttribute(`url`)));break;case`instance_controller`:r.instanceControllers.push(this.parseNodeInstance(a));break;case`instance_light`:r.instanceLights.push(Iu(a.getAttribute(`url`)));break;case`instance_geometry`:r.instanceGeometries.push(this.parseNodeInstance(a));break;case`instance_node`:r.instanceNodes.push(Iu(a.getAttribute(`url`)));break;case`matrix`:o=Pu(a.textContent),r.matrix.multiply(t.fromArray(o).transpose());{let e=a.getAttribute(`sid`);r.transforms[e]=a.nodeName,r.transformData[e]={type:`matrix`,array:o},r.transformOrder.push(e)}break;case`translate`:o=Pu(a.textContent),n.fromArray(o),r.matrix.multiply(t.makeTranslation(n.x,n.y,n.z));{let e=a.getAttribute(`sid`);r.transforms[e]=a.nodeName,r.transformData[e]={type:`translate`,x:o[0],y:o[1],z:o[2]},r.transformOrder.push(e)}break;case`rotate`:o=Pu(a.textContent);{let e=Ot.degToRad(o[3]);r.matrix.multiply(t.makeRotationAxis(n.fromArray(o),e));let i=a.getAttribute(`sid`);r.transforms[i]=a.nodeName,r.transformData[i]={type:`rotate`,axis:[o[0],o[1],o[2]],angle:o[3]},r.transformOrder.push(i)}break;case`scale`:o=Pu(a.textContent),r.matrix.scale(n.fromArray(o));{let e=a.getAttribute(`sid`);r.transforms[e]=a.nodeName,r.transformData[e]={type:`scale`,x:o[0],y:o[1],z:o[2]},r.transformOrder.push(e)}break;case`extra`:break;default:}}return this.hasNode(r.id)?console.warn(`THREE.ColladaLoader: There is already a node with ID %s. Exclude current node from further processing.`,r.id):this.library.nodes[r.id]=r,r}parseNodeInstance(e){let t={id:Iu(e.getAttribute(`url`)),materials:{},skeletons:[]};for(let n=0;n<e.childNodes.length;n++){let r=e.childNodes[n];switch(r.nodeName){case`bind_material`:let e=r.getElementsByTagName(`instance_material`);for(let n=0;n<e.length;n++){let r=e[n],i=r.getAttribute(`symbol`),a=r.getAttribute(`target`);t.materials[i]=Iu(a)}break;case`skeleton`:t.skeletons.push(Iu(r.textContent));break;default:break}}return t}parseVisualScene(e){let t={name:e.getAttribute(`name`),children:[]};this.prepareNodes(e);let n=Mu(e,`node`);for(let e=0;e<n.length;e++)t.children.push(this.parseNode(n[e]));this.library.visualScenes[e.getAttribute(`id`)]=t}hasNode(e){return this.library.nodes[e]!==void 0}}})),zu,Bu=t((()=>{lo(),Ru(),zu=class{constructor(e,t,n,r){this.library=e,this.collada=t,this.textureLoader=n,this.tgaLoader=r,this.tempColor=new q,this.animations=[],this.kinematics={},this.position=new W,this.scale=new W,this.quaternion=new kt,this.matrix=new K,this.deferredPivotAnimations={},this.transformNodes={}}compose(){let e=this.library;this.buildLibrary(e.animations,this.buildAnimation.bind(this)),this.buildLibrary(e.clips,this.buildAnimationClip.bind(this)),this.buildLibrary(e.controllers,this.buildController.bind(this)),this.buildLibrary(e.images,this.buildImage.bind(this)),this.buildLibrary(e.effects,this.buildEffect.bind(this)),this.buildLibrary(e.materials,this.buildMaterial.bind(this)),this.buildLibrary(e.cameras,this.buildCamera.bind(this)),this.buildLibrary(e.lights,this.buildLight.bind(this)),this.buildLibrary(e.geometries,this.buildGeometry.bind(this)),this.buildLibrary(e.visualScenes,this.buildVisualScene.bind(this)),this.setupAnimations(),this.setupKinematics();let t=this.parseScene(Mu(this.collada,`scene`)[0]);return t.animations=this.animations,{scene:t,animations:this.animations,kinematics:this.kinematics}}buildLibrary(e,t){for(let n in e){let r=e[n];r.build=t(e[n])}}getBuild(e,t){return e.build===void 0&&(e.build=t(e)),e.build}isEmpty(e){return Object.keys(e).length===0}buildAnimation(e){let t=[],n=e.channels,r=e.samplers,i=e.sources,a=this.aggregateAnimationChannels(n,r,i);for(let e in a){let n=this.library.nodes[e];if(!n)continue;let r=a[e];if(this.hasPivotTransforms(n))this.collectDeferredPivotAnimation(e,r);else{let i=this.getNode(e),a=!1;for(let e in r){let o=n.transforms[e],s=n.transformData[e],c=r[e];switch(o){case`matrix`:this.buildMatrixTracks(i,c,n,t);break;case`translate`:this.buildTranslateTrack(i,c,s,t);break;case`rotate`:a||=(this.buildRotateTrack(i,e,c,s,n,t),!0);break;case`scale`:this.buildScaleTrack(i,c,s,t);break}}}}return t}collectDeferredPivotAnimation(e,t){this.deferredPivotAnimations[e]||(this.deferredPivotAnimations[e]={});let n=this.deferredPivotAnimations[e];for(let e in t){n[e]||(n[e]={});for(let r in t[e])n[e][r]=t[e][r]}}hasPivotTransforms(e){for(let t of[`rotatePivot`,`rotatePivotInverse`,`rotatePivotTranslation`,`scalePivot`,`scalePivotInverse`,`scalePivotTranslation`])if(e.transforms[t]!==void 0)return!0;return!1}getAnimation(e){return this.getBuild(this.library.animations[e],this.buildAnimation.bind(this))}aggregateAnimationChannels(e,t,n){let r={};for(let i in e){if(!e.hasOwnProperty(i))continue;let a=e[i],o=t[a.sampler],s=o.inputs.INPUT,c=o.inputs.OUTPUT,l=n[s],u=n[c],d=o.inputs.INTERPOLATION,f=o.inputs.IN_TANGENT,p=o.inputs.OUT_TANGENT,m=d?n[d]:null,h=f?n[f]:null,g=p?n[p]:null,_=a.id,v=a.sid,y=a.member||`default`;r[_]||(r[_]={}),r[_][v]||(r[_][v]={}),r[_][v][y]={times:l.array,values:u.array,stride:u.stride,arraySyntax:a.arraySyntax,indices:a.indices,interpolation:m?m.array:null,inTangent:h?h.array:null,outTangent:g?g.array:null,inTangentStride:h?h.stride:0,outTangentStride:g?g.stride:0}}return r}buildMatrixTracks(e,t,n,r){let i=n.matrix.clone().transpose(),a={};for(let e in t){let n=t[e],r=n.times,i=n.values,o=n.stride;for(let e=0,t=r.length;e<t;e++){let t=r[e],s=e*o;if(a[t]===void 0&&(a[t]={}),n.arraySyntax===!0){let e=i[s],r=n.indices[0]+4*n.indices[1];a[t][r]=e}else for(let e=0;e<o;e++)a[t][e]=i[s+e]}}let o=this.prepareAnimationData(a,i),s={name:e.uuid,keyframes:o};this.createKeyframeTracks(s,r)}buildTranslateTrack(e,t,n,r){if(t.default&&t.default.stride===3){let n=t.default,i=Array.from(n.times),a=Array.from(n.values),o=new la(e.uuid+`.position`,i,a),s=this.getInterpolationInfo(t);this.applyInterpolation(o,s,t),r.push(o);return}let i=this.getTimesForAllAxes(t);if(i.length===0)return;let a=[],o=this.getInterpolationInfo(t);for(let e=0;e<i.length;e++){let r=i[e],o=this.getValueAtTime(t.X,r,n.x),s=this.getValueAtTime(t.Y,r,n.y),c=this.getValueAtTime(t.Z,r,n.z);a.push(o,s,c)}let s=new la(e.uuid+`.position`,i,a);this.applyInterpolation(s,o),r.push(s)}buildRotateTrack(e,t,n,r,i,a){let o=n.ANGLE||n.default;if(!o)return;let s=Array.from(o.times);if(s.length===0)return;let c=[];for(let e of i.transformOrder)if(i.transforms[e]===`rotate`){let t=i.transformData[e];c.push({sid:e,axis:new W(t.axis[0],t.axis[1],t.axis[2]),defaultAngle:t.angle})}let l=new kt,u=new kt,d=new kt,f=[],p=this.getInterpolationInfo(n);for(let e=0;e<s.length;e++){let n=s[e];l.identity();for(let e of c){let r;r=e.sid===t?this.getValueAtTime(o,n,e.defaultAngle):e.defaultAngle;let i=Ot.degToRad(r);d.setFromAxisAngle(e.axis,i),l.multiply(d)}e>0&&u.dot(l)<0&&(l.x=-l.x,l.y=-l.y,l.z=-l.z,l.w=-l.w),u.copy(l),f.push(l.x,l.y,l.z,l.w)}let m=new sa(e.uuid+`.quaternion`,s,f);this.applyInterpolation(m,p),a.push(m)}buildScaleTrack(e,t,n,r){if(t.default&&t.default.stride===3){let n=t.default,i=Array.from(n.times),a=Array.from(n.values),o=new la(e.uuid+`.scale`,i,a),s=this.getInterpolationInfo(t);this.applyInterpolation(o,s,t),r.push(o);return}let i=this.getTimesForAllAxes(t);if(i.length===0)return;let a=[],o=this.getInterpolationInfo(t);for(let e=0;e<i.length;e++){let r=i[e],o=this.getValueAtTime(t.X,r,n.x),s=this.getValueAtTime(t.Y,r,n.y),c=this.getValueAtTime(t.Z,r,n.z);a.push(o,s,c)}let s=new la(e.uuid+`.scale`,i,a);this.applyInterpolation(s,o),r.push(s)}getTimesForAllAxes(e){let t=[];return e.X&&(t=t.concat(Array.from(e.X.times))),e.Y&&(t=t.concat(Array.from(e.Y.times))),e.Z&&(t=t.concat(Array.from(e.Z.times))),e.ANGLE&&(t=t.concat(Array.from(e.ANGLE.times))),e.default&&(t=t.concat(Array.from(e.default.times))),t=[...new Set(t)].sort((e,t)=>e-t),t}getValueAtTime(e,t,n){if(!e)return n;let r=e.times,i=e.values,a=e.interpolation;for(let n=0;n<r.length;n++){if(r[n]===t)return i[n];if(r[n]>t){if(n===0)return i[0];let o=n-1,s=n,c=r[o],l=r[s],u=i[o],d=i[s],f=a?a[o]:`LINEAR`;return f===`STEP`?u:f===`BEZIER`&&e.inTangent&&e.outTangent?this.evaluateBezierComponent(e,o,s,c,l,t):u+(t-c)/(l-c)*(d-u)}}return i[i.length-1]}evaluateBezierComponent(e,t,n,r,i,a){let o=e.values,s=e.inTangent,c=e.outTangent,l=e.inTangentStride||1,u=o[t],d=o[n],f,p,m,h;l===2?(f=c[t*2],p=c[t*2+1],m=s[n*2],h=s[n*2+1]):(f=r+(i-r)/3,p=c[t],m=i-(i-r)/3,h=s[n]);let g=(a-r)/(i-r);for(let e=0;e<8;e++){let e=g*g,t=e*g,n=1-g,o=n*n,s=o*n*r+3*o*g*f+3*n*e*m+t*i,c=3*o*(f-r)+6*n*g*(m-f)+3*e*(i-m);if(Math.abs(c)<1e-10)break;let l=s-a;if(Math.abs(l)<1e-10)break;g-=l/c,g=Math.max(0,Math.min(1,g))}let _=g*g,v=_*g,y=1-g,b=y*y;return b*y*u+3*b*g*p+3*y*_*h+v*d}getInterpolationInfo(e){let t=[`X`,`Y`,`Z`,`ANGLE`,`default`],n=null,r=!0;for(let i of t){let t=e[i];if(!t||!t.interpolation)continue;let a=t.interpolation;for(let e=0;e<a.length;e++){let t=a[e];n===null?n=t:t!==n&&(r=!1)}}return{type:n||`LINEAR`,uniform:r}}applyInterpolation(e,t,n=null){if(t.type===`STEP`&&t.uniform)e.setInterpolation(st);else if(t.type===`BEZIER`&&t.uniform&&n){let t=n.default;t&&t.inTangent&&t.outTangent&&(e.setInterpolation(ut),e.settings={inTangents:new Float32Array(t.inTangent),outTangents:new Float32Array(t.outTangent)})}}prepareAnimationData(e,t){let n=[];for(let t in e)n.push({time:parseFloat(t),value:e[t]});n.sort((e,t)=>e.time-t.time);for(let e=0;e<16;e++)this.transformAnimationData(n,e,t.elements[e]);return n}createKeyframeTracks(e,t){let n=e.keyframes,r=e.name,i=[],a=[],o=[],s=[],c=this.position,l=this.quaternion,u=this.scale,d=this.matrix;for(let e=0,t=n.length;e<t;e++){let t=n[e],r=t.time,f=t.value;d.fromArray(f).transpose(),d.decompose(c,l,u),i.push(r),a.push(c.x,c.y,c.z),o.push(l.x,l.y,l.z,l.w),s.push(u.x,u.y,u.z)}return a.length>0&&t.push(new la(r+`.position`,i,a)),o.length>0&&t.push(new sa(r+`.quaternion`,i,o)),s.length>0&&t.push(new la(r+`.scale`,i,s)),t}transformAnimationData(e,t,n){let r,i=!0,a,o;for(a=0,o=e.length;a<o;a++)r=e[a],r.value[t]===void 0?r.value[t]=null:i=!1;if(i===!0)for(a=0,o=e.length;a<o;a++)r=e[a],r.value[t]=n;else this.createMissingKeyframes(e,t)}createMissingKeyframes(e,t){let n,r;for(let i=0,a=e.length;i<a;i++){let a=e[i];if(a.value[t]===null){if(n=this.getPrev(e,i,t),r=this.getNext(e,i,t),n===null){a.value[t]=r.value[t];continue}if(r===null){a.value[t]=n.value[t];continue}this.interpolate(a,n,r,t)}}}getPrev(e,t,n){for(;t>=0;){let r=e[t];if(r.value[n]!==null)return r;t--}return null}getNext(e,t,n){for(;t<e.length;){let r=e[t];if(r.value[n]!==null)return r;t++}return null}interpolate(e,t,n,r){if(n.time-t.time===0){e.value[r]=t.value[r];return}e.value[r]=(e.time-t.time)*(n.value[r]-t.value[r])/(n.time-t.time)+t.value[r]}buildAnimationClip(e){let t=[],n=e.name,r=e.end-e.start||-1,i=e.animations;for(let e=0,n=i.length;e<n;e++){let n=this.getAnimation(i[e]);for(let e=0,r=n.length;e<r;e++)t.push(n[e])}return new ua(n,r,t)}getAnimationClip(e){return this.getBuild(this.library.clips[e],this.buildAnimationClip.bind(this))}buildController(e){let t={id:e.id},n=this.library.geometries[t.id];return e.skin!==void 0&&(t.skin=this.buildSkin(e.skin),n.sources.skinIndices=t.skin.indices,n.sources.skinWeights=t.skin.weights),t}buildSkin(e){let t={joints:[],indices:{array:[],stride:4},weights:{array:[],stride:4}},n=e.sources,r=e.vertexWeights,i=r.vcount,a=r.v,o=r.inputs.JOINT.offset,s=r.inputs.WEIGHT.offset,c=e.sources[e.joints.inputs.JOINT],l=e.sources[e.joints.inputs.INV_BIND_MATRIX],u=n[r.inputs.WEIGHT.id].array,d=0,f,p,m;for(f=0,m=i.length;f<m;f++){let e=i[f],n=[];for(p=0;p<e;p++){let e=a[d+o],t=u[a[d+s]];n.push({index:e,weight:t}),d+=2}for(n.sort(h),p=0;p<4;p++){let e=n[p];e===void 0?(t.indices.array.push(0),t.weights.array.push(0)):(t.indices.array.push(e.index),t.weights.array.push(e.weight))}}for(e.bindShapeMatrix?t.bindMatrix=new K().fromArray(e.bindShapeMatrix).transpose():t.bindMatrix=new K().identity(),f=0,m=c.array.length;f<m;f++){let e=c.array[f],n=new K().fromArray(l.array,f*l.stride).transpose();t.joints.push({name:e,boneInverse:n})}return t;function h(e,t){return t.weight-e.weight}}getController(e){return this.getBuild(this.library.controllers[e],this.buildController.bind(this))}buildImage(e){return e.build===void 0?e.init_from:e.build}getImage(e){let t=this.library.images[e];return t===void 0?(console.warn(`THREE.ColladaLoader: Couldn't find image with ID:`,e),null):this.getBuild(t,this.buildImage.bind(this))}buildEffect(e){return e}getEffect(e){return this.getBuild(this.library.effects[e],this.buildEffect.bind(this))}getTextureLoader(e){let t,n=e.slice((e.lastIndexOf(`.`)-1>>>0)+2);switch(n=n.toLowerCase(),n){case`tga`:t=this.tgaLoader;break;default:t=this.textureLoader}return t}buildMaterial(e){let t=this.getEffect(e.url),n=t.profile.technique,r;switch(n.type){case`phong`:case`blinn`:r=new Yi;break;case`lambert`:r=new Xi;break;default:r=new kr;break}r.name=e.name||``;let i=this;function a(e,n=null){let r=t.profile.samplers[e.id],a=null;if(r!==void 0){let e=t.profile.surfaces[r.source];a=i.getImage(e.init_from)}else console.warn(`THREE.ColladaLoader: Undefined sampler. Access image directly (see #12530).`),a=i.getImage(e.id);if(a!==null){let t=i.getTextureLoader(a);if(t!==void 0){let r=t.load(a),o=e.extra;if(o!==void 0&&o.technique!==void 0&&i.isEmpty(o.technique)===!1){let e=o.technique;r.wrapS=e.wrapU?Je:Ye,r.wrapT=e.wrapV?Je:Ye,r.offset.set(e.offsetU||0,e.offsetV||0),r.repeat.set(e.repeatU||1,e.repeatV||1)}else r.wrapS=Je,r.wrapT=Je;return n!==null&&(r.colorSpace=n),r}else return console.warn(`THREE.ColladaLoader: Loader for texture %s not found.`,a),null}else return console.warn(`THREE.ColladaLoader: Couldn't create texture with ID:`,e.id),null}let o=n.parameters;for(let e in o){let t=o[e];switch(e){case`diffuse`:t.color&&r.color.fromArray(t.color),t.texture&&(r.map=a(t.texture,H));break;case`specular`:t.color&&r.specular&&r.specular.fromArray(t.color),t.texture&&(r.specularMap=a(t.texture));break;case`bump`:t.texture&&(r.normalMap=a(t.texture));break;case`ambient`:t.texture&&(r.lightMap=a(t.texture,H));break;case`shininess`:t.float&&r.shininess&&(r.shininess=t.float);break;case`emission`:t.color&&r.emissive&&r.emissive.fromArray(t.color),t.texture&&(r.emissiveMap=a(t.texture,H));break}}Ft.colorSpaceToWorking(r.color,H),r.specular&&Ft.colorSpaceToWorking(r.specular,H),r.emissive&&Ft.colorSpaceToWorking(r.emissive,H);let s=o.transparent,c=o.transparency;if(c===void 0&&s&&(c={float:1}),s===void 0&&c&&(s={opaque:`A_ONE`,data:{color:[1,1,1,1]}}),s&&c)if(s.data.texture)r.transparent=!0;else{let e=s.data.color;switch(s.opaque){case`A_ONE`:r.opacity=e[3]*c.float;break;case`RGB_ZERO`:r.opacity=1-e[0]*c.float;break;case`A_ZERO`:r.opacity=1-e[3]*c.float;break;case`RGB_ONE`:r.opacity=e[0]*c.float;break;default:console.warn(`THREE.ColladaLoader: Invalid opaque type "%s" of transparent tag.`,s.opaque)}r.opacity<1&&(r.transparent=!0)}if(n.extra!==void 0&&n.extra.technique!==void 0){let e=n.extra.technique;for(let t in e){let n=e[t];switch(t){case`double_sided`:r.side=n===1?2:0;break;case`bump`:r.normalMap=a(n.texture),r.normalScale=new U(1,1);break}}}return r}getMaterial(e){return this.getBuild(this.library.materials[e],this.buildMaterial.bind(this))}buildCamera(e){let t;switch(e.optics.technique){case`perspective`:t=new Pa(e.optics.parameters.yfov,e.optics.parameters.aspect_ratio,e.optics.parameters.znear,e.optics.parameters.zfar);break;case`orthographic`:let n=e.optics.parameters.ymag,r=e.optics.parameters.xmag,i=e.optics.parameters.aspect_ratio;r=r===void 0?n*i:r,n=n===void 0?r/i:n,r*=.5,n*=.5,t=new za(-r,r,n,-n,e.optics.parameters.znear,e.optics.parameters.zfar);break;default:t=new Pa;break}return t.name=e.name||``,t}getCamera(e){let t=this.library.cameras[e];return t===void 0?(console.warn(`THREE.ColladaLoader: Couldn't find camera with ID:`,e),null):this.getBuild(t,this.buildCamera.bind(this))}buildLight(e){let t;switch(e.technique){case`directional`:t=new Va;break;case`point`:t=new Ra;break;case`spot`:t=new Ia;break;case`ambient`:t=new Ha;break}return e.parameters.color&&t.color.copy(e.parameters.color),e.parameters.distance&&(t.distance=e.parameters.distance),e.parameters.falloffAngle&&(t.angle=Ot.degToRad(e.parameters.falloffAngle)),t}getLight(e){let t=this.library.lights[e];return t===void 0?(console.warn(`THREE.ColladaLoader: Couldn't find light with ID:`,e),null):this.getBuild(t,this.buildLight.bind(this))}groupPrimitives(e){let t={};for(let n=0;n<e.length;n++){let r=e[n];t[r.type]===void 0&&(t[r.type]=[]),t[r.type].push(r)}return t}checkUVCoordinates(e){let t=0;for(let n=0,r=e.length;n<r;n++)e[n].hasUV===!0&&t++;t>0&&t<e.length&&(e.uvsNeedsFix=!0)}buildGeometry(e){let t={},n=e.sources,r=e.vertices,i=e.primitives;if(i.length===0)return{};let a=this.groupPrimitives(i);for(let e in a){let i=a[e];this.checkUVCoordinates(i),t[e]=this.buildGeometryType(i,n,r)}return t}buildGeometryType(e,t,n){let r={},i={array:[],stride:0},a={array:[],stride:0},o={array:[],stride:0},s={array:[],stride:0},c={array:[],stride:0},l={array:[],stride:4},u={array:[],stride:4},d=new hr,f=[],p=0;for(let r=0;r<e.length;r++){let m=e[r],h=m.inputs,g=0;switch(m.type){case`lines`:case`linestrips`:g=m.count*2;break;case`triangles`:g=m.count*3;break;case`polygons`:case`polylist`:for(let e=0;e<m.count;e++){let t=m.vcount[e];switch(t){case 3:g+=3;break;case 4:g+=6;break;default:g+=(t-2)*3;break}}break;default:console.warn(`THREE.ColladaLoader: Unknown primitive type:`,m.type)}d.addGroup(p,g,r),p+=g,m.material&&f.push(m.material);for(let r in h){let d=h[r];switch(r){case`VERTEX`:for(let r in n){let f=n[r];switch(r){case`POSITION`:let n=i.array.length;if(this.buildGeometryData(m,t[f],d.offset,i.array),i.stride=t[f].stride,t.skinWeights&&t.skinIndices&&(this.buildGeometryData(m,t.skinIndices,d.offset,l.array),this.buildGeometryData(m,t.skinWeights,d.offset,u.array)),m.hasUV===!1&&e.uvsNeedsFix===!0){let e=(i.array.length-n)/i.stride;for(let t=0;t<e;t++)o.array.push(0,0)}break;case`NORMAL`:this.buildGeometryData(m,t[f],d.offset,a.array),a.stride=t[f].stride;break;case`COLOR`:this.buildGeometryData(m,t[f],d.offset,c.array),c.stride=t[f].stride;break;case`TEXCOORD`:this.buildGeometryData(m,t[f],d.offset,o.array),o.stride=t[f].stride;break;case`TEXCOORD1`:this.buildGeometryData(m,t[f],d.offset,s.array),o.stride=t[f].stride;break;default:console.warn(`THREE.ColladaLoader: Semantic "%s" not handled in geometry build process.`,r)}}break;case`NORMAL`:this.buildGeometryData(m,t[d.id],d.offset,a.array),a.stride=t[d.id].stride;break;case`COLOR`:this.buildGeometryData(m,t[d.id],d.offset,c.array,!0),c.stride=t[d.id].stride;break;case`TEXCOORD`:this.buildGeometryData(m,t[d.id],d.offset,o.array),o.stride=t[d.id].stride;break;case`TEXCOORD1`:this.buildGeometryData(m,t[d.id],d.offset,s.array),s.stride=t[d.id].stride;break}}}return i.array.length>0&&d.setAttribute(`position`,new J(i.array,i.stride)),a.array.length>0&&d.setAttribute(`normal`,new J(a.array,a.stride)),c.array.length>0&&d.setAttribute(`color`,new J(c.array,c.stride)),o.array.length>0&&d.setAttribute(`uv`,new J(o.array,o.stride)),s.array.length>0&&d.setAttribute(`uv1`,new J(s.array,s.stride)),l.array.length>0&&d.setAttribute(`skinIndex`,new J(l.array,l.stride)),u.array.length>0&&d.setAttribute(`skinWeight`,new J(u.array,u.stride)),r.data=d,r.type=e[0].type,r.materialKeys=f,r}buildGeometryData(e,t,n,r,i=!1){let a=e.p,o=e.stride,s=e.vcount,c=this.tempColor;function l(e){let t=a[e+n]*d,o=t+d;for(;t<o;t++)r.push(u[t]);if(i){let e=r.length-d-1;c.setRGB(r[e+0],r[e+1],r[e+2],H),r[e+0]=c.r,r[e+1]=c.g,r[e+2]=c.b}}let u=t.array,d=t.stride;if(e.vcount!==void 0){let e=0;for(let t=0,n=s.length;t<n;t++){let n=s[t];if(n===4){let t=e+o*0,n=e+o*1,r=e+o*2,i=e+o*3;l(t),l(n),l(i),l(n),l(r),l(i)}else if(n===3){let t=e+o*0,n=e+o*1,r=e+o*2;l(t),l(n),l(r)}else if(n>4){let t=[];for(let r=0;r<n;r++){let n=a[e+o*r]*d,i=u[n],s=u[n+1],c=u[n+2];t.push(new W(i,s,c))}let r=new W,i=new Ln;i.a=t[0],i.b=t[1],i.c=t[2],i.getNormal(r);let s=[];if(Math.abs(r.x)>Math.abs(r.y)&&Math.abs(r.x)>Math.abs(r.z))for(let e=0;e<n;e++)s.push(new U(t[e].y,t[e].z));else if(Math.abs(r.y)>Math.abs(r.z))for(let e=0;e<n;e++)s.push(new U(t[e].x,t[e].z));else for(let e=0;e<n;e++)s.push(new U(t[e].x,t[e].y));let c=Gi.isClockWise(s);c===!0&&s.reverse();let f=Gi.triangulateShape(s,[]);for(let t=0;t<f.length;t++){let r=f[t],i,a,s;c===!1?(i=r[0],a=r[1],s=r[2]):(i=n-1-r[0],a=n-1-r[2],s=n-1-r[1]);let u=e+o*i,d=e+o*a,p=e+o*s;l(u),l(d),l(p)}}e+=o*n}}else for(let e=0,t=a.length;e<t;e+=o)l(e)}getGeometry(e){return this.getBuild(this.library.geometries[e],this.buildGeometry.bind(this))}buildKinematicsModel(e){return e.build===void 0?e:e.build}getKinematicsModel(e){return this.getBuild(this.library.kinematicsModels[e],this.buildKinematicsModel.bind(this))}buildKinematicsScene(e){return e.build===void 0?e:e.build}getKinematicsScene(e){return this.getBuild(this.library.kinematicsScenes[e],this.buildKinematicsScene.bind(this))}setupKinematics(){let e=Object.keys(this.library.kinematicsModels)[0],t=Object.keys(this.library.kinematicsScenes)[0],n=Object.keys(this.library.visualScenes)[0];if(e===void 0||t===void 0)return;let r=this.getKinematicsModel(e),i=this.getKinematicsScene(t),a=this.getVisualScene(n),o=i.bindJointAxis,s={},c=this.collada,l=this;for(let e=0,t=o.length;e<t;e++){let t=o[e],n=c.querySelector(`[sid="`+t.target+`"]`);if(n){let e=n.parentElement;u(t.jointIndex,e)}}function u(e,t){let n=t.getAttribute(`name`),i=r.joints[e],o=l.buildTransformList(t);a.traverse(function(t){t.name===n&&(s[e]={object:t,transforms:o,joint:i,position:i.zeroPosition})})}let d=new K,f=this.matrix;this.kinematics={joints:r&&r.joints,getJointValue:function(e){let t=s[e];if(t)return t.position;console.warn(`THREE.ColladaLoader: Joint `+e+` doesn't exist.`)},setJointValue:function(e,t){let n=s[e];if(n){let r=n.joint;if(t>r.limits.max||t<r.limits.min)console.warn(`THREE.ColladaLoader: Joint `+e+` value `+t+` outside of limits (min: `+r.limits.min+`, max: `+r.limits.max+`).`);else if(r.static)console.warn(`THREE.ColladaLoader: Joint `+e+` is static.`);else{let i=n.object,a=r.axis,o=n.transforms;f.identity();for(let n=0;n<o.length;n++){let i=o[n];if(i.sid&&i.sid.indexOf(e)!==-1)switch(r.type){case`revolute`:f.multiply(d.makeRotationAxis(a,Ot.degToRad(t)));break;case`prismatic`:f.multiply(d.makeTranslation(a.x*t,a.y*t,a.z*t));break;default:console.warn(`THREE.ColladaLoader: Unknown joint type: `+r.type);break}else switch(i.type){case`matrix`:f.multiply(i.obj);break;case`translate`:f.multiply(d.makeTranslation(i.obj.x,i.obj.y,i.obj.z));break;case`scale`:f.scale(i.obj);break;case`rotate`:f.multiply(d.makeRotationAxis(i.obj,i.angle));break}}i.matrix.copy(f),i.matrix.decompose(i.position,i.quaternion,i.scale),s[e].position=t}}else console.warn(`THREE.ColladaLoader: Joint `+e+` does not exist.`)}}}buildTransformList(e){let t=[],n=this.collada.querySelector(`[id="`+e.id+`"]`);for(let e=0;e<n.childNodes.length;e++){let r=n.childNodes[e];if(r.nodeType!==1)continue;let i,a;switch(r.nodeName){case`matrix`:i=Pu(r.textContent);let e=new K().fromArray(i).transpose();t.push({sid:r.getAttribute(`sid`),type:r.nodeName,obj:e});break;case`translate`:case`scale`:i=Pu(r.textContent),a=new W().fromArray(i),t.push({sid:r.getAttribute(`sid`),type:r.nodeName,obj:a});break;case`rotate`:i=Pu(r.textContent),a=new W().fromArray(i);let n=Ot.degToRad(i[3]);t.push({sid:r.getAttribute(`sid`),type:r.nodeName,obj:a,angle:n});break}}return t}buildSkeleton(e,t){let n=[],r=[],i,a,o;for(i=0;i<e.length;i++){let r=e[i],a;if(this.hasNode(r))a=this.getNode(r),this.buildBoneHierarchy(a,t,n);else if(this.hasVisualScene(r)){let e=this.library.visualScenes[r].children;for(let r=0;r<e.length;r++){let i=e[r];if(i.type===`JOINT`){let e=this.getNode(i.id);this.buildBoneHierarchy(e,t,n)}}}else console.error(`THREE.ColladaLoader: Unable to find root bone of skeleton with ID:`,r)}for(i=0;i<t.length;i++)for(a=0;a<n.length;a++)if(o=n[a],o.bone.name===t[i].name){r[i]=o,o.processed=!0;break}for(i=0;i<n.length;i++)o=n[i],o.processed===!1&&(r.push(o),o.processed=!0);let s=[],c=[];for(i=0;i<r.length;i++)o=r[i],s.push(o.bone),c.push(o.boneInverse);return new ni(s,c)}buildBoneHierarchy(e,t,n){e.traverse(function(e){if(e.isBone===!0){let r;for(let n=0;n<t.length;n++){let i=t[n];if(i.name===e.name){r=i.boneInverse;break}}r===void 0&&(r=new K),n.push({bone:e,boneInverse:r,processed:!1})}})}buildNode(e){let t=[],n=e.matrix,r=e.nodes,i=e.type,a=e.instanceCameras,o=e.instanceControllers,s=e.instanceLights,c=e.instanceGeometries,l=e.instanceNodes;for(let e=0,n=r.length;e<n;e++)t.push(this.getNode(r[e]));for(let e=0,n=a.length;e<n;e++){let n=this.getCamera(a[e]);n!==null&&t.push(n.clone())}for(let e=0,n=o.length;e<n;e++){let n=o[e],r=this.getController(n.id),i=this.getGeometry(r.id),a=this.buildObjects(i,n.materials),s=n.skeletons,c=r.skin.joints,l=this.buildSkeleton(s,c);for(let e=0,n=a.length;e<n;e++){let n=a[e];n.isSkinnedMesh&&(n.bind(l,r.skin.bindMatrix),n.normalizeSkinWeights()),t.push(n)}}for(let e=0,n=s.length;e<n;e++){let n=this.getLight(s[e]);n!==null&&t.push(n.clone())}for(let e=0,n=c.length;e<n;e++){let n=c[e],r=this.getGeometry(n.id),i=this.buildObjects(r,n.materials);for(let e=0,n=i.length;e<n;e++)t.push(i[e])}for(let e=0,n=l.length;e<n;e++)t.push(this.getNode(l[e]).clone());let u;if(r.length===0&&t.length===1)u=t[0];else{u=i===`JOINT`?new Qr:new vn;for(let e=0;e<t.length;e++)u.add(t[e])}return u.name=i===`JOINT`?e.sid:e.name,i!==`JOINT`&&this.hasPivotTransforms(e)?this.wrapWithTransformHierarchy(u,e):(u.matrix.copy(n),u.matrix.decompose(u.position,u.quaternion,u.scale),u)}wrapWithTransformHierarchy(e,t){let n=t.id;this.transformNodes[n]={};let r=t.transformOrder,i=t.transformData,a=new vn;a.name=t.name;let o=a;for(let e=0;e<r.length;e++){let a=r[e],s=i[a],c=new vn;switch(c.name=t.name+`_`+a,s.type){case`translate`:c.position.set(s.x,s.y,s.z);break;case`rotate`:{let e=new W(s.axis[0],s.axis[1],s.axis[2]),t=Ot.degToRad(s.angle);c.quaternion.setFromAxisAngle(e,t),c.userData.rotationAxis=e;break}case`scale`:c.scale.set(s.x,s.y,s.z);break;case`matrix`:new K().fromArray(s.array).transpose().decompose(c.position,c.quaternion,c.scale);break}this.transformNodes[n][a]=c,o.add(c),o=c}return o.add(e),a}resolveMaterialBinding(e,t){let n=[];for(let r=0,i=e.length;r<i;r++){let i=t[e[r]];i===void 0?(console.warn(`THREE.ColladaLoader: Material with key %s not found. Apply fallback material.`,e[r]),n.push(this.fallbackMaterial)):n.push(this.getMaterial(i))}return n}get fallbackMaterial(){return this._fallbackMaterial===void 0&&(this._fallbackMaterial=new kr({name:ma.DEFAULT_MATERIAL_NAME,color:16711935})),this._fallbackMaterial}buildObjects(e,t){let n=[];for(let r in e){let i=e[r],a=this.resolveMaterialBinding(i.materialKeys,t);if(a.length===0&&(r===`lines`||r===`linestrips`?a.push(new bi):a.push(new Yi)),r===`lines`||r===`linestrips`)for(let e=0,t=a.length;e<t;e++){let t=a[e];if(t.isMeshPhongMaterial===!0||t.isMeshLambertMaterial===!0){let n=new bi;n.color.copy(t.color),n.opacity=t.opacity,n.transparent=t.transparent,a[e]=n}}let o=i.data.attributes.skinIndex!==void 0,s=a.length===1?a[0]:a,c;switch(r){case`lines`:c=new ji(i.data,s);break;case`linestrips`:c=new Oi(i.data,s);break;case`triangles`:case`polygons`:case`polylist`:c=o?new Zr(i.data,s):new Vr(i.data,s);break}n.push(c)}return n}hasNode(e){return this.library.nodes[e]!==void 0}getNode(e){return this.getBuild(this.library.nodes[e],this.buildNode.bind(this))}buildVisualScene(e){let t=new vn;t.name=e.name;let n=e.children;for(let e=0;e<n.length;e++){let r=n[e];t.add(this.getNode(r.id))}return t}hasVisualScene(e){return this.library.visualScenes[e]!==void 0}getVisualScene(e){return this.getBuild(this.library.visualScenes[e],this.buildVisualScene.bind(this))}parseScene(e){let t=Mu(e,`instance_visual_scene`)[0];return this.getVisualScene(this.parseId(t.getAttribute(`url`)))}parseId(e){return e.substring(1)}setupAnimations(){let e=this.library.clips;if(this.isEmpty(e)===!0){if(this.isEmpty(this.library.animations)===!1){let e=[];for(let t in this.library.animations){let n=this.getAnimation(t);for(let t=0,r=n.length;t<r;t++)e.push(n[t])}this.buildDeferredPivotAnimationTracks(e),this.animations.push(new ua(`default`,-1,e))}}else for(let t in e)this.animations.push(this.getAnimationClip(t))}buildDeferredPivotAnimationTracks(e){for(let t in this.deferredPivotAnimations){let n=this.library.nodes[t];if(!n)continue;let r=this.deferredPivotAnimations[t];this.buildTransformHierarchyTracks(t,r,n,e)}}buildTransformHierarchyTracks(e,t,n,r){let i=this.transformNodes[e];if(!i){console.warn(`THREE.ColladaLoader: Transform hierarchy not found for node:`,e);return}for(let e in t){let a=i[e];if(!a)continue;let o=n.transforms[e],s=n.transformData[e],c=t[e];switch(o){case`translate`:this.buildHierarchyTranslateTrack(a,c,s,r);break;case`rotate`:this.buildHierarchyRotateTrack(a,c,s,r);break;case`scale`:this.buildHierarchyScaleTrack(a,c,s,r);break}}}buildHierarchyTranslateTrack(e,t,n,r){if(t.default&&t.default.stride===3){let n=t.default,i=new la(e.uuid+`.position`,Array.from(n.times),Array.from(n.values)),a=this.getInterpolationInfo(t);this.applyInterpolation(i,a,t),r.push(i);return}let i=this.getTimesForAllAxes(t);if(i.length===0)return;let a=[],o=this.getInterpolationInfo(t);for(let e=0;e<i.length;e++){let r=i[e],o=this.getValueAtTime(t.X,r,n.x),s=this.getValueAtTime(t.Y,r,n.y),c=this.getValueAtTime(t.Z,r,n.z);a.push(o,s,c)}let s=new la(e.uuid+`.position`,i,a);this.applyInterpolation(s,o),r.push(s)}buildHierarchyRotateTrack(e,t,n,r){let i=t.ANGLE||t.default;if(!i)return;let a=Array.from(i.times);if(a.length===0)return;let o=e.userData.rotationAxis||new W(n.axis[0],n.axis[1],n.axis[2]),s=new kt,c=new kt,l=[],u=this.getInterpolationInfo(t);for(let e=0;e<a.length;e++){let t=a[e],r=this.getValueAtTime(i,t,n.angle),u=Ot.degToRad(r);s.setFromAxisAngle(o,u),e>0&&c.dot(s)<0&&(s.x=-s.x,s.y=-s.y,s.z=-s.z,s.w=-s.w),c.copy(s),l.push(s.x,s.y,s.z,s.w)}let d=new sa(e.uuid+`.quaternion`,a,l);this.applyInterpolation(d,u),r.push(d)}buildHierarchyScaleTrack(e,t,n,r){if(t.default&&t.default.stride===3){let n=t.default,i=new la(e.uuid+`.scale`,Array.from(n.times),Array.from(n.values)),a=this.getInterpolationInfo(t);this.applyInterpolation(i,a,t),r.push(i);return}let i=this.getTimesForAllAxes(t);if(i.length===0)return;let a=[],o=this.getInterpolationInfo(t);for(let e=0;e<i.length;e++){let r=i[e],o=this.getValueAtTime(t.X,r,n.x),s=this.getValueAtTime(t.Y,r,n.y),c=this.getValueAtTime(t.Z,r,n.z);a.push(o,s,c)}let s=new la(e.uuid+`.scale`,i,a);this.applyInterpolation(s,o),r.push(s)}}})),Vu=r({ColladaLoader:()=>Hu}),Hu,Uu=t((()=>{lo(),ju(),Ru(),Bu(),Hu=class extends ma{load(e,t,n,r){let i=this,a=i.path===``?Wa.extractUrlBase(e):i.path,o=new _a(i.manager);o.setPath(i.path),o.setRequestHeader(i.requestHeader),o.setWithCredentials(i.withCredentials),o.load(e,function(n){try{t(i.parse(n,a))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e,t){if(e.length===0)return{scene:new Cn};let n=new Lu().parse(e);if(n===null)return null;let{library:r,asset:i,collada:a}=n,o=new xa(this.manager);o.setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);let s;Au&&(s=new Au(this.manager),s.setPath(this.resourcePath||t));let{scene:c,animations:l,kinematics:u}=new zu(r,a,o,s).compose();return c.animations=l,i.upAxis===`Z_UP`&&(console.warn(`THREE.ColladaLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted, see #24289.`),c.rotation.set(-Math.PI/2,0,0)),c.scale.multiplyScalar(i.unit),{get animations(){return console.warn(`THREE.ColladaLoader: Please access animations over scene.animations now.`),l},kinematics:u,library:r,scene:c}}}})),Wu,Gu,Ku,qu,Ju,Yu=t((()=>{Wu=/^def\s+(?:(\w+)\s+)?"?([^"]+)"?$/,Gu=/^string\s+(\w+)$/,Ku=/^(?:uniform\s+)?(\w+(?:\[\])?)\s+(.+)$/,qu={Attribute:1,Prim:6,Relationship:8},Ju=class{parseText(e){e=this._preprocess(e);let t={},n=e.split(`
`),r=null,i=t,a=[t];for(let e of n)if(e.includes(`=`)){let t=this._findAssignmentOperator(e);if(t===-1){r=e.trim();continue}let n=e.slice(0,t).trim(),o=e.slice(t+1).trim();if(o.endsWith(`{`)){let e={};a.push(e),i[n]=e,i=e}else if(o.endsWith(`(`)){let e=o.slice(0,-1);i[n]=e;let t={};a.push(t),i=t}else i[n]=o}else if(e.includes(`:`)&&!e.includes(`=`)){let t=e.indexOf(`:`),n=e.slice(0,t).trim(),r=e.slice(t+1).trim();/^[\d.]+$/.test(n)&&(i[n]=r)}else if(e.endsWith(`{`)){r=e.slice(0,-1).trim()||r;let t=i[r]||{};a.push(t),i[r]=t,i=t}else if(e.endsWith(`}`)){if(a.pop(),a.length===0)continue;i=a[a.length-1]}else if(e.endsWith(`(`)){let t={};a.push(t),r=e.split(`(`)[0].trim()||r,i[r]=t,i=t}else e.endsWith(`)`)?(a.pop(),i=a[a.length-1]):e.trim()&&(r=e.trim());return t}_preprocess(e){e=this._stripBlockComments(e),e=this._collapseTripleQuotedStrings(e);let t=e.split(`
`),n=[],r=!1,i=0,a=0,o=``;for(let e=0;e<t.length;e++){let s=t[e];s=this._stripInlineComment(s);let c=s.trim();if(r){o+=` `+c;for(let e of c)e===`[`?i++:e===`]`?i--:e===`(`&&i>0?a++:e===`)`&&i>0&&a--;i===0&&a===0&&(n.push(o),o=``,r=!1)}else{if(c.includes(`=`)){let e=this._findAssignmentOperator(c);if(e!==-1){let t=c.slice(e+1).trim(),n=0,s=0;for(let e of t)e===`[`?n++:e===`]`&&s++;if(n>s){r=!0,i=n-s,a=0,o=c;continue}}}n.push(c)}}return n.join(`
`)}_stripBlockComments(e){let t=``,n=0;for(;n<e.length;)if(e[n]===`/`&&n+1<e.length&&e[n+1]===`*`){let t=n+2;for(;t<e.length;){if(e[t]===`*`&&t+1<e.length&&e[t+1]===`/`){t+=2;break}t++}n=t}else t+=e[n],n++;return t}_collapseTripleQuotedStrings(e){let t=``,n=0;for(;n<e.length;){if(n+2<e.length){let r=e.slice(n,n+3);if(r===`'''`||r===`"""`){let i=r;for(t+=i,n+=3;n<e.length;)if(n+2<e.length&&e.slice(n,n+3)===i){t+=i,n+=3;break}else e[n]===`
`?t+=`\\n`:e[n]!==`\r`&&(t+=e[n]),n++;continue}}t+=e[n],n++}return t}_stripInlineComment(e){if(e.trim().startsWith(`#usda`))return e;let t=!1,n=null,r=!1;for(let i=0;i<e.length;i++){let a=e[i];if(r){r=!1;continue}if(a===`\\`){r=!0;continue}if(!t&&(a===`"`||a===`'`))t=!0,n=a;else if(t&&a===n)t=!1,n=null;else if(!t&&a===`#`)return e.slice(0,i).trimEnd()}return e}_findAssignmentOperator(e){let t=!1,n=null,r=!1;for(let i=0;i<e.length;i++){let a=e[i];if(r){r=!1;continue}if(a===`\\`){r=!0;continue}if(!t&&(a===`"`||a===`'`))t=!0,n=a;else if(t&&a===n)t=!1,n=null;else if(!t&&a===`=`)return i}return-1}parseData(e){let t=this.parseText(e),n={},r={};if(`#usda 1.0`in t){let e=t[`#usda 1.0`];e.upAxis&&(r.upAxis=e.upAxis.replace(/"/g,``)),e.defaultPrim&&(r.defaultPrim=e.defaultPrim.replace(/"/g,``)),e.metersPerUnit!==void 0&&(r.metersPerUnit=parseFloat(e.metersPerUnit)),e.framesPerSecond!==void 0&&(r.framesPerSecond=parseFloat(e.framesPerSecond)),e.timeCodesPerSecond!==void 0&&(r.timeCodesPerSecond=parseFloat(e.timeCodesPerSecond))}n[`/`]={specType:qu.Prim,fields:r};let i=(e,t)=>{let r=[];for(let a in e){if(a===`#usda 1.0`||a===`variants`)continue;let o=a.match(Wu);if(o){let s=o[1]||``,c=o[2],l=t===`/`?`/`+c:t+`/`+c;r.push(c);let u={typeName:s},d=e[a];this._extractPrimData(d,l,u,n,qu),n[l]={specType:qu.Prim,fields:u},i(d,l)}}r.length>0&&n[t]&&(n[t].fields.primChildren=r)};return i(t,`/`),this._inferSkelElementSize(n),{specsByPath:n}}_inferSkelElementSize(e){for(let t in e){let n=e[t];if(n.specType!==qu.Prim||n.fields.typeName!==`Mesh`)continue;let r=e[t+`.points`];if(!r||!r.fields.default)continue;let i=r.fields.default.length/3;i!==0&&(this._inferElementSize(e[t+`.primvars:skel:jointIndices`],i),this._inferElementSize(e[t+`.primvars:skel:jointWeights`],i))}}_inferElementSize(e,t){if(!e||e.fields.elementSize!==void 0||!e.fields.default)return;let n=e.fields.default.length;n>0&&n%t===0&&(e.fields.elementSize=n/t)}_extractPrimData(e,t,n,r,i){if(!(!e||typeof e!=`object`))for(let a in e){if(a.startsWith(`def `))continue;if(a===`prepend references`){n.references=[e[a]];continue}if(a===`payload`){n.payload=e[a];continue}if(a===`variants`){let t={},r=e[a];for(let e in r){let n=e.match(Gu);if(n){let i=n[1];t[i]=r[e].replace(/"/g,``)}}Object.keys(t).length>0&&(n.variantSelection=t);continue}if(a.startsWith(`rel `)){let n=a.slice(4),o=t+`.`+n,s=e[a].replace(/[<>]/g,``);r[o]={specType:i.Relationship,fields:{targetPaths:[s]}};continue}if(a.includes(`xformOpOrder`)){n.xformOpOrder=e[a].replace(/[\[\]]/g,``).split(`,`).map(e=>e.trim().replace(/"/g,``));continue}let o=a.match(Ku);if(o){let n=o[1],s=o[2],c=e[a];if(s.endsWith(`.connect`)){let e=s.slice(0,-8),a=t+`.`+e,o=String(c).trim();o.startsWith(`<`)&&(o=o.slice(1)),o.endsWith(`>`)&&(o=o.slice(0,-1)),r[a]||(r[a]={specType:i.Attribute,fields:{typeName:n}}),r[a].fields.connectionPaths=[o];continue}if(s.endsWith(`.timeSamples`)&&typeof c==`object`){let e=s.slice(0,-12),a=t+`.`+e,o=[],l=[];for(let e in c){let t=parseFloat(e);isNaN(t)||(o.push(t),l.push(this._parseAttributeValue(n,c[e])))}let u=o.map((e,t)=>({t:e,v:l[t]})).sort((e,t)=>e.t-t.t);r[a]={specType:i.Attribute,fields:{timeSamples:{times:u.map(e=>e.t),values:u.map(e=>e.v)},typeName:n}}}else{let e=this._parseAttributeValue(n,c),a=t+`.`+s;r[a]?(r[a].fields.default=e,r[a].fields.typeName=n):r[a]={specType:i.Attribute,fields:{default:e,typeName:n}}}}}}_parseAttributeValue(e,t){if(t==null)return;let n=String(t).trim();if(e.endsWith(`[]`)){let t;try{let e=n.replace(/\(/g,`[`).replace(/\)/g,`]`);e.endsWith(`,`)&&(e=e.slice(0,-1));let r=JSON.parse(e);t=Array.isArray(r)&&Array.isArray(r[0])?r.flat():r}catch{t=n.replace(/[\[\]]/g,``).split(`,`).map(e=>{let t=e.trim(),n=parseFloat(t);return isNaN(n)?t.replace(/"/g,``):n})}if(e.startsWith(`quat`))for(let e=0;e<t.length;e+=4){let n=t[e];t[e]=t[e+1],t[e+1]=t[e+2],t[e+2]=t[e+3],t[e+3]=n}return t}if(e.includes(`3`)||e.includes(`2`)||e.includes(`4`))return n.replace(/[()]/g,``).split(`,`).map(e=>parseFloat(e.trim()));if(e.startsWith(`quat`)){let e=n.replace(/[()]/g,``).split(`,`).map(e=>parseFloat(e.trim()));return[e[1],e[2],e[3],e[0]]}return e.includes(`matrix`)?n.replace(/[()]/g,``).split(`,`).map(e=>parseFloat(e.trim())):e===`float`||e===`double`||e===`int`?parseFloat(n):e===`string`||e===`token`?this._parseString(n):e===`asset`?n.replace(/@/g,``).replace(/"/g,``):this._parseString(n)}_parseString(e){(e.startsWith(`"`)&&e.endsWith(`"`)||e.startsWith(`'`)&&e.endsWith(`'`))&&(e=e.slice(1,-1));let t=``,n=0;for(;n<e.length;)if(e[n]===`\\`&&n+1<e.length){let r=e[n+1];switch(r){case`n`:t+=`
`;break;case`t`:t+=`	`;break;case`r`:t+=`\r`;break;case`\\`:t+=`\\`;break;case`"`:t+=`"`;break;case`'`:t+=`'`;break;default:t+=r;break}n+=2}else t+=e[n],n++;return t}}}));function Xu(e,t,n,r,i,a){for(;t<n;){let o=e[t++];if(t>n)break;let s=o>>4;if(s===15){let r;do{if(t>=n)break;r=e[t++],s+=r}while(r===255&&t<n)}if(s>0){t+s>n&&(s=n-t);for(let n=0;n<s&&!(i>=a);n++)r[i++]=e[t++]}if(t>=n||t+2>n)break;let c=e[t++]|e[t++]<<8;if(c===0)break;let l=(o&15)+4;if(l===19){let r;do{if(t>=n)break;r=e[t++],l+=r}while(r===255&&t<n)}let u=i-c;if(u<0)break;for(let e=0;e<l&&!(i>=a);e++)r[i++]=r[u+e]}return i}function Zu(e,t){let n=new Uint8Array(t),r=e[0];if(r===0)return Xu(e,1,e.length,n,0,t),n;{let i=1,a=[];for(let t=0;t<r;t++){let t=(e[i]|e[i+1]<<8|e[i+2]<<16|e[i+3]<<24)>>>0;a.push(t),i+=4}let o=i,s=0;for(let i=0;i<r;i++){let r=a[i],c=Math.min(65536,t-s);Xu(e,o,o+r,n,s,s+c),o+=r,s+=c}return n}}function Qu(e,t){let n=t*4+(t*2+7>>3)+4;return $u(Zu(new Uint8Array(e),n),t)}function $u(e,t){let n=new DataView(e.buffer,e.byteOffset,e.byteLength),r=0,i=n.getInt32(r,!0);r+=4;let a=t*2+7>>3,o=r,s=r+a,c=new Int32Array(t),l=0,u=o,d=s;for(let r=0;r<t;){let a=e[u++];for(let e=0;e<4&&r<t;e++,r++){let t=a>>e*2&3,o=0;switch(t){case 0:o=i;break;case 1:o=n.getInt8(d),d+=1;break;case 2:o=n.getInt16(d,!0),d+=2;break;case 3:o=n.getInt32(d,!0),d+=4;break}l+=o,c[r]=l}}return c}var ed,td,nd,$,rd,id,ad,od,sd,cd,ld=t((()=>{ed=new TextDecoder,td=new Float32Array(32);for(let e=0;e<32;e++)td[e]=2**(e-15);nd=2**-14,$={Invalid:0,Bool:1,UChar:2,Int:3,UInt:4,Int64:5,UInt64:6,Half:7,Float:8,Double:9,String:10,Token:11,AssetPath:12,Matrix2d:13,Matrix3d:14,Matrix4d:15,Quatd:16,Quatf:17,Quath:18,Vec2d:19,Vec2f:20,Vec2h:21,Vec2i:22,Vec3d:23,Vec3f:24,Vec3h:25,Vec3i:26,Vec4d:27,Vec4f:28,Vec4h:29,Vec4i:30,Dictionary:31,TokenListOp:32,StringListOp:33,PathListOp:34,ReferenceListOp:35,IntListOp:36,Int64ListOp:37,UIntListOp:38,UInt64ListOp:39,PathVector:40,TokenVector:41,Specifier:42,Permission:43,Variability:44,VariantSelectionMap:45,TimeSamples:46,Payload:47,DoubleVector:48,LayerOffsetVector:49,StringVector:50,ValueBlock:51,Value:52,UnregisteredValue:53,UnregisteredValueListOp:54,PayloadListOp:55,TimeCode:56,PathExpression:57,Relocates:58,Spline:59,AnimationBlock:60},rd=4294967295,id=105,ad=116,od=class{constructor(e){this.buffer=e,this.view=new DataView(e),this.offset=0}seek(e){this.offset=e}tell(){return this.offset}readUint8(){let e=this.view.getUint8(this.offset);return this.offset+=1,e}readInt8(){let e=this.view.getInt8(this.offset);return this.offset+=1,e}readUint16(){let e=this.view.getUint16(this.offset,!0);return this.offset+=2,e}readInt16(){let e=this.view.getInt16(this.offset,!0);return this.offset+=2,e}readUint32(){let e=this.view.getUint32(this.offset,!0);return this.offset+=4,e}readInt32(){let e=this.view.getInt32(this.offset,!0);return this.offset+=4,e}readUint64(){let e=this.view.getUint32(this.offset,!0),t=this.view.getUint32(this.offset+4,!0);return this.offset+=8,t*4294967296+e}readInt64(){let e=this.view.getUint32(this.offset,!0),t=this.view.getInt32(this.offset+4,!0);return this.offset+=8,t*4294967296+e}readFloat32(){let e=this.view.getFloat32(this.offset,!0);return this.offset+=4,e}readFloat64(){let e=this.view.getFloat64(this.offset,!0);return this.offset+=8,e}readBytes(e){let t=new Uint8Array(this.buffer,this.offset,e);return this.offset+=e,t}readString(e){let t=this.readBytes(e),n=0;for(;n<e&&t[n]!==0;)n++;return ed.decode(t.subarray(0,n))}},sd=class{constructor(e,t){this.lo=e,this.hi=t}get isArray(){return(this.hi&2147483648)!=0}get isInlined(){return(this.hi&1073741824)!=0}get isCompressed(){return(this.hi&536870912)!=0}get typeEnum(){return this.hi>>16&255}get payload(){return this.lo+(this.hi&65535)*4294967296}getInlinedValue(){return this.lo}},cd=class{parseData(e){this.buffer=e instanceof ArrayBuffer?e:e.buffer,this.reader=new od(this.buffer),this.version={major:0,minor:0,patch:0},this._conversionBuffer=new ArrayBuffer(4),this._conversionView=new DataView(this._conversionBuffer),this._readBootstrap(),this._readTOC(),this._readTokens(),this._readStrings(),this._readFields(),this._readFieldSets(),this._readPaths(),this._readSpecs(),this.specsByPath={};for(let e of this.specs){let t=this.paths[e.pathIndex];if(!t)continue;let n=this._getFieldsForSpec(e);this.specsByPath[t]={specType:e.specType,fields:n}}return{specsByPath:this.specsByPath}}_readBootstrap(){let e=this.reader;if(e.seek(0),e.readString(8)!==`PXR-USDC`)throw Error(`THREE.USDCParser: Not a valid USDC file.`);this.version.major=e.readUint8(),this.version.minor=e.readUint8(),this.version.patch=e.readUint8(),e.readBytes(5),this.tocOffset=e.readUint64()}_readTOC(){let e=this.reader;e.seek(this.tocOffset);let t=e.readUint64();this.sections={};for(let n=0;n<t;n++){let t=e.readString(16),n=e.readUint64(),r=e.readUint64();this.sections[t]={start:n,size:r}}}_readTokens(){let e=this.sections.TOKENS;if(!e)return;let t=this.reader;t.seek(e.start);let n=t.readUint64();if(this.tokens=[],this.version.major===0&&this.version.minor<4){let e=t.readUint64(),r=t.readBytes(e),i=0;for(let e=0;e<n;e++){let e=i;for(;e<r.length&&r[e]!==0;)e++;this.tokens.push(ed.decode(r.subarray(i,e))),i=e+1}}else{let e=t.readUint64(),r=t.readUint64(),i=Zu(t.readBytes(r),e),a=0;for(let e=0;e<n;e++){let e=a;for(;e<i.length&&i[e]!==0;)e++;this.tokens.push(ed.decode(i.subarray(a,e))),a=e+1}}}_readStrings(){let e=this.sections.STRINGS;if(!e){this.strings=[];return}let t=this.reader;t.seek(e.start);let n=Math.floor(e.size/4);this.strings=[];for(let e=0;e<n;e++)this.strings.push(t.readUint32())}_readFields(){let e=this.sections.FIELDS;if(!e)return;let t=this.reader;if(t.seek(e.start),this.fields=[],this.version.major===0&&this.version.minor<4){let n=Math.floor(e.size/12);for(let e=0;e<n;e++){let e=t.readUint32(),n=t.readUint32(),r=t.readUint32();this.fields.push({tokenIndex:e,valueRep:new sd(n,r)})}}else{let e=t.readUint64(),n=t.readUint64(),r=t.readBytes(n),i=Qu(r.buffer.slice(r.byteOffset,r.byteOffset+n),e),a=t.readUint64(),o=Zu(t.readBytes(a),e*8),s=new DataView(o.buffer,o.byteOffset,o.byteLength);for(let t=0;t<e;t++){let e=s.getUint32(t*8,!0),n=s.getUint32(t*8+4,!0);this.fields.push({tokenIndex:i[t],valueRep:new sd(e,n)})}}}_readFieldSets(){let e=this.sections.FIELDSETS;if(!e)return;let t=this.reader;if(t.seek(e.start),this.fieldSets=[],this.version.major===0&&this.version.minor<4){let n=Math.floor(e.size/4);for(let e=0;e<n;e++)this.fieldSets.push(t.readUint32())}else{let e=t.readUint64(),n=t.readUint64(),r=t.readBytes(n),i=Qu(r.buffer.slice(r.byteOffset,r.byteOffset+n),e);for(let t=0;t<e;t++)this.fieldSets.push(i[t])}}_readPaths(){let e=this.sections.PATHS;if(!e)return;let t=this.reader;t.seek(e.start);let n=t.readUint64();if(this.paths=Array(n).fill(``),this.version.major===0&&this.version.minor<4)this._readPathsRecursive(``);else{t.readUint64();let e=t.readUint64(),r=t.readBytes(e),i=Qu(r.buffer.slice(r.byteOffset,r.byteOffset+e),n),a=t.readUint64(),o=t.readBytes(a),s=Qu(o.buffer.slice(o.byteOffset,o.byteOffset+a),n),c=t.readUint64(),l=t.readBytes(c),u=Qu(l.buffer.slice(l.byteOffset,l.byteOffset+c),n);this._buildPathsFromCompressed(i,s,u)}}_readPathsRecursive(e,t=0){let n=this.reader;if(t>1e3)return;let r=n.readUint32(),i=n.readUint32(),a=n.readUint8(),o=(a&1)!=0,s=(a&2)!=0,c=(a&4)!=0,l;if(e===``)l=`/`;else{let t=this.tokens[i]||``;l=c?e+`.`+t:e===`/`?`/`+t:e+`/`+t}if(this.paths[r]=l,o&&s){let r=n.readUint64();this._readPathsRecursive(l,t+1),n.seek(r),this._readPathsRecursive(e,t+1)}else o?this._readPathsRecursive(l,t+1):s&&this._readPathsRecursive(e,t+1)}_buildPathsFromCompressed(e,t,n){let r=(i,a)=>{let o=i;for(;o<e.length;){let i=o++,s=e[i],c=t[i],l=n[i],u;if(a===``)u=`/`,a=u;else{let e=this.tokens[Math.abs(c)]||``;u=c<0?a+`.`+e:a===`/`?`/`+e:a+`/`+e}this.paths[s]=u;let d=l>0||l===-1,f=l>=0;if(d)f&&r(i+l,a),a=u;else if(!f)break}};r(0,``)}_readSpecs(){let e=this.sections.SPECS;if(!e)return;let t=this.reader;if(t.seek(e.start),this.specs=[],this.version.major===0&&this.version.minor<4){let n=this.version.minor===0&&this.version.patch===1?16:12,r=Math.floor(e.size/n);for(let e=0;e<r;e++){let e=t.readUint32(),r=t.readUint32(),i=t.readUint32();n===16&&t.readUint32(),this.specs.push({pathIndex:e,fieldSetIndex:r,specType:i})}}else{let e=t.readUint64(),n=t.readUint64(),r=t.readBytes(n),i=Qu(r.buffer.slice(r.byteOffset,r.byteOffset+n),e),a=t.readUint64(),o=t.readBytes(a),s=Qu(o.buffer.slice(o.byteOffset,o.byteOffset+a),e),c=t.readUint64(),l=t.readBytes(c),u=Qu(l.buffer.slice(l.byteOffset,l.byteOffset+c),e);for(let t=0;t<e;t++)this.specs.push({pathIndex:i[t],fieldSetIndex:s[t],specType:u[t]})}}_readValue(e){let t=e.typeEnum,n=e.isArray,r=e.isInlined;if(t===$.TimeSamples)return this._readTimeSamples(e);if(r)return this._readInlinedValue(e);let i=e.payload;if(i===0&&n)return[];if(i<0||i>=this.buffer.byteLength)throw RangeError(`USDCParser: Invalid payload offset `+i+` for type `+t+`.`);let a=this.reader.tell();this.reader.seek(i);let o;return o=n?this._readArrayValue(e):this._readScalarValue(t),this.reader.seek(a),o}_readInlinedValue(e){let t=e.typeEnum,n=e.getInlinedValue(),r=this._conversionView;switch(t){case $.Bool:return n!==0;case $.UChar:return n&255;case $.Int:case $.UInt:return n;case $.Float:return r.setUint32(0,n,!0),r.getFloat32(0,!0);case $.Double:return r.setUint32(0,n,!0),r.getFloat32(0,!0);case $.Token:return this.tokens[n]||``;case $.String:return this.tokens[this.strings[n]]||``;case $.AssetPath:return this.tokens[n]||``;case $.Specifier:return n;case $.Permission:case $.Variability:return n;case $.Vec2h:return r.setUint32(0,n,!0),[this._halfToFloat(r.getUint16(0,!0)),this._halfToFloat(r.getUint16(2,!0))];case $.Vec2f:case $.Vec2i:return r.setUint32(0,n,!0),[r.getInt8(0),r.getInt8(1)];case $.Vec3f:case $.Vec3i:return r.setUint32(0,n,!0),[r.getInt8(0),r.getInt8(1),r.getInt8(2)];case $.Vec4f:case $.Vec4i:return r.setUint32(0,n,!0),[r.getInt8(0),r.getInt8(1),r.getInt8(2),r.getInt8(3)];case $.Matrix2d:return r.setUint32(0,n,!0),[r.getInt8(0),0,0,r.getInt8(1)];case $.Matrix3d:return r.setUint32(0,n,!0),[r.getInt8(0),0,0,0,r.getInt8(1),0,0,0,r.getInt8(2)];case $.Matrix4d:return r.setUint32(0,n,!0),[r.getInt8(0),0,0,0,0,r.getInt8(1),0,0,0,0,r.getInt8(2),0,0,0,0,r.getInt8(3)];default:return n}}_readTimeSamples(e){let t=this.reader,n=e.payload,r=t.tell();t.seek(n);let i=t.tell(),a=t.readInt64();t.seek(i+a);let o=new sd(t.readUint32(),t.readUint32()),s=this._readValue(o),c=i+a+8;t.seek(c);let l=t.tell(),u=t.readInt64();t.seek(l+u);let d=t.readUint64(),f=[];for(let e=0;e<d;e++){let e=t.readUint32(),n=t.readUint32();f.push(new sd(e,n))}let p=[];for(let e=0;e<d;e++)p.push(this._readValue(f[e]));return t.seek(r),{times:s instanceof Float64Array?Array.from(s):Array.isArray(s)?s:[s],values:p}}_readScalarValue(e){let t=this.reader;switch(e){case $.Invalid:return null;case $.Bool:return t.readUint8()!==0;case $.UChar:return t.readUint8();case $.Int:return t.readInt32();case $.UInt:return t.readUint32();case $.Int64:return t.readInt64();case $.UInt64:return t.readUint64();case $.Half:return this._readHalf();case $.Float:return t.readFloat32();case $.Double:return t.readFloat64();case $.String:case $.Token:{let e=t.readUint32();return this.tokens[e]||``}case $.AssetPath:{let e=t.readUint32();return this.tokens[e]||``}case $.Vec2f:return[t.readFloat32(),t.readFloat32()];case $.Vec2d:return[t.readFloat64(),t.readFloat64()];case $.Vec2i:return[t.readInt32(),t.readInt32()];case $.Vec3f:return[t.readFloat32(),t.readFloat32(),t.readFloat32()];case $.Vec3d:return[t.readFloat64(),t.readFloat64(),t.readFloat64()];case $.Vec3i:return[t.readInt32(),t.readInt32(),t.readInt32()];case $.Vec4f:return[t.readFloat32(),t.readFloat32(),t.readFloat32(),t.readFloat32()];case $.Vec4d:return[t.readFloat64(),t.readFloat64(),t.readFloat64(),t.readFloat64()];case $.Quatf:return[t.readFloat32(),t.readFloat32(),t.readFloat32(),t.readFloat32()];case $.Quatd:return[t.readFloat64(),t.readFloat64(),t.readFloat64(),t.readFloat64()];case $.Matrix4d:{let e=[];for(let n=0;n<16;n++)e.push(t.readFloat64());return e}case $.TokenVector:{let e=t.readUint64(),n=[];for(let r=0;r<e;r++){let e=t.readUint32();n.push(this.tokens[e]||``)}return n}case $.PathVector:{let e=t.readUint64(),n=[];for(let r=0;r<e;r++){let e=t.readUint32();n.push(this.paths[e]||``)}return n}case $.DoubleVector:{let e=t.readUint64(),n=new Float64Array(e);for(let r=0;r<e;r++)n[r]=t.readFloat64();return n}case $.Dictionary:{let e=t.readUint64(),n={};for(let r=0;r<e;r++){let e=t.readUint32(),r=this.tokens[e],i=t.position+t.readInt64(),a=t.position;t.position=i;let o=new sd(t.readUint64()),s=null;o.isInlined?s=this._readInlinedValue(o):o.isArray?(t.position=o.payload,s=this._readArrayValue(o)):(t.position=o.payload,s=this._readScalarValue(o.typeEnum)),t.position=a,r!==void 0&&s!==null&&(n[r]=s)}return n}case $.TokenListOp:case $.StringListOp:case $.IntListOp:case $.Int64ListOp:case $.UIntListOp:case $.UInt64ListOp:return null;case $.PathListOp:{let e=t.readUint8(),n=(e&2)!=0,r=(e&4)!=0,i=(e&8)!=0,a=(e&16)!=0,o=(e&32)!=0,s=(e&64)!=0,c=()=>{let e=t.readUint64(),n=[];for(let r=0;r<e;r++){let e=t.readUint32();n.push(this.paths[e])}return n},l=null,u=null,d=null,f=null;return n&&(l=c()),r&&(u=c()),o&&(d=c()),s&&(f=c()),i&&c(),a&&c(),d&&d.length>0?d:l&&l.length>0?l:f&&f.length>0?f:u&&u.length>0?u:null}case $.VariantSelectionMap:{let e=t.readUint64(),n={};for(let r=0;r<e;r++){let e=t.readUint32(),r=t.readUint32(),i=this.tokens[this.strings[e]],a=this.tokens[this.strings[r]];i&&a&&(n[i]=a)}return n}default:return console.warn(`USDCParser: Unsupported scalar type`,e),null}}_readArrayValue(e){let t=this.reader,n=e.typeEnum,r=e.isCompressed,i;if(i=this.version.major===0&&this.version.minor<7?t.readUint32():t.readUint64(),!Number.isSafeInteger(i)||i<0)throw RangeError(`USDCParser: Invalid array size `+i+` for type `+n+`.`);if(i>2147483647)throw RangeError(`USDCParser: Array size `+i+` exceeds implementation limits.`);if(i===0)return[];if(r)return this._readCompressedArray(n,i);switch(n){case $.Int:{let e=new Int32Array(i);for(let n=0;n<i;n++)e[n]=t.readInt32();return e}case $.UInt:{let e=new Uint32Array(i);for(let n=0;n<i;n++)e[n]=t.readUint32();return e}case $.Float:{let e=new Float32Array(i);for(let n=0;n<i;n++)e[n]=t.readFloat32();return e}case $.Double:{let e=new Float64Array(i);for(let n=0;n<i;n++)e[n]=t.readFloat64();return e}case $.Vec2f:{let e=new Float32Array(i*2);for(let n=0;n<i*2;n++)e[n]=t.readFloat32();return e}case $.Vec3f:{let e=new Float32Array(i*3);for(let n=0;n<i*3;n++)e[n]=t.readFloat32();return e}case $.Vec4f:{let e=new Float32Array(i*4);for(let n=0;n<i*4;n++)e[n]=t.readFloat32();return e}case $.Vec3h:{let e=new Float32Array(i*3);for(let t=0;t<i*3;t++)e[t]=this._readHalf();return e}case $.Quatf:{let e=new Float32Array(i*4);for(let n=0;n<i*4;n++)e[n]=t.readFloat32();return e}case $.Quath:{let e=new Float32Array(i*4);for(let t=0;t<i*4;t++)e[t]=this._readHalf();return e}case $.Matrix4d:{let e=new Float64Array(i*16);for(let n=0;n<i*16;n++)e[n]=t.readFloat64();return e}case $.Token:{let e=[];for(let n=0;n<i;n++){let n=t.readUint32();e.push(this.tokens[n]||``)}return e}case $.Half:{let e=new Float32Array(i);for(let t=0;t<i;t++)e[t]=this._readHalf();return e}default:return console.warn(`USDCParser: Unsupported array type`,n),[]}}_readCompressedArray(e,t){let n=this.reader;switch(e){case $.Int:case $.UInt:{let e=n.readUint64(),r=n.readBytes(e);return Qu(r.buffer.slice(r.byteOffset,r.byteOffset+e),t)}case $.Float:{let e=n.readInt8();if(e===id){let e=n.readUint64(),r=n.readBytes(e),i=Qu(r.buffer.slice(r.byteOffset,r.byteOffset+e),t),a=new Float32Array(t);for(let e=0;e<t;e++)a[e]=i[e];return a}else if(e===ad){let e=n.readUint32(),r=new Float32Array(e);for(let t=0;t<e;t++)r[t]=n.readFloat32();let i=n.readUint64(),a=n.readBytes(i),o=Qu(a.buffer.slice(a.byteOffset,a.byteOffset+i),t),s=new Float32Array(t);for(let e=0;e<t;e++)s[e]=r[o[e]];return s}return console.warn(`USDCParser: Unknown float compression code`,e),new Float32Array(t)}default:return console.warn(`USDCParser: Unsupported compressed array type`,e),[]}}_readHalf(){return this._halfToFloat(this.reader.readUint16())}_halfToFloat(e){let t=(e&32768)>>15,n=(e&31744)>>10,r=e&1023;return n===0?r===0?t?-0:0:(t?-1:1)*nd*(r/1024):n===31?r?NaN:t?-1/0:1/0:(t?-1:1)*td[n]*(1+r/1024)}_getFieldsForSpec(e){let t={},n=e.fieldSetIndex,r=0;for(;n<this.fieldSets.length&&r<1e4;){let e=this.fieldSets[n];if(e===rd||e===-1)break;let i=this.fields[e];if(i){let e=this.tokens[i.tokenIndex];t[e]=this._readValue(i.valueRep)}n++,r++}return t}}})),ud,dd,fd,pd,md=t((()=>{lo(),ud=/^(.+?)\/\{(\w+)=(\w+)\}\/(.+)$/,dd={Unknown:0,Attribute:1,Connection:2,Expression:3,Mapper:4,MapperArg:5,Prim:6,PseudoRoot:7,Relationship:8,RelationshipTarget:9,Variant:10,VariantSet:11},fd={projection:`perspective`,clippingRange:[1,1e6],horizontalAperture:20.955,verticalAperture:15.2908,horizontalApertureOffset:0,verticalApertureOffset:0,focalLength:50,focusDistance:0,fStop:0},pd=class e{constructor(e=null){this.textureCache={},this.skinnedMeshes=[],this.manager=e,this.texturePromises=[]}compose(e,t={},n={},r=``){this.specsByPath=e.specsByPath,this.assets=t,this.externalVariantSelections=n,this.basePath=r,this.skinnedMeshes=[],this.skeletons={},this.texturePromises=[],this._buildIndexes();let i=this.specsByPath[`/`],a=i?i.fields:{};this.fps=a.timeCodesPerSecond||a.framesPerSecond||24;let o=new vn;this._buildHierarchy(o,`/`),this._bindSkeletons();let s=Object.keys(this.skeletons);s.length===1&&(o.skeleton=this.skeletons[s[0]].skeleton),o.animations=this._buildAnimations();let c=a.metersPerUnit;return c!==void 0&&c!==1&&o.scale.setScalar(c),i&&i.fields&&i.fields.upAxis===`Z`&&(o.rotation.x=-Math.PI/2),o}applyTransform(e,t,n={}){let r={...t,...n},i=r.xformOpOrder;if(i&&i.length>0){let t=new K,n=new K,a=null;for(let e=0;e<i.length;e++){let o=i[e],s=o.startsWith(`!invert!`),c=s?o.slice(8):o;if(c===`xformOp:transform`){let e=r[`xformOp:transform`];e&&e.length===16&&(n.set(e[0],e[4],e[8],e[12],e[1],e[5],e[9],e[13],e[2],e[6],e[10],e[14],e[3],e[7],e[11],e[15]),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:translate`){let e=r[`xformOp:translate`];e&&(n.makeTranslation(e[0],e[1],e[2]),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:translate:pivot`){let e=r[`xformOp:translate:pivot`];e&&(n.makeTranslation(e[0],e[1],e[2]),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:scale`){let e=r[`xformOp:scale`];e&&(Array.isArray(e)?(n.makeScale(e[0],e[1],e[2]),a=[e[0],e[1],e[2]]):(n.makeScale(e,e,e),a=[e,e,e]),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:rotateXYZ`){let e=r[`xformOp:rotateXYZ`];if(e){let r=new $t(e[0]*Math.PI/180,e[1]*Math.PI/180,e[2]*Math.PI/180,`ZYX`);n.makeRotationFromEuler(r),s&&n.invert(),t.multiply(n)}}else if(c===`xformOp:rotateX`){let e=r[`xformOp:rotateX`];e!==void 0&&(n.makeRotationX(e*Math.PI/180),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:rotateY`){let e=r[`xformOp:rotateY`];e!==void 0&&(n.makeRotationY(e*Math.PI/180),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:rotateZ`){let e=r[`xformOp:rotateZ`];e!==void 0&&(n.makeRotationZ(e*Math.PI/180),s&&n.invert(),t.multiply(n))}else if(c===`xformOp:orient`){let e=r[`xformOp:orient`];if(e&&e.length===4){let r=new kt(e[0],e[1],e[2],e[3]);n.makeRotationFromQuaternion(r),s&&n.invert(),t.multiply(n)}}}if(e.matrix.copy(t),e.matrix.decompose(e.position,e.quaternion,e.scale),a){let t=a[0]<0,n=a[1]<0,r=a[2]<0;+!!t+ +!!n+ +!!r==3&&(e.scale.set(a[0],a[1],a[2]),e.quaternion.set(e.quaternion.x,-e.quaternion.y,e.quaternion.z,-e.quaternion.w))}return}if(r[`xformOp:translate`]){let t=r[`xformOp:translate`];e.position.set(t[0],t[1],t[2])}if(r[`xformOp:translate:pivot`]){let t=r[`xformOp:translate:pivot`];e.pivot=new W(t[0],t[1],t[2])}if(r[`xformOp:scale`]){let t=r[`xformOp:scale`];Array.isArray(t)?e.scale.set(t[0],t[1],t[2]):e.scale.set(t,t,t)}if(r[`xformOp:rotateXYZ`]){let t=r[`xformOp:rotateXYZ`];e.rotation.set(t[0]*Math.PI/180,t[1]*Math.PI/180,t[2]*Math.PI/180)}if(r[`xformOp:orient`]){let t=r[`xformOp:orient`];t.length===4&&e.quaternion.set(t[0],t[1],t[2],t[3])}}_buildIndexes(){this.childrenByPath=new Map,this.attributesByPrimPath=new Map,this.materialsByRoot=new Map,this.shadersByMaterialPath=new Map,this.geomSubsetsByMeshPath=new Map;for(let e in this.specsByPath){let t=this.specsByPath[e];if(t.specType===dd.Prim){let n=e.lastIndexOf(`/`);if(n>0){let t=e.slice(0,n),r=e.slice(n+1);this.childrenByPath.has(t)||this.childrenByPath.set(t,[]),this.childrenByPath.get(t).push({name:r,path:e})}else if(n===0&&e.length>1){let t=e.slice(1);this.childrenByPath.has(`/`)||this.childrenByPath.set(`/`,[]),this.childrenByPath.get(`/`).push({name:t,path:e})}let r=t.fields.typeName;if(r===`Material`){let t=e.split(`/`),n=t.length>1?`/`+t[1]:`/`;this.materialsByRoot.has(n)||this.materialsByRoot.set(n,[]),this.materialsByRoot.get(n).push(e)}if(r===`Shader`&&n>0){let t=e.slice(0,n);for(;t.length>0;){let n=this.specsByPath[t];if(n&&n.specType===dd.Prim&&n.fields.typeName===`Material`){this.shadersByMaterialPath.has(t)||this.shadersByMaterialPath.set(t,[]),this.shadersByMaterialPath.get(t).push(e);break}let r=t.lastIndexOf(`/`);if(r<=0)break;t=t.slice(0,r)}}if(r===`GeomSubset`&&n>0){let t=e.slice(0,n);this.geomSubsetsByMeshPath.has(t)||this.geomSubsetsByMeshPath.set(t,[]),this.geomSubsetsByMeshPath.get(t).push(e)}}else if(t.specType===dd.Attribute||t.specType===dd.Relationship){let n=e.lastIndexOf(`.`);if(n>0){let r=e.slice(0,n),i=e.slice(n+1);this.attributesByPrimPath.has(r)||this.attributesByPrimPath.set(r,new Map),this.attributesByPrimPath.get(r).set(i,t)}}}}_isDirectChild(e,t,n){if(!t.startsWith(n))return!1;let r=t.slice(n.length);return r.length===0||r.startsWith(`{`)?!1:!r.includes(`/`)}_buildHierarchy(e,t){let n=[],r=new Set,i=this.childrenByPath.get(t);if(i)for(let e of i)r.has(e.path)||(r.add(e.path),n.push(e));let a=this._getVariantPaths(t);for(let e of a){let t=this.childrenByPath.get(e);if(t)for(let e of t)r.has(e.path)||(r.add(e.path),n.push(e))}for(let{name:t,path:r}of n){let n=this.specsByPath[r];if(!n||n.specType!==dd.Prim)continue;let i=n.fields.typeName,a=this._getReferences(n);if(a.length>0){let o=this._getLocalVariantSelections(n.fields),s=[];for(let e of a){let t=this._resolveReference(e,o);t&&s.push(t)}if(s.length>0){let a=this._getAttributes(r);if(s.length===1){let o=this._findSingleMesh(s[0]);if(o&&(i===`Xform`||!i)){o.name=t,this.applyTransform(o,n.fields,a),this._applyMaterialBinding(o,r),e.add(o),this._buildHierarchy(o,r);continue}}let o=new _n;o.name=t,this.applyTransform(o,n.fields,a);for(let e of s)for(;e.children.length>0;)o.add(e.children[0]);e.add(o),this._buildHierarchy(o,r);continue}}if(i===`SkelRoot`){let i=new _n;i.name=t,i.userData.isSkelRoot=!0;let a=this._getAttributes(r);this.applyTransform(i,n.fields,a),e.add(i),this._buildHierarchy(i,r)}else if(i===`Skeleton`){let t=this._buildSkeleton(r);t&&(this.skeletons[r]=t),this._buildHierarchy(e,r)}else if(i!==`SkelAnimation`){if(i===`Mesh`){let t=this._buildMesh(r,n);t&&(e.add(t),this._buildHierarchy(t,r))}else if(i===`Camera`){let i=this._buildCamera(r);i.name=t;let a=this._getAttributes(r);this.applyTransform(i,n.fields,a),e.add(i),this._buildHierarchy(i,r)}else if(i===`DistantLight`||i===`SphereLight`||i===`RectLight`||i===`DiskLight`){let a=this._buildLight(r,i);a.name=t;let o=this._getAttributes(r);this.applyTransform(a,n.fields,o),e.add(a),this._buildHierarchy(a,r)}else if(i===`Cube`||i===`Sphere`||i===`Cylinder`||i===`Cone`||i===`Capsule`){let t=this._buildGeomPrimitive(r,n,i);t&&(e.add(t),this._buildHierarchy(t,r))}else if(!(i===`Material`||i===`Shader`||i===`GeomSubset`)){let i=new _n;i.name=t;let a=this._getAttributes(r);this.applyTransform(i,n.fields,a),e.add(i),this._buildHierarchy(i,r)}}}}_getVariantPaths(e){let t=this.specsByPath[e],n=t?.fields?.variantSetChildren,r=[];if(!n||n.length===0)return r;for(let i of n){let n=this.externalVariantSelections[i]||null;if(!n){let e=t.fields.variantSelection;n=e?e[i]:null}if(!n){let t=e+`/{`+i+`=}`,r=this.specsByPath[t];r?.fields?.variantChildren&&(n=r.fields.variantChildren[0])}if(n){let t=e+`/{`+i+`=`+n+`}`;r.push(t)}}return r}_resolveFilePath(e){let t=e;if(t.startsWith(`./`)&&(t=t.slice(2)),!this.basePath)return t;let n=this.basePath.endsWith(`/`)?this.basePath:this.basePath+`/`;return Wa.resolveURL(t,n)}_resolveReference(t,n={}){if(!t)return null;let r=t.match(/@([^@]+)@(?:<([^>]+)>)?/);if(!r)return null;let i=r[1],a=r[2],o=this._resolveFilePath(i),s={...n,...this.externalVariantSelections},c=this.assets[o];if(!c)return null;if(c.specsByPath){let t=new e(this.manager),n=this._getBasePath(o),r=t.compose(c,this.assets,s,n);if(a){let e=a.split(`/`).pop(),t=null;for(let n of r.children)if(n.name===e){t=n;break}if(t){r.remove(t);let e=new vn;return e.add(t),e}}return r}return c.isGroup||c.isObject3D?c.clone():null}_findSingleMesh(e){for(let t of e.children)if(t.isMesh)return e.remove(t),t;if(e.children.length===1){let t=e.children[0];if(t.children&&t.children.length===1){let e=t.children[0];if(e.isMesh&&!this._hasNonIdentityTransform(t))return t.remove(e),e}}return null}_hasNonIdentityTransform(e){let t=e.position,n=e.rotation,r=e.scale,i=t.x!==0||t.y!==0||t.z!==0,a=n.x!==0||n.y!==0||n.z!==0,o=r.x!==1||r.y!==1||r.z!==1;return i||a||o}_getBasePath(e){let t=e.lastIndexOf(`/`);return t>=0?e.slice(0,t):``}_getLocalVariantSelections(e){let t={};if(e.variantSelection)for(let n in e.variantSelection)t[n]=e.variantSelection[n];return t}_getReferences(e){let t=[];if(e.fields.references&&e.fields.references.length>0){let n=e.fields.references[0];if(typeof n==`string`){let e=n.matchAll(/@([^@]+)@(?:<([^>]+)>)?/g);for(let n of e)t.push(n[0])}else n.assetPath&&t.push(`@`+n.assetPath+`@`)}if(t.length===0&&e.fields.payload){let n=e.fields.payload;typeof n==`string`?t.push(n):n.assetPath&&t.push(`@`+n.assetPath+`@`)}return t}_getAttributes(e){let t={};this._collectAttributesFromPath(e,t);let n=e.match(ud);if(n){let r=n[1],i=n[4],a=this._getVariantPaths(r);for(let n of a){if(e.startsWith(n))continue;let r=n+`/`+i;this._collectAttributesFromPath(r,t)}}else{let n=e.split(`/`);for(let e=1;e<n.length-1;e++){let r=n.slice(0,e+1).join(`/`),i=n.slice(e+1).join(`/`),a=this._getVariantPaths(r);for(let e of a){let n=e+`/`+i;this._collectAttributesFromPath(n,t)}}}return t}_collectAttributesFromPath(e,t){let n=this.attributesByPrimPath.get(e);if(n)for(let[e,r]of n){if(r.fields?.default!==void 0)t[e]=r.fields.default;else if(r.fields?.timeSamples){let{times:n,values:i}=r.fields.timeSamples;if(n&&i&&n.length>0){let r=n.indexOf(0);t[e]=r>=0?i[r]:i[0]}}r.fields?.elementSize!==void 0&&(t[e+`:elementSize`]=r.fields.elementSize),e.startsWith(`primvars:`)&&r.fields?.typeName!==void 0&&(t[e+`:typeName`]=r.fields.typeName)}}_buildGeomPrimitive(e,t,n){let r=this._getAttributes(e),i=e.split(`/`).pop(),a;switch(n){case`Cube`:{let e=r.size||2;a=new zi(e,e,e);break}case`Sphere`:a=new Ki(r.radius||1,32,16);break;case`Cylinder`:{let e=r.height||2,t=r.radius||1;a=new Vi(t,t,e,32);break}case`Cone`:{let e=r.height||2;a=new Hi(r.radius||1,e,32);break}case`Capsule`:{let e=r.height||1;a=new Bi(r.radius||.5,e,16,32);break}}let o=r.axis||`Z`;o===`X`?a.rotateZ(-Math.PI/2):o===`Z`&&a.rotateX(Math.PI/2);let s=this._buildMaterial(e,t.fields),c=new Vr(a,s);return c.name=i,this.applyTransform(c,t.fields,r),c}_buildMesh(e,t){let n=this._getAttributes(e),r=n[`primvars:skel:jointIndices`],i=n[`primvars:skel:jointWeights`],a=r&&i&&r.length>0&&i.length>0,o=this._getGeomSubsets(e),s,c;if(o.length>0){s=this._buildGeometryWithSubsets(n,o,a);let r=this._getMaterialPath(e,t.fields);c=o.map(e=>{let t=e.materialPath||r;return this._buildMaterialForPath(t)})}else s=this._buildGeometry(e,n,a),c=this._buildMaterial(e,t.fields);let l=n[`primvars:displayColor`];if(l&&l.length>=3){let e=e=>{e.color&&e.color.r===1&&e.color.g===1&&e.color.b===1&&!e.map&&e.color.setRGB(l[0],l[1],l[2],H)};Array.isArray(c)?c.forEach(e):e(c)}let u=n[`primvars:displayOpacity`];if(u&&u.length===1&&o.length===0){let e=u[0],t=t=>{e<1&&t.opacity===1&&t.transparent===!1&&(t.opacity=e,t.transparent=!0)};Array.isArray(c)?c.forEach(t):t(c)}let d;if(a){d=new Zr(s,c);let t=this.specsByPath[e+`.skel:skeleton`];t||=this.specsByPath[e+`.rel skel:skeleton`];let r=null;t&&(t.fields.targetPaths&&t.fields.targetPaths.length>0?r=t.fields.targetPaths[0]:t.fields.default&&(r=t.fields.default.replace(/<|>/g,``)));let i=n[`skel:joints`],a=n[`primvars:skel:geomBindTransform`];this.skinnedMeshes.push({mesh:d,skeletonPath:r,path:e,localJoints:i,geomBindTransform:a})}else d=new Vr(s,c);return d.name=e.split(`/`).pop(),this.applyTransform(d,t.fields,n),d}_buildCamera(e){let t=this._getAttributes(e),n=t.projection,r=typeof n==`string`?n.toLowerCase():fd.projection,i=t.clippingRange||fd.clippingRange,a=Math.max(2**-52,this._parseNumber(i[0],fd.clippingRange[0])),o=Math.max(a+2**-52,this._parseNumber(i[1],fd.clippingRange[1])),s=this._parseNumber(t.horizontalAperture,fd.horizontalAperture),c=this._parseNumber(t.verticalAperture,fd.verticalAperture),l=this._parseNumber(t.horizontalApertureOffset,fd.horizontalApertureOffset),u=this._parseNumber(t.verticalApertureOffset,fd.verticalApertureOffset),d=this._parseNumber(t.focalLength,fd.focalLength),f=this._parseNumber(t.focusDistance,fd.focusDistance),p=this._parseNumber(t.fStop,fd.fStop),m;if(r===`orthographic`){let e=s/10,t=c/10,n=l/10,r=u/10;m=new za(n-e*.5,n+e*.5,r+t*.5,r-t*.5,a,o)}else{let e=Math.max(2**-52,c),t=Math.max(2**-52,d),n=s/e;m=new Pa(2*Math.atan(e/(2*t))*180/Math.PI,n,a,o),m.filmGauge=Math.max(s,c),m.filmOffset=l,m.focus=f,m.setFocalLength(t),u!==0&&(m.userData.verticalApertureOffset=u)}return m.userData.fStop=p,m.userData.usdProjection=r,m}_buildLight(e,t){let n=this._getAttributes(e),r=this._parseNumber(n[`inputs:intensity`],1),i=n[`inputs:color`]||[1,1,1],a=n[`inputs:enableColorTemperature`]===!0,o=this._parseNumber(n[`inputs:colorTemperature`],6500),s=new q(i[0],i[1],i[2]);if(a){let e=this._colorTemperature(o);s.multiply(e)}let c;switch(t){case`DistantLight`:c=new Va(s,r);break;case`SphereLight`:{let e=this._parseNumber(n[`shaping:cone:angle`],0);c=e>0?new Ia(s,r,0,e*Math.PI/180,this._parseNumber(n[`shaping:cone:softness`],0)):new Ra(s,r);break}case`RectLight`:c=new Ua(s,r,this._parseNumber(n[`inputs:width`],1),this._parseNumber(n[`inputs:height`],1));break;case`DiskLight`:{let e=this._parseNumber(n[`inputs:radius`],.5)*2;c=new Ua(s,r,e,e);break}}return c}_colorTemperature(e){let t=e/100,n,r,i;return t<=66?(n=1,r=.3900815787690196*Math.log(t)-.6318414437886275):(n=1.292936186062745*(t-60)**-.1332047592,r=1.1298908608952942*(t-60)**-.0755148492),i=t>=66?1:t<=19?0:.543206789110196*Math.log(t-10)-1.19625408914,new q(Math.min(Math.max(n,0),1),Math.min(Math.max(r,0),1),Math.min(Math.max(i,0),1))}_parseNumber(e,t){let n=Number(e);return Number.isFinite(n)?n:t}_getGeomSubsets(e){let t=[],n=this.geomSubsetsByMeshPath.get(e);if(!n)return t;for(let e of n){let n=this._getAttributes(e).indices;if(!n||n.length===0)continue;let r=this._getMaterialBindingTarget(e);t.push({name:e.split(`/`).pop(),indices:n,materialPath:r})}return t}_getMaterialBindingTarget(e){let t=e+`.material:binding`,n=this.specsByPath[t];if(n?.fields?.targetPaths?.length>0)return n.fields.targetPaths[0];let r=e.split(`/`);for(let e=1;e<r.length;e++){let t=r.slice(0,e+1).join(`/`),n=r.slice(e+1).join(`/`),i=this._getVariantPaths(t);for(let e of i){let t=n?e+`/`+n+`.material:binding`:e+`.material:binding`,r=this.specsByPath[t];if(r?.fields?.targetPaths?.length>0)return r.fields.targetPaths[0]}}return null}_buildGeometry(e,t,n=!1){let r=new hr,i=t.points;if(!i||i.length===0)return r;let a=t.faceVertexIndices,o=t.faceVertexCounts,s=t[`primvars:arnold:polygon_holes`],c=this._buildHoleMap(s),l=a,u=null;if(o&&o.length>0){let e=this._triangulateIndicesWithPattern(a,o,i,c);l=e.indices,u=e.pattern}let d=i;l&&l.length>0&&(d=this._expandAttribute(i,l,3)),r.setAttribute(`position`,new tr(new Float32Array(d),3));let f=t.normals||t[`primvars:normals`],p=t[`normals:indices`]||t[`primvars:normals:indices`];if(f&&f.length>0){let e=f;if(p&&p.length>0&&u){let t=this._applyTriangulationPattern(p,u);e=this._expandAttribute(f,t,3)}else if(f.length===i.length)l&&l.length>0&&(e=this._expandAttribute(f,l,3));else if(u){let t=this._applyTriangulationPattern(Array.from({length:f.length/3},(e,t)=>t),u);e=this._expandAttribute(f,t,3)}r.setAttribute(`normal`,new tr(new Float32Array(e),3))}else{let e=this._computeVertexNormals(i,l);r.setAttribute(`normal`,new tr(new Float32Array(this._expandAttribute(e,l,3)),3))}let{uvs:m,uvIndices:h}=this._findUVPrimvar(t),g=a?a.length:0;if(m&&m.length>0){let e=m;if(h&&h.length>0&&u){let t=this._applyTriangulationPattern(h,u);e=this._expandAttribute(m,t,2)}else if(l&&m.length/2==i.length/3)e=this._expandAttribute(m,l,2);else if(u&&m.length/2===g){let t=this._applyTriangulationPattern(Array.from({length:g},(e,t)=>t),u);e=this._expandAttribute(m,t,2)}r.setAttribute(`uv`,new tr(new Float32Array(e),2))}let{uvs2:_,uv2Indices:v}=this._findUV2Primvar(t);if(_&&_.length>0){let e=_;if(v&&v.length>0&&u){let t=this._applyTriangulationPattern(v,u);e=this._expandAttribute(_,t,2)}else if(l&&_.length/2==i.length/3)e=this._expandAttribute(_,l,2);else if(u&&_.length/2===g){let t=this._applyTriangulationPattern(Array.from({length:g},(e,t)=>t),u);e=this._expandAttribute(_,t,2)}r.setAttribute(`uv1`,new tr(new Float32Array(e),2))}if(n){let e=t[`primvars:skel:jointIndices`],n=t[`primvars:skel:jointWeights`],i=t[`primvars:skel:jointIndices:elementSize`]||4;if(e&&n){let t=d.length/3,a,o;l&&l.length>0?(a=this._expandAttribute(e,l,i),o=this._expandAttribute(n,l,i)):(a=e,o=n);let s=new Uint16Array(t*4),c=new Float32Array(t*4);this._selectTopWeights(a,o,i,t,s,c),r.setAttribute(`skinIndex`,new tr(s,4)),r.setAttribute(`skinWeight`,new tr(c,4))}}return r}_buildGeometryWithSubsets(e,t,n=!1){let r=new hr,i=e.points;if(!i||i.length===0)return r;let a=e.faceVertexIndices,o=e.faceVertexCounts;if(!o||o.length===0)return r;let s=e[`primvars:arnold:polygon_holes`],c=this._buildHoleMap(s),l=c.holeFaces,u=c.parentToHoles,{uvs:d,uvIndices:f}=this._findUVPrimvar(e),{uvs2:p,uv2Indices:m}=this._findUV2Primvar(e),h=e.normals||e[`primvars:normals`],g=e[`normals:indices`]||e[`primvars:normals:indices`],_=n?e[`primvars:skel:jointIndices`]:null,v=n?e[`primvars:skel:jointWeights`]:null,y=e[`primvars:skel:jointIndices:elementSize`]||4,b=[],x=0;for(let e=0;e<o.length;e++){if(b.push(x),l.has(e))continue;let t=o[e],n=u.get(e);if(n&&n.length>0){let e=t;for(let t of n)e+=o[t];x+=e-2}else t>=3&&(x+=t-2)}let S=new Int32Array(x).fill(-1);for(let e=0;e<t.length;e++){let n=t[e];for(let t=0;t<n.indices.length;t++){let r=n.indices[t];if(r>=o.length)continue;let i=b[r],a=o[r]-2;for(let t=0;t<a;t++)S[i+t]=e}}let C=[];for(let e=0;e<x;e++)C.push({original:e,subset:S[e]});C.sort((e,t)=>e.subset-t.subset);let w=[],T=C.length>0?C[0].subset:-1,E=0;for(let e=0;e<C.length;e++)C[e].subset!==T&&(T>=0&&w.push({start:E*3,count:(e-E)*3,materialIndex:T}),T=C[e].subset,E=e);T>=0&&C.length>E&&w.push({start:E*3,count:(C.length-E)*3,materialIndex:T});for(let e of w)r.addGroup(e.start,e.count,e.materialIndex);let{indices:D,pattern:O}=this._triangulateIndicesWithPattern(a,o,i,c),ee=o.reduce((e,t)=>e+t,0),k=d&&!f&&d.length/2===ee||p&&!m&&p.length/2===ee?this._applyTriangulationPattern(Array.from({length:ee},(e,t)=>t),O):null,te=f?this._applyTriangulationPattern(f,O):d&&d.length/2===ee?k:null,A=m?this._applyTriangulationPattern(m,O):p&&p.length/2===ee?k:null,j=h&&g&&g.length>0,ne=h&&h.length/3===ee,M=j?this._applyTriangulationPattern(g,O):ne?this._applyTriangulationPattern(Array.from({length:ee},(e,t)=>t),O):null,N=!h&&D.length>0?this._computeVertexNormals(i,D):null,P=x*3,F=new Float32Array(P*3),I=d?new Float32Array(P*2):null,re=p?new Float32Array(P*2):null,L=h||N?new Float32Array(P*3):null,R=_?new Uint16Array(P*y):null,z=v?new Float32Array(P*y):null;for(let e=0;e<C.length;e++){let t=C[e].original;for(let n=0;n<3;n++){let r=t*3+n,a=e*3+n,o=D[r];if(F[a*3]=i[o*3],F[a*3+1]=i[o*3+1],F[a*3+2]=i[o*3+2],I&&d)if(te){let e=te[r];I[a*2]=d[e*2],I[a*2+1]=d[e*2+1]}else d.length/2==i.length/3&&(I[a*2]=d[o*2],I[a*2+1]=d[o*2+1]);if(re&&p)if(A){let e=A[r];re[a*2]=p[e*2],re[a*2+1]=p[e*2+1]}else p.length/2==i.length/3&&(re[a*2]=p[o*2],re[a*2+1]=p[o*2+1]);if(L)if(h&&M){let e=M[r];L[a*3]=h[e*3],L[a*3+1]=h[e*3+1],L[a*3+2]=h[e*3+2]}else h&&h.length===i.length?(L[a*3]=h[o*3],L[a*3+1]=h[o*3+1],L[a*3+2]=h[o*3+2]):N&&(L[a*3]=N[o*3],L[a*3+1]=N[o*3+1],L[a*3+2]=N[o*3+2]);if(R&&z&&_&&v)for(let e=0;e<y;e++)R[a*y+e]=_[o*y+e]||0,z[a*y+e]=v[o*y+e]||0}}if(r.setAttribute(`position`,new tr(F,3)),I&&r.setAttribute(`uv`,new tr(I,2)),re&&r.setAttribute(`uv1`,new tr(re,2)),r.setAttribute(`normal`,new tr(L,3)),R&&z){let e=new Uint16Array(P*4),t=new Float32Array(P*4);this._selectTopWeights(R,z,y,P,e,t),r.setAttribute(`skinIndex`,new tr(e,4)),r.setAttribute(`skinWeight`,new tr(t,4))}return r}_selectTopWeights(e,t,n,r,i,a){if(n<=4){for(let o=0;o<r;o++)for(let r=0;r<4;r++)r<n?(i[o*4+r]=e[o*n+r]||0,a[o*4+r]=t[o*n+r]||0):(i[o*4+r]=0,a[o*4+r]=0);return}let o=new Uint32Array(n);for(let s=0;s<r;s++){let r=s*n;for(let e=0;e<n;e++)o[e]=e;for(let e=0;e<4;e++){let i=e,a=t[r+o[e]]||0;for(let s=e+1;s<n;s++){let e=t[r+o[s]]||0;e>a&&(a=e,i=s)}if(i!==e){let t=o[e];o[e]=o[i],o[i]=t}}let c=0;for(let e=0;e<4;e++)c+=t[r+o[e]]||0;for(let n=0;n<4;n++){let l=o[n];c>0?(i[s*4+n]=e[r+l]||0,a[s*4+n]=(t[r+l]||0)/c):(i[s*4+n]=0,a[s*4+n]=0)}}}_findUVPrimvar(e){for(let t in e){if(!t.startsWith(`primvars:`)||t.endsWith(`:typeName`)||t.endsWith(`:elementSize`)||t.endsWith(`:indices`)||t.includes(`skel:`))continue;let n=e[t+`:typeName`];if(n&&n.includes(`texCoord`))return{uvs:e[t],uvIndices:e[t+`:indices`]}}return{uvs:e[`primvars:st`]||e[`primvars:UVMap`],uvIndices:e[`primvars:st:indices`]}}_findUV2Primvar(e){return{uvs2:e[`primvars:st1`],uv2Indices:e[`primvars:st1:indices`]}}_buildHoleMap(e){if(!e||e.length===0)return{parentToHoles:new Map,holeFaces:new Set};let t=new Map,n=new Set;for(let r=0;r<e.length;r+=2){let i=e[r],a=e[r+1];n.add(i),t.has(a)||t.set(a,[]),t.get(a).push(i)}return{parentToHoles:t,holeFaces:n}}_triangulateIndicesWithPattern(e,t,n=null,r=null){let i=[],a=[],o=[],s=0;for(let e=0;e<t.length;e++)o.push(s),s+=t[e];let c=r?.parentToHoles||new Map,l=r?.holeFaces||new Set,u=0;for(let r=0;r<t.length;r++){let s=t[r];if(l.has(r)){u+=s;continue}let d=c.get(r);if(d&&d.length>0&&n&&n.length>0){let r=new Map,c=[];for(let t=0;t<s;t++){let n=e[u+t];c.push(n),r.set(n,u+t)}let l=[];for(let n of d){let i=o[n],a=t[n],s=[];for(let t=0;t<a;t++){let n=e[i+t];s.push(n),r.set(n,i+t)}l.push(s)}let f=this._triangulateNGonWithHoles(c,l,n);for(let e of f)i.push(e[0],e[1],e[2]),a.push(r.get(e[0]),r.get(e[1]),r.get(e[2]))}else if(s===3)i.push(e[u],e[u+1],e[u+2]),a.push(u,u+1,u+2);else if(s===4)i.push(e[u],e[u+1],e[u+2],e[u],e[u+2],e[u+3]),a.push(u,u+1,u+2,u,u+2,u+3);else if(s>4)if(n&&n.length>0){let t=[];for(let n=0;n<s;n++)t.push(e[u+n]);let r=this._triangulateNGon(t,n);for(let e of r)i.push(e[0],e[1],e[2]),a.push(u+t.indexOf(e[0]),u+t.indexOf(e[1]),u+t.indexOf(e[2]))}else for(let t=1;t<s-1;t++)i.push(e[u],e[u+t],e[u+t+1]),a.push(u,u+t,u+t+1);u+=s}return{indices:i,pattern:a}}_applyTriangulationPattern(e,t){let n=[];for(let r=0;r<t.length;r++)n.push(e[t[r]]);return n}_triangulateNGon(e,t){let n=[],r=[];for(let n of e)r.push(new W(t[n*3],t[n*3+1],t[n*3+2]));let i=new W;for(let e=0;e<r.length;e++){let t=r[e],n=r[(e+1)%r.length];i.x+=(t.y-n.y)*(t.z+n.z),i.y+=(t.z-n.z)*(t.x+n.x),i.z+=(t.x-n.x)*(t.y+n.y)}i.normalize();let a=new W,o=new W;Math.abs(i.y)>.9?a.set(1,0,0):a.set(0,1,0),o.crossVectors(i,a).normalize(),a.crossVectors(o,i).normalize();for(let e of r)n.push(new U(e.dot(a),e.dot(o)));let s=Gi.triangulateShape(n,[]),c=[];for(let t of s)c.push([e[t[0]],e[t[1]],e[t[2]]]);return c}_triangulateNGonWithHoles(e,t,n){let r=[];for(let t of e)r.push(new W(n[t*3],n[t*3+1],n[t*3+2]));let i=new W;for(let e=0;e<r.length;e++){let t=r[e],n=r[(e+1)%r.length];i.x+=(t.y-n.y)*(t.z+n.z),i.y+=(t.z-n.z)*(t.x+n.x),i.z+=(t.x-n.x)*(t.y+n.y)}i.normalize();let a=new W,o=new W;Math.abs(i.y)>.9?a.set(1,0,0):a.set(0,1,0),o.crossVectors(i,a).normalize(),a.crossVectors(o,i).normalize();let s=[];for(let e of r)s.push(new U(e.dot(a),e.dot(o)));let c=[];for(let e of t){let t=[];for(let r of e){let e=new W(n[r*3],n[r*3+1],n[r*3+2]);t.push(new U(e.dot(a),e.dot(o)))}c.push(t)}let l=[...e];for(let e of t)l.push(...e);let u=Gi.triangulateShape(s,c),d=[];for(let e of u)d.push([l[e[0]],l[e[1]],l[e[2]]]);return d}_triangulateIndices(e,t){let n=[],r=0;for(let i=0;i<t.length;i++){let a=t[i];if(a===3)n.push(e[r],e[r+1],e[r+2]);else if(a===4)n.push(e[r],e[r+1],e[r+2],e[r],e[r+2],e[r+3]);else if(a>4)for(let t=1;t<a-1;t++)n.push(e[r],e[r+t],e[r+t+1]);r+=a}return n}_expandAttribute(e,t,n){let r=Array(t.length*n);for(let i=0;i<t.length;i++){let a=t[i];for(let t=0;t<n;t++)r[i*n+t]=e[a*n+t]}return r}_computeVertexNormals(e,t){let n=e.length/3,r=new Float32Array(n*3);for(let n=0;n<t.length;n+=3){let i=t[n],a=t[n+1],o=t[n+2],s=e[i*3],c=e[i*3+1],l=e[i*3+2],u=e[a*3],d=e[a*3+1],f=e[a*3+2],p=e[o*3],m=e[o*3+1],h=e[o*3+2],g=u-s,_=d-c,v=f-l,y=p-s,b=m-c,x=h-l,S=_*x-v*b,C=v*y-g*x,w=g*b-_*y;r[i*3]+=S,r[i*3+1]+=C,r[i*3+2]+=w,r[a*3]+=S,r[a*3+1]+=C,r[a*3+2]+=w,r[o*3]+=S,r[o*3+1]+=C,r[o*3+2]+=w}for(let e=0;e<n;e++){let t=r[e*3],n=r[e*3+1],i=r[e*3+2],a=Math.sqrt(t*t+n*n+i*i);a>0&&(r[e*3]/=a,r[e*3+1]/=a,r[e*3+2]/=a)}return r}_getMaterialPath(e,t){let n=null,r=t[`material:binding`];return r&&(n=Array.isArray(r)?r[0]:r),n||=this._getMaterialBindingTarget(e),n}_buildMaterial(e,t){let n=new Ji,r=null,i=t[`material:binding`];if(i&&(r=Array.isArray(i)?i[0]:i),r||=this._getMaterialBindingTarget(e),!r){let t=[],n=e+`/`;for(let e in this.specsByPath){if(!e.startsWith(n)||!e.endsWith(`.material:binding`))continue;let r=this.specsByPath[e];if(!r)continue;let i=r.fields.targetPaths;i&&i.length>0&&t.push(i[0])}t.length>0&&(r=this._pickBestMaterial(t))}if(!r){let t=`/`+e.split(`/`)[1],n=this.materialsByRoot.get(t);if(n){for(let e of n)if(e.startsWith(t+`/Looks/`)||e.startsWith(t+`/Materials/`)){r=e;break}}}return r&&this._applyMaterial(n,r),n}_buildMaterialForPath(e){let t=new Ji;return e&&this._applyMaterial(t,e),t}_applyMaterialBinding(e,t){let n=t+`.material:binding`,r=this.specsByPath[n];if(!r)return;let i=null,a=r.fields?.targetPaths||r.fields?.default;if(a&&(i=Array.isArray(a)?a[0]:a),!i)return;i=String(i).replace(/^<|>$/g,``);let o=new Ji;this._applyMaterial(o,i),e.material=o}_pickBestMaterial(e){for(let t of e){let e=this.shadersByMaterialPath.get(t);if(e)for(let n of e){let e=this._getAttributes(n);if(e[`info:id`]===`UsdUVTexture`&&e[`inputs:file`])return t}}return e[0]}_applyMaterial(e,t){if(!this.specsByPath[t])return;let n=this.shadersByMaterialPath.get(t);if(n)for(let t of n){let n=this.specsByPath[t];if(!n)continue;let r=this._getAttributes(t)[`info:id`]||n.fields[`info:id`];r===`UsdPreviewSurface`||r===`ND_UsdPreviewSurface_surfaceshader`?this._applyPreviewSurface(e,t):r===`arnold:openpbr_surface`&&this._applyOpenPBRSurface(e,t)}}_applyTextureOrValue(e,t,n,r,i,a,o,s){let c=t+`.`+r,l=this.specsByPath[c];if(l&&l.fields.connectionPaths&&l.fields.connectionPaths.length>0){let t=s===this._getTextureFromOpenPBRConnection?l.fields.connectionPaths:[l.fields.connectionPaths[0]];for(let n of t){let t=s.call(this,n);if(t)return t.colorSpace=a,e[i]=t,!0}}return n[r]!==void 0&&o&&o(n[r]),!1}_applyPreviewSurface(e,t){let n=this._getAttributes(t),r=(r,i,a,o)=>this._applyTextureOrValue(e,t,n,r,i,a,o,this._getTextureFromConnection),i=e=>{let n=t+`.`+e;return this.specsByPath[n]};if(r(`inputs:diffuseColor`,`map`,H,t=>{Array.isArray(t)&&t.length>=3&&e.color.setRGB(t[0],t[1],t[2],H)}),e.map&&e.map.userData.scale){let t=e.map.userData.scale;Array.isArray(t)&&t.length>=3&&e.color.setRGB(t[0],t[1],t[2],H)}if(r(`inputs:emissiveColor`,`emissiveMap`,H,t=>{Array.isArray(t)&&t.length>=3&&e.emissive.setRGB(t[0],t[1],t[2],H)}),e.emissiveMap)if(e.emissiveMap.userData.scale){let t=e.emissiveMap.userData.scale;Array.isArray(t)&&t.length>=3&&e.emissive.setRGB(t[0],t[1],t[2],H)}else e.emissive.set(16777215);if(r(`inputs:normal`,`normalMap`,``,null),e.normalMap&&e.normalMap.userData.scale){let t=e.normalMap.userData.scale;e.normalScale=new U(t[0],t[1])}if(r(`inputs:roughness`,`roughnessMap`,``,t=>{e.roughness=t})&&(e.roughness=1),r(`inputs:metallic`,`metalnessMap`,``,t=>{e.metalness=t})&&(e.metalness=1),r(`inputs:occlusion`,`aoMap`,``,null),n[`inputs:ior`]!==void 0&&(e.ior=n[`inputs:ior`]),r(`inputs:specularColor`,`specularColorMap`,H,t=>{Array.isArray(t)&&t.length>=3&&e.specularColor.setRGB(t[0],t[1],t[2],H)}),e.specularColorMap&&e.specularColorMap.userData.scale){let t=e.specularColorMap.userData.scale;Array.isArray(t)&&t.length>=3&&e.specularColor.setRGB(t[0],t[1],t[2],H)}n[`inputs:clearcoat`]!==void 0&&(e.clearcoat=n[`inputs:clearcoat`]),n[`inputs:clearcoatRoughness`]!==void 0&&(e.clearcoatRoughness=n[`inputs:clearcoatRoughness`]);let a=n[`inputs:opacityThreshold`]===void 0?0:n[`inputs:opacityThreshold`];if(i(`inputs:opacity`)?.fields?.connectionPaths?.length>0)a>0?(e.alphaTest=a,e.transparent=!1):e.transparent=!0;else{let t=n[`inputs:opacity`]===void 0?1:n[`inputs:opacity`];t<1&&(e.transparent=!0,e.opacity=t)}}_applyOpenPBRSurface(e,t){let n=this._getAttributes(t),r=(r,i,a,o)=>this._applyTextureOrValue(e,t,n,r,i,a,o,this._getTextureFromOpenPBRConnection);if(r(`inputs:base_color`,`map`,H,t=>{Array.isArray(t)&&t.length>=3&&e.color.setRGB(t[0],t[1],t[2],H)}),e.map&&e.map.userData.scale){let t=e.map.userData.scale;Array.isArray(t)&&t.length>=3&&e.color.setRGB(t[0],t[1],t[2],H)}r(`inputs:base_metalness`,`metalnessMap`,``,t=>{typeof t==`number`&&(e.metalness=t)}),r(`inputs:specular_roughness`,`roughnessMap`,``,t=>{typeof t==`number`&&(e.roughness=t)});let i=r(`inputs:emission_color`,`emissiveMap`,H,t=>{Array.isArray(t)&&t.length>=3&&e.emissive.setRGB(t[0],t[1],t[2],H)}),a=n[`inputs:emission_luminance`];a!==void 0&&a>0&&(i?e.emissiveIntensity=a:e.emissive.multiplyScalar(a));let o=n[`inputs:transmission_weight`];if(o!==void 0&&o>0){e.transmission=o;let t=n[`inputs:transmission_depth`];t!==void 0&&(e.thickness=t);let r=n[`inputs:transmission_color`];r!==void 0&&Array.isArray(r)&&(e.attenuationColor.setRGB(r[0],r[1],r[2]),e.attenuationDistance=t||1)}let s=n[`inputs:geometry_opacity`];s!==void 0&&s<1&&(e.opacity=s,e.transparent=!0);let c=n[`inputs:specular_ior`];c!==void 0&&(e.ior=c);let l=n[`inputs:coat_weight`];if(l!==void 0&&l>0){e.clearcoat=l;let t=n[`inputs:coat_roughness`];t!==void 0&&(e.clearcoatRoughness=t)}let u=n[`inputs:thin_film_weight`];if(u!==void 0&&u>0){e.iridescence=u;let t=n[`inputs:thin_film_ior`];t!==void 0&&(e.iridescenceIOR=t);let r=n[`inputs:thin_film_thickness`];if(r!==void 0){let t=r*1e3;e.iridescenceThicknessRange=[t,t]}}let d=n[`inputs:specular_weight`];d!==void 0&&(e.specularIntensity=d);let f=n[`inputs:specular_color`];f!==void 0&&Array.isArray(f)&&e.specularColor.setRGB(f[0],f[1],f[2]);let p=n[`inputs:specular_roughness_anisotropy`];p!==void 0&&p>0&&(e.anisotropy=p),r(`inputs:geometry_normal`,`normalMap`,``,null)}_getTextureFromOpenPBRConnection(e){let t=e.replace(/<|>/g,``),n=t.split(`.`)[0],r=this.specsByPath[n];if(!r)return null;let i=this._getAttributes(n),a=i[`info:id`]||r.fields[`info:id`];if(r.fields.typeName===`NodeGraph`){let e=t.split(`.`)[1],r=n+`.`+e,i=this.specsByPath[r];return i?.fields?.connectionPaths?.length>0?this._getTextureFromOpenPBRConnection(i.fields.connectionPaths[0]):null}if(a===`arnold:image`){let e=i[`inputs:filename`];return e?this._loadTextureFromPath(e):null}if(a&&a.startsWith(`ND_image_`)){let e=i[`inputs:file`];return e?this._loadTextureFromPath(e):null}if(a===`MayaND_fileTexture_color4`){let e=n+`.inputs:inColor`,t=this.specsByPath[e];return t?.fields?.connectionPaths?.length>0?this._getTextureFromOpenPBRConnection(t.fields.connectionPaths[0]):null}if(a&&a.startsWith(`ND_convert_`)){let e=n+`.inputs:in`,t=this.specsByPath[e];return t?.fields?.connectionPaths?.length>0?this._getTextureFromOpenPBRConnection(t.fields.connectionPaths[0]):null}if(a===`arnold:bump2d`){let e=n+`.inputs:bump_map`,t=this.specsByPath[e];return t?.fields?.connectionPaths?.length>0?this._getTextureFromOpenPBRConnection(t.fields.connectionPaths[0]):null}if(a===`arnold:color_correct`){let e=n+`.inputs:input`,t=this.specsByPath[e];return t?.fields?.connectionPaths?.length>0?this._getTextureFromOpenPBRConnection(t.fields.connectionPaths[0]):null}let o=n.substring(0,n.lastIndexOf(`/`));if(o){let e=this.specsByPath[o];if(e){let t=this._getAttributes(o);if((t[`info:id`]||e.fields[`info:id`])===`arnold:image`){let e=t[`inputs:filename`];if(e)return this._loadTextureFromPath(e)}}}return null}_loadTextureFromPath(e){if(!e)return null;if(this.textureCache[e])return this.textureCache[e];let t=this._loadTexture(e,null,null);return t&&(this.textureCache[e]=t),t}_getTextureFromConnection(e){let t=e.split(`.`)[0],n=this.specsByPath[t];if(!n)return null;let r=this._getAttributes(t);if((r[`info:id`]||n.fields[`info:id`])!==`UsdUVTexture`)return null;let i=r[`inputs:file`];if(!i)return null;let a=null,o=0,s=t+`.inputs:st`,c=this.specsByPath[s];if(c?.fields?.connectionPaths?.length>0){let e=c.fields.connectionPaths[0].replace(/<|>/g,``).split(`.`)[0],t=this.specsByPath[e];if(t){let n=this._getAttributes(e),r=n[`info:id`]||t.fields[`info:id`];if(r===`UsdTransform2d`){a=n;let t=e+`.inputs:in`,r=this.specsByPath[t];if(r?.fields?.connectionPaths?.length>0){let e=r.fields.connectionPaths[0].replace(/<|>/g,``).split(`.`)[0],t=this._getAttributes(e)[`inputs:varname`];t===`st1`?o=1:t===`st2`&&(o=2)}}else if(r===`UsdPrimvarReader_float2`){let e=n[`inputs:varname`];e===`st1`?o=1:e===`st2`&&(o=2)}}}let l=r[`inputs:scale`],u=r[`inputs:bias`],d=i;if(l&&(d+=`:s`+l.join(`,`)),u&&(d+=`:b`+u.join(`,`)),this.textureCache[d])return this.textureCache[d];let f=this._loadTexture(i,r,a);return f&&(l&&(f.userData.scale=l),u&&(f.userData.bias=u),o!==0&&(f.channel=o),this.textureCache[d]=f),f}_applyTextureTransforms(e,t){if(!t)return;let n=t[`inputs:scale`];n&&Array.isArray(n)&&n.length>=2&&e.repeat.set(n[0],n[1]);let r=t[`inputs:translation`];r&&Array.isArray(r)&&r.length>=2&&e.offset.set(r[0],r[1]);let i=t[`inputs:rotation`];typeof i==`number`&&(e.rotation=i*Math.PI/180)}_loadTexture(e,t,n){let r=e;r.startsWith(`@`)&&(r=r.slice(1)),r.endsWith(`@`)&&(r=r.slice(0,-1));let i=this._resolveFilePath(r),a=this.assets[i];if(a||=this.assets[r],!a){let e=r.split(`/`).pop();for(let r in this.assets)if(r.endsWith(e)||r.endsWith(`/`+e))return this._createTextureFromData(this.assets[r],t,n);if(this.basePath)return this._createTextureFromData(i,t,n);if(this.manager){let r=this.manager.resolveURL(e);if(r!==e)return this._createTextureFromData(r,t,n)}return console.warn(`USDLoader: Texture not found:`,r),null}return this._createTextureFromData(a,t,n)}_createTextureFromData(e,t,n){if(!e)return null;let r=this,i=new Ht,a;if(typeof e==`string`)a=e;else if(e instanceof Uint8Array||e instanceof ArrayBuffer){let t=new Blob([e]);a=URL.createObjectURL(t)}else return null;let o=new Image;return this.texturePromises.push(new Promise(s=>{o.onload=function(){i.image=o,t&&(i.wrapS=r._getWrapMode(t[`inputs:wrapS`]),i.wrapT=r._getWrapMode(t[`inputs:wrapT`])),r._applyTextureTransforms(i,n),i.needsUpdate=!0,typeof e!=`string`&&URL.revokeObjectURL(a),s()},o.onerror=function(){console.warn(`USDLoader: Failed to load texture:`,a),typeof e!=`string`&&URL.revokeObjectURL(a),s()}})),o.src=a,i}_getWrapMode(e){return e===`repeat`?Je:e===`mirror`?Xe:e===`clamp`?Ye:Je}_buildSkeleton(e){let t=this._getAttributes(e),n=t.joints;if(!n||n.length===0)return null;let r=t.bindTransforms,i=t.restTransforms,a=this._flattenMatrixArray(r,n.length),o=this._flattenMatrixArray(i,n.length),s=[],c={},l=[];for(let e=0;e<n.length;e++){let t=n[e],r=t.split(`/`).pop(),i=new Qr;if(i.name=r,s.push(i),c[t]={bone:i,index:e},a&&a.length>=(e+1)*16){let t=new K,n=a.slice(e*16,(e+1)*16);t.set(n[0],n[4],n[8],n[12],n[1],n[5],n[9],n[13],n[2],n[6],n[10],n[14],n[3],n[7],n[11],n[15]);let r=t.clone().invert();l.push(r)}else l.push(new K)}for(let e=0;e<n.length;e++){let t=n[e].split(`/`);if(t.length>1){let n=c[t.slice(0,-1).join(`/`)];n&&n.bone.add(s[e])}}if(o&&o.length>=n.length*16)for(let e=0;e<n.length;e++){let t=new K,n=o.slice(e*16,(e+1)*16);t.set(n[0],n[4],n[8],n[12],n[1],n[5],n[9],n[13],n[2],n[6],n[10],n[14],n[3],n[7],n[11],n[15]),t.decompose(s[e].position,s[e].quaternion,s[e].scale)}let u=s.filter(e=>!e.parent||!e.parent.isBone),d=this.specsByPath[e+`.skel:animationSource`],f=null;return d&&d.fields.targetPaths&&d.fields.targetPaths.length>0&&(f=d.fields.targetPaths[0]),{skeleton:new ni(s,l),joints:n,rootBones:u,animationPath:f,path:e}}_bindSkeletons(){for(let e of this.skinnedMeshes){let{mesh:t,skeletonPath:n,localJoints:r,geomBindTransform:i}=e,a=null;if(n&&this.skeletons[n]&&(a=this.skeletons[n]),!a){for(let e in this.skeletons)if(n&&(n.includes(e)||e.includes(n))){a=this.skeletons[e];break}}if(!a){let e=Object.keys(this.skeletons);e.length>0&&(a=this.skeletons[e[0]])}if(!a){console.warn(`USDComposer: No skeleton found for skinned mesh`,t.name);continue}let{skeleton:o,rootBones:s,joints:c}=a;if(r&&r.length>0){let e=t.geometry.attributes.skinIndex;if(e){let t=[];for(let e=0;e<r.length;e++){let n=r[e],i=c.indexOf(n);t[e]=i>=0?i:0}let n=e.array;for(let e=0;e<n.length;e++){let r=n[e];r<t.length&&(n[e]=t[r])}}}for(let e of s)t.add(e);let l=new K;if(i&&i.length===16){let e=i;l.set(e[0],e[4],e[8],e[12],e[1],e[5],e[9],e[13],e[2],e[6],e[10],e[14],e[3],e[7],e[11],e[15])}t.bind(o,l)}}_buildAnimations(){let e=[];for(let t in this.specsByPath){let n=this.specsByPath[t];if(n.specType!==dd.Prim||n.fields.typeName!==`SkelAnimation`)continue;let r=this._buildAnimationClip(t);r&&e.push(r)}let t=this._buildTransformAnimations();return t.length>0&&e.push(new ua(`TransformAnimation`,-1,t)),e}_buildTransformAnimations(){let e=[];for(let t in this.specsByPath){let n=this.specsByPath[t];if(n.specType!==dd.Prim)continue;let r=n.fields?.typeName;if(r!==`Xform`&&r!==`Scope`&&r!==`Mesh`)continue;let i=t.split(`/`).pop(),a=t+`.xformOp:orient`,o=this.specsByPath[a];if(o?.fields?.timeSamples){let{times:t,values:n}=o.fields.timeSamples,r=[],a=[];for(let e=0;e<t.length;e++){r.push(t[e]/this.fps);let i=n[e];a.push(i[0],i[1],i[2],i[3])}r.length>0&&e.push(new sa(i+`.quaternion`,new Float32Array(r),new Float32Array(a)))}let s=t+`.xformOp:rotateXYZ`,c=this.specsByPath[s];if(c?.fields?.timeSamples){let{times:t,values:n}=c.fields.timeSamples,r=[],a=[],o=new $t,s=new kt;for(let e=0;e<t.length;e++){r.push(t[e]/this.fps);let i=n[e];o.set(i[0]*Math.PI/180,i[1]*Math.PI/180,i[2]*Math.PI/180,`ZYX`),s.setFromEuler(o),a.push(s.x,s.y,s.z,s.w)}r.length>0&&e.push(new sa(i+`.quaternion`,new Float32Array(r),new Float32Array(a)))}let l=t+`.xformOp:translate`,u=this.specsByPath[l];if(u?.fields?.timeSamples){let{times:t,values:n}=u.fields.timeSamples,r=[],a=[];for(let e=0;e<t.length;e++){r.push(t[e]/this.fps);let i=n[e];a.push(i[0],i[1],i[2])}r.length>0&&e.push(new la(i+`.position`,new Float32Array(r),new Float32Array(a)))}let d=t+`.xformOp:scale`,f=this.specsByPath[d];if(f?.fields?.timeSamples){let{times:t,values:n}=f.fields.timeSamples,r=[],a=[];for(let e=0;e<t.length;e++){r.push(t[e]/this.fps);let i=n[e];a.push(i[0],i[1],i[2])}r.length>0&&e.push(new la(i+`.scale`,new Float32Array(r),new Float32Array(a)))}let p=n.fields?.properties||[];for(let n of p){if(!n.startsWith(`xformOp:transform`))continue;let r=t+`.`+n,a=this.specsByPath[r];if(!a?.fields?.timeSamples)continue;let{times:o,values:s}=a.fields.timeSamples,c=[],l=[],u=[],d=[],f=[],p=[],m=new K,h=new W,g=new kt,_=new W;for(let e=0;e<o.length;e++){let t=s[e];if(!t||t.length<16)continue;let n=o[e]/this.fps;m.set(t[0],t[4],t[8],t[12],t[1],t[5],t[9],t[13],t[2],t[6],t[10],t[14],t[3],t[7],t[11],t[15]),m.decompose(h,g,_),c.push(n),l.push(h.x,h.y,h.z),u.push(n),d.push(g.x,g.y,g.z,g.w),f.push(n),p.push(_.x,_.y,_.z)}c.length>0&&(e.push(new la(i+`.position`,new Float32Array(c),new Float32Array(l))),e.push(new sa(i+`.quaternion`,new Float32Array(u),new Float32Array(d))),e.push(new la(i+`.scale`,new Float32Array(f),new Float32Array(p))));break}}return e}_buildAnimationClip(e){let t=this._getAttributes(e).joints;if(!t||t.length===0)return null;let n=[],r=this._getTimeSampledAttribute(e,`rotations`);if(r&&r.times&&r.values){let{times:e,values:i}=r;for(let r=0;r<t.length;r++){let a=t[r].split(`/`).pop(),o=[],s=[];for(let t=0;t<e.length;t++){let n=i[t];if(!n||n.length<(r+1)*4)continue;o.push(e[t]/this.fps);let a=n[r*4+0],c=n[r*4+1],l=n[r*4+2],u=n[r*4+3];s.push(a,c,l,u)}o.length>0&&n.push(new sa(a+`.quaternion`,new Float32Array(o),new Float32Array(s)))}}let i=this._getTimeSampledAttribute(e,`translations`);if(i&&i.times&&i.values){let{times:e,values:r}=i;for(let i=0;i<t.length;i++){let a=t[i].split(`/`).pop(),o=[],s=[];for(let t=0;t<e.length;t++){let n=r[t];!n||n.length<(i+1)*3||(o.push(e[t]/this.fps),s.push(n[i*3+0],n[i*3+1],n[i*3+2]))}o.length>0&&n.push(new la(a+`.position`,new Float32Array(o),new Float32Array(s)))}}let a=this._getTimeSampledAttribute(e,`scales`);if(a&&a.times&&a.values){let{times:e,values:r}=a;for(let i=0;i<t.length;i++){let a=t[i].split(`/`).pop(),o=[],s=[];for(let t=0;t<e.length;t++){let n=r[t];!n||n.length<(i+1)*3||(o.push(e[t]/this.fps),s.push(n[i*3+0],n[i*3+1],n[i*3+2]))}o.length>0&&n.push(new la(a+`.scale`,new Float32Array(o),new Float32Array(s)))}}return n.length===0?null:new ua(e.split(`/`).pop(),-1,n)}_getTimeSampledAttribute(e,t){let n=e+`.`+t,r=this.specsByPath[n];if(r&&r.fields.timeSamples){let e=r.fields.timeSamples;if(e.times&&e.values)return e}return null}_flattenMatrixArray(e,t){if(!e||e.length===0)return null;if(typeof e[0]==`number`)return e;let n=[];for(let r=0;r<t;r++)for(let t=0;t<4;t++){let i=e[r*4+t];i&&i.length===4?n.push(i[0],i[1],i[2],i[3]):n.push(+(t===0),+(t===1),+(t===2),+(t===3))}return n}}})),hd=r({USDLoader:()=>gd}),gd,_d=t((()=>{lo(),Ds(),Yu(),ld(),md(),gd=class extends ma{constructor(e){super(e)}load(e,t,n,r){let i=this,a=i.path===``?Wa.extractUrlBase(e):i.path,o=new _a(i.manager);o.setPath(i.path),o.setResponseType(`arraybuffer`),o.setRequestHeader(i.requestHeader),o.setWithCredentials(i.withCredentials),o.load(e,function(n){try{i.parse(n,a,t,r)}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e,t=``,n,r){let i=new Ju,a=new cd,o=new TextDecoder;function s(e){return e instanceof ArrayBuffer?e:e.byteOffset===0&&e.byteLength===e.buffer.byteLength?e.buffer:e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength)}function c(e){let t=e.lastIndexOf(`.`);return t<0||e.lastIndexOf(`/`)>t?``:e.slice(t+1).toLowerCase()}function l(e){let t={};for(let n in e){let r=e[n],l=c(n);if(l===`png`||l===`jpg`||l===`jpeg`||l===`avif`){t[n]=r;continue}l!==`usd`&&l!==`usda`&&l!==`usdc`||(u(r)?t[n]=a.parseData(s(r)):t[n]=i.parseData(o.decode(r)))}return t}function u(e){let t=new Uint8Array([80,88,82,45,85,83,68,67]),n=e instanceof Uint8Array?e:new Uint8Array(e);if(n.byteLength<t.length)return!1;for(let e=0;e<t.length;e++)if(n[e]!==t[e])return!1;return!0}function d(e){let t=Object.keys(e);if(t.length<1)return{file:void 0,filename:``,basePath:``};let n=t[0],r=c(n),i=!1,a=n.lastIndexOf(`/`),o=a>=0?n.slice(0,a):``;if(r===`usda`)return{file:e[n],filename:n,basePath:o};if(r===`usdc`)i=!0;else if(r===`usd`)if(u(e[n]))i=!0;else return{file:e[n],filename:n,basePath:o};return i?{file:e[n],filename:n,basePath:o}:{file:void 0,filename:``,basePath:``}}let f=this,p=(e,t)=>(n&&Promise.all(e.texturePromises).then(()=>n(t)).catch(e=>r?r(e):console.error(e)),t);if(typeof e==`string`){let n=new pd(f.manager),r=i.parseData(e);return p(n,n.compose(r,{},{},t))}if(u(e)){let n=new pd(f.manager),r=a.parseData(s(e));return p(n,n.compose(r,{},{},t))}let m=new Uint8Array(e);if(m[0]===80&&m[1]===75){let e=Co(m),t=l(e),{file:n,filename:r,basePath:i}=d(e);if(!n)throw Error(`THREE.USDLoader: Invalid USDZ package. The first ZIP entry must be a USD layer (.usd/.usda/.usdc).`);let a=new pd(f.manager),o=t[r];if(!o)throw Error(`THREE.USDLoader: Failed to parse root layer "`+r+`".`);return p(a,a.compose(o,t,{},i))}let h=new pd(f.manager),g=o.decode(m),_=i.parseData(g);return p(h,h.compose(_,{},{},t))}}}));lo(),Ds(),Object.assign(globalThis,{DOMParser:Os.DOMParser}),xa.prototype.load=function(e,t){let n=new Ht;return queueMicrotask(()=>t?.(n)),n},Ka.prototype.load=function(e,t){queueMicrotask(()=>t?.(new OffscreenCanvas(1,1).transferToImageBitmap()))};let vd=new TextDecoder,yd=512*1024*1024;function bd(e){if(/<!DOCTYPE|<!ENTITY/i.test(e))throw Error(`External XML declarations are unsupported.`);let t=new Os.DOMParser({onError:(e,t)=>{if(e!==`warning`)throw Error(t)}}).parseFromString(e,`application/xml`),n=function(e){let t=/^\[(id|sid)="([^"]+)"\]$/.exec(e);return t&&Array.from(this.getElementsByTagName(`*`)).find(e=>e.getAttribute(t[1])===t[2])||null},r=Array.from(t.getElementsByTagName(`*`));for(let e of r)Object.assign(e,{querySelector:n});return Object.assign(t,{querySelector:n}),t}Object.assign(globalThis,{DOMParser:class{parseFromString(e){return bd(e)}}});let xd=(e,t)=>Array.from(e.childNodes).filter(e=>e.nodeType===1&&(!t||e.tagName===t)),Sd=(e,t)=>xd(e,t)[0],Cd=(e,t)=>Sd(e,t)?.textContent?.trim()||``;function wd(e){let t=0,n=Co(e,{filter:e=>{if(t+=e.originalSize,t>yd)throw Error(`Archive exceeds the available import working budget (512 MiB). Export a smaller asset bundle.`);if(/^[/\\]|(^|[/\\])\.\.([/\\]|$)/.test(e.name))throw Error(`Unsafe archive asset path.`);return!0}});return new Map(Object.entries(n))}function Td(e,t){let n=decodeURIComponent(t).replace(/\\/g,`/`).replace(/^\.\//,``);if(/^(https?:|file:|\/)/i.test(n))throw Error(`Only assets in the selected local bundle can be imported.`);let r=[];for(let e of n.split(`/`))if(!(e===`.`||!e))if(e===`..`){if(!r.length)throw Error(`Asset reference leaves the selected bundle.`);r.pop()}else r.push(e);n=r.join(`/`);let i=e.get(n);if(i)return i;let a=[...e].filter(([e])=>e.toLowerCase()===n.toLowerCase());if(a.length===1)return a[0][1];throw Error(`Missing companion asset: ${t}. Select it with the model or use a packaged format.`)}function Ed(e,t=!1){if(!e)return new K;let n=(e.match(/[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?/g)||[]).map(Number);if(!n.every(Number.isFinite))throw Error(`Invalid source transformation.`);if(t&&n.length===16)return new K().fromArray(n);if(n.length!==12)throw Error(`Unsupported source transformation matrix.`);return new K().fromArray([n[0],n[1],n[2],0,n[3],n[4],n[5],0,n[6],n[7],n[8],0,n[9],n[10],n[11],1])}function Dd(e,t){e.matrix.copy(t),e.matrixAutoUpdate=!1}async function Od(e,t,n){let r=Td(t,e),i=e.split(`.`).pop().toLowerCase(),a=new fa,o=[];a.setURLModifier(n=>{if(n.startsWith(`data:`)||n.startsWith(`blob:`))return n;let r=e.includes(`/`)?e.slice(0,e.lastIndexOf(`/`)+1):``,i=URL.createObjectURL(new Blob([Td(t,r+n).slice().buffer]));return o.push(i),i});try{let e=r.slice().buffer;if(i===`glb`||i===`gltf`){let{GLTFLoader:t}=await Promise.resolve().then(()=>(Ic(),Is)),n=new t(a);return n.register(()=>({name:`OPTICMESH_NEUTRAL`,loadMaterial:()=>Promise.resolve(new qi)})),(await n.parseAsync(i===`glb`?e:vd.decode(r),``)).scene}if(i===`obj`){let{OBJLoader:e}=await Promise.resolve().then(()=>(Zc(),Lc));return new e(a).parse(vd.decode(r))}if(i===`fbx`){let{FBXLoader:t}=await Promise.resolve().then(()=>(Il(),dl));return new t(a).parse(e,``)}if(i===`3ds`){let{TDSLoader:t}=await Promise.resolve().then(()=>(Eu(),Ll));return n.add(`3DS imports mesh names and placement; legacy keyframer hierarchy is not preserved.`),new t(a).parse(e,``)}if(i===`stl`){let{STLLoader:t}=await Promise.resolve().then(()=>(ku(),Du));return new Vr(new t(a).parse(e))}if(i===`dae`){let{ColladaLoader:e}=await Promise.resolve().then(()=>(Uu(),Vu));return new e(a).parse(vd.decode(r),``).scene}if([`usd`,`usda`,`usdc`,`usdz`].includes(i)){let{USDLoader:t}=await Promise.resolve().then(()=>(_d(),hd));return n.add(`USD imports supported static meshes. Advanced composition, animation and shading may differ from the source.`),await new Promise((n,r)=>{new t(a).parse(e,``,n,r)})}throw Error(`Unsupported mesh format: ${i}`)}finally{for(let e of o)URL.revokeObjectURL(e)}}async function kd(e,t){let n=wd(e),r=bd(vd.decode(Td(n,`description.xml`))),i=r.getElementsByTagName(`FixtureType`)[0];if(![`1.1`,`1.2`].includes(r.documentElement?.getAttribute(`DataVersion`)||``))throw Error(`Supported GDTF geometry versions are 1.1 and 1.2.`);if(!i)throw Error(`GDTF fixture description is missing.`);let a=xd(Sd(i,`Models`)||i,`Model`),o=Sd(i,`Geometries`);if(!o)throw Error(`GDTF contains no geometry hierarchy.`);let s=new Map(a.map(e=>[e.getAttribute(`Name`),e])),c=new Map(Array.from(o.getElementsByTagName(`*`)).map(e=>[e.getAttribute(`Name`),e])),l=new Map;async function u(e,r){if(r.has(e)||r.size>128)throw Error(`Cyclic or excessively nested GDTF geometry.`);let i=new Set(r).add(e),a=new vn;a.name=e.getAttribute(`Name`)||e.tagName,Dd(a,Ed(e.getAttribute(`Position`)||``,!0));let o=e.getAttribute(`Model`),d=s.get(o);if(d){let e=l.get(o);if(!e){let r=d.getAttribute(`File`),i=d.getAttribute(`PrimitiveType`),a=[`Length`,`Width`,`Height`].map(e=>Number(d.getAttribute(e))||.1);if(r){let i=[`models/gltf/${r}.glb`,`models/3ds/${r}.3ds`].find(e=>n.has(e));if(!i)throw Error(`Missing GDTF mesh: ${r}`);e=await Od(i,n,t);let a=new vn;i.endsWith(`.glb`)?a.rotation.x=Math.PI/2:a.scale.setScalar(.001),a.add(e),e=a}else{let n=i===`Sphere`?new Ki(.5,12,8):i===`Cylinder`?new Vi(.5,.5,1,12):new zi(1,1,1);[`Cube`,`Sphere`,`Cylinder`].includes(i||``)||t.add(`Some GDTF predefined shapes use dimensioned box placeholders.`),i===`Cylinder`&&n.rotateX(Math.PI/2),e=new Vr(n),e.scale.set(a[0],a[1],a[2])}l.set(o,e)}a.add(e.clone(!0))}if(e.tagName===`GeometryReference`){let n=c.get(e.getAttribute(`Geometry`));n?a.add(await u(n,i)):t.add(`A GDTF geometry reference could not be resolved.`)}for(let t of xd(e))(t.hasAttribute(`Position`)||t.hasAttribute(`Model`)||t.tagName.startsWith(`Geometry`))&&a.add(await u(t,i));return a}let d=new vn;d.name=i.getAttribute(`Name`)||`Fixture`;for(let e of xd(o))d.add(await u(e,new Set));return t.add(`GDTF imports static fixture geometry at its authored pose; beams and DMX behaviour are excluded.`),d}async function Ad(e,t){let n=wd(e),r=bd(vd.decode(Td(n,`GeneralSceneDescription.xml`))),i=r.documentElement,a=i.getAttribute(`verMajor`),o=i.getAttribute(`verMinor`);if(i.tagName!==`GeneralSceneDescription`)throw Error(`MVR scene description root is invalid.`);if(a!==`1`||![`4`,`5`,`6`].includes(o||``))throw Error(`MVR version ${a||`?`}.${o||`?`} is unsupported. Supported versions are 1.4, 1.5 and 1.6.`);let s=new Map(Array.from(r.getElementsByTagName(`Symdef`)).map(e=>[e.getAttribute(`uuid`),e])),c=new Map;async function l(e,r){if(r.has(e)||r.size>128)throw Error(`Cyclic or excessively nested MVR hierarchy.`);let i=new Set(r).add(e),a=new vn;a.name=e.getAttribute(`name`)||e.tagName;let o=e.tagName===`Geometry3D`||e.tagName===`Symbol`;o||Dd(a,Ed(Cd(e,`Matrix`)));for(let r of o?[e]:xd(Sd(e,`Geometries`)||e))if(r.tagName===`Geometry3D`){let e=r.getAttribute(`fileName`)||``;e.includes(`.`)||(e+=`.3ds`);let i=c.get(e);i||(i=await Od(e,n,t),c.set(e,i));let o=new vn;Dd(o,Ed(Cd(r,`Matrix`)));let s=new vn;/\.gl(?:tf|b)$/i.test(e)&&(s.rotation.x=Math.PI/2,s.scale.setScalar(1e3)),s.add(i.clone(!0)),o.add(s),a.add(o)}else if(r.tagName===`Symbol`){let e=s.get(r.getAttribute(`symdef`));if(!e)throw Error(`Missing MVR symbol definition.`);let t=new vn;Dd(t,Ed(Cd(r,`Matrix`))),t.add(await l(e,i)),a.add(t)}e.tagName===`Fixture`&&Cd(e,`GDTFSpec`)&&t.add(`Lighting fixture definitions and metadata are excluded from MVR mesh import.`);let u=Sd(e,`ChildList`);if(u)for(let e of xd(u))a.add(await l(e,i));return a}let u=new vn,d=r.getElementsByTagName(`Layers`)[0];if(!d)throw Error(`MVR scene layers are missing.`);for(let e of xd(d))u.add(await l(e,new Set));let f=e=>{for(let t of[...e.children])f(t)||e.remove(t);return e instanceof Vr&&!!e.geometry.getAttribute(`position`)?.count||e.children.length>0};return f(u),u}async function jd(e,t){let n=t.split(`.`).pop().toLowerCase(),r=new Set;self.postMessage({progress:`Reading ${n.toUpperCase()} geometry…`});let i=n===`mvr`?await Ad(Td(e,t),r):n===`gdtf`?await kd(Td(e,t),r):await Od(t,e,r);i.updateMatrixWorld(!0);let a={id:crypto.randomUUID(),name:t,format:n,hierarchy:!0,nodes:[],geometries:{},warnings:[],triangles:0},o=new Map,s=crypto.randomUUID();a.nodes.push({id:s,parent:null,name:`3D Model — ${t}`,matrix:new K().toArray(),visible:!0,locked:!1,style:`shaded`});let c=(e,t)=>{let n=crypto.randomUUID(),i={id:n,parent:t,name:e.name||(e instanceof Vr?`Mesh`:`Group`),matrix:e.matrixWorld.toArray(),visible:e.visible,locked:!1};if(!i.matrix.every(Number.isFinite))throw Error(`Object "${i.name}" has an invalid transform. Check its coordinates in the source application and export it again.`);if(e instanceof Vr){let t=e.geometry;if(e instanceof Zr){t=e.geometry.clone();let n=t.getAttribute(`position`),i=new W;for(let t=0;t<n.count;t++)e.getVertexPosition(t,i),n.setXYZ(t,i.x,i.y,i.z);t.computeVertexNormals(),r.add(`Skinned geometry is imported as a static pose.`)}let n=o.get(t);n||(n=crypto.randomUUID(),o.set(t,n),a.geometries[n]=As(t,i.name,e=>r.add(e))),i.geometry=n,a.triangles+=(t.index?.count||t.getAttribute(`position`).count)/3}else (e instanceof Oi||e instanceof Ri)&&r.add(`Non-surface lines and points are omitted.`);if(!(e instanceof Sa||e instanceof Aa)){a.nodes.push(i);for(let t of e.children)c(t,n)}};if(c(i,s),!a.triangles)throw Error(`No supported triangle mesh geometry was found.`);return a.warnings=[...r],a}self.onmessage=async e=>{try{let{files:t,name:n}=e.data;if(t.reduce((e,t)=>e+t.bytes.byteLength,0)>yd)throw Error(`Selected assets exceed the 512 MiB import working budget.`);let r=new Map(t.map(e=>[e.name,new Uint8Array(e.bytes)]));self.postMessage({model:await jd(r,n)})}catch(e){self.postMessage({error:e instanceof Error?e.message:`Unable to read model.`})}}})();